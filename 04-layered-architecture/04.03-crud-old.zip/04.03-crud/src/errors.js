'use strict';

var Commons = require('@neosperience/nsp-service-commons-lib');

var NspError = Commons.NspError;
var HttpError = Commons.HttpError;

function initErrors () {
    NspError.addCodes({
        PRODUCT_NOT_FOUND: 'PRODUCT_NOT_FOUND',
        PRODUCT_UNPROCESSABLE: 'PRODUCT_UNPROCESSABLE',
        PRODUCT_ALREADY_EXISTS: 'PRODUCT_ALREADY_EXISTS',
        DUPLICATED_PRODUCT_SKU: 'DUPLICATED_PRODUCT_SKU',
        COLLECTION_NOT_FOUND: 'COLLECTION_NOT_FOUND',
        COLLECTION_UNPROCESSABLE: 'COLLECTION_UNPROCESSABLE',
        COLLECTION_ALREADY_EXISTS: 'COLLECTION_ALREADY_EXISTS',
        CANNOT_DELETE_COLLECTION: 'CANNOT_DELETE_COLLECTION',
    });
    var mapping = {};
    mapping[NspError.codes.PRODUCT_NOT_FOUND] = HttpError.statusCodes.NOT_FOUND;
    mapping[NspError.codes.PRODUCT_UNPROCESSABLE] = HttpError.statusCodes.UNPROCESSABLE_ENTITY;
    mapping[NspError.codes.PRODUCT_ALREADY_EXISTS] = HttpError.statusCodes.CONFLICT;
    mapping[NspError.codes.DUPLICATED_PRODUCT_SKU] = HttpError.statusCodes.CONFLICT;
    mapping[NspError.codes.COLLECTION_NOT_FOUND] = HttpError.statusCodes.NOT_FOUND;
    mapping[NspError.codes.COLLECTION_UNPROCESSABLE] = HttpError.statusCodes.UNPROCESSABLE_ENTITY;
    mapping[NspError.codes.COLLECTION_ALREADY_EXISTS] = HttpError.statusCodes.CONFLICT;
    mapping[NspError.codes.CANNOT_DELETE_COLLECTION] = HttpError.statusCodes.CONFLICT;
    HttpError.addNspErrorMapping(mapping);
}

initErrors();
module.exports.NspError = NspError;
module.exports.HttpError = HttpError;
