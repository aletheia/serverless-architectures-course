'use strict';

var MongoDb = require('mongodb'),
    Promise = require('bluebird'),
    NspError = require('./errors.js').NspError;

function toNspError (dbError) {
    return new NspError(NspError.codes.INTERNAL_SERVER_ERROR, dbError.message);
}

function Client (logger, config, mongo) {
    mongo = mongo || MongoDb;

    var connectionPromise = mongo.MongoClient.connect(config.url, {
        promiseLibrary: Promise
    });

    this.insertOne = function (collection, doc) {
        logger.verbose('RepClient/insert');
        return connectionPromise.then(function (db) {
            return db.collection(collection).insertOne(doc);
        }).catch(function (dbErr) {
            throw toNspError(dbErr);
        });
    };

    this.find = function (collection, query, projection) {
        logger.verbose('RepClient/find');
        return connectionPromise.then(function (db) {
            return db.collection(collection).find(query, projection);
        }).catch(function (dbErr) {
            throw toNspError(dbErr);
        });
    };

    this.findOne = function (collection, query, projection) {
        logger.verbose('RepClient/findOne');
        return connectionPromise.then(function (db) {
            return db.collection(collection).findOne(query, projection);
        }).catch(function (dbErr) {
            throw toNspError(dbErr);
        });
    };

    this.findOneAndReplace = function (collection, filter, replacement, options) {
        logger.verbose('RepClient/findOneAndReplace');
        return connectionPromise.then(function (db) {
            return db.collection(collection).findOneAndReplace(filter, replacement, options);
        }).catch(function (dbErr) {
            throw toNspError(dbErr);
        });
    };

    this.deleteOne = function (collection, filter) {
        logger.verbose('RepClient/deleteOne');
        return connectionPromise.then(function (db) {
            return db.collection(collection).deleteOne(filter);
        }).catch(function (dbErr) {
            throw toNspError(dbErr);
        });
    };

    this.update = function (collection, query, update) {
        logger.verbose('RepClient/update');
        return connectionPromise.then(function (db) {
            return db.collection(collection).update(query, update);
        }).catch(function (dbErr) {
            throw toNspError(dbErr);
        });
    };

    this.dropDatabase = function () {
        logger.verbose('RepClient/dropDatabase');
        return connectionPromise.then(function (db) {
            return db.dropDatabase();
        }).catch(function (dbErr) {
            throw toNspError(dbErr);
        });
    };

    this.dispose = function () {
        logger.verbose('RepClient/dispose');
        return connectionPromise.then(function (db) {
            return db.close();
        }).catch(function (dbErr) {
            throw toNspError(dbErr);
        });
    };
}

Client.$inject = ['logger', 'db-client.config'];

module.exports = Client;
