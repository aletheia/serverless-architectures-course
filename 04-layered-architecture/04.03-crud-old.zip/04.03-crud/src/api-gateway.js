'use strict';

var _ = require('lodash'),
    Commons = require('@neosperience/nsp-service-commons-lib');

var createThingSchema = require('../resources/json-schemas/thing-create.json'),
    updateThingSchema = require('../resources/json-schemas/thing-update.json');

class ApiGateway extends Commons.ApiGateway {
    static factory () {
        return {
            create: event => new ApiGateway(event)
        };
    }

    constructor (event) {
        super(event);
    }

    getUuid () {
        return this.getPathParameter('uuid', true);
    }

    getOwner () {
        return this.getQueryStringParameter('owner');
    }

    getLocale () {
        function validator (locale) {
            if (!/^[a-z]{2}(_[A-Z]{2})?$/.test(locale)) {
                throw new Commons.ValidationError('Invalid format: "' + locale + '"');
            }
        }
        return this.getQueryStringParameter('locale', false, validator);
    }

    getTags () {
        var result;
        function validator (tags) {
            result = tags.split(',');
            if (!_.isEqual(result, _.uniq(result))) {
                throw new Commons.ValidationError('Must contain unique values');
            }
        }
        this.getQueryStringParameter('tags', false, validator);
        return result;
    }

    getStatusFilter () {
        function validator (statusFilter) {
            statusFilter = statusFilter.toLowerCase();
            if (statusFilter !== 'all' && statusFilter !== 'published' && statusFilter !== 'draft') {
                throw new Commons.ValidationError('Must be one of "all", "published", "draft"');
            }
        }
        var statusFilter = this.getQueryStringParameter('statusFilter', false, validator);
        if (_.isUndefined(statusFilter)) {
            return 'published';
        }
        statusFilter = statusFilter.toLowerCase();
        if (statusFilter === 'all') {
            return undefined;
        } else {
            return statusFilter;
        }
    }

    getThingForCreate () {
        return this.getEntity(createThingSchema, 'thing');
    }

    getThingForUpdate () {
        return this.getEntity(updateThingSchema, 'thing');
    }


}

module.exports = ApiGateway;
