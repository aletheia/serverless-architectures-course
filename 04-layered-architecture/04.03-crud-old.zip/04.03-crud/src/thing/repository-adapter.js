'use strict';

var _ = require('lodash'),
    NspError = require('../errors.js').NspError,
    Promise = require('bluebird');

function thingMongoIDToUUID (thing) {
    if (!_.isNull(thing)) {
        thing.uuid = thing._id;
        delete thing._id;
    }
}

function thingUUIDToMongoID (thing) {
    if (!_.isUndefined(thing.uuid)) {
        if (!_.isString(thing.uuid)) {
            throw new NspError(NspError.codes.INTERNAL_SERVER_ERROR, 'Invalid UUID');
        }
        thing._id = thing.uuid;
        delete thing.uuid;
    }
}

function RepositoryAdapter (logger, repository) {

    this.createThing = function (thing) {
        return Promise.try(function () {
            thing = _.cloneDeep(thing);
            thingUUIDToMongoID(thing);
            return repository.createThing(thing)
                .then(function (createdThing) {
                    thingMongoIDToUUID(createdThing);
                    return createdThing;
                });
        });
    };

    this.getThing = function (uuid) {
        return Promise.try(function () {
            return repository.getThing(uuid)
                .then(function (thing) {
                    thingMongoIDToUUID(thing);
                    return thing;
                });
        });
    };

    this.getThingByOwnerAndSku = function (owner, sku) {
        return Promise.try(function () {
            return repository.getThingByOwnerAndSku(owner, sku)
                .then(function (thing) {
                    thingMongoIDToUUID(thing);
                    return thing;
                });
        });
    };

    this.getThingForChecks = function (uuid) {
        return Promise.try(function () {
            return repository.getThingForChecks(uuid)
                .then(function (thing) {
                    thingMongoIDToUUID(thing);
                    return thing;
                });
        });
    };

    this.updateThing = function (replacementThing) {
        return Promise.try(function () {
            replacementThing = _.cloneDeep(replacementThing);
            thingUUIDToMongoID(replacementThing);
            return repository.updateThing(replacementThing)
                .then(function (replacedThing) {
                    thingMongoIDToUUID(replacedThing);
                    return replacedThing;
                });
        });
    };

    this.deleteThing = function (thingToDelete) {
        return Promise.try(function () {
            thingToDelete = _.clone(thingToDelete);
            thingUUIDToMongoID(thingToDelete);
            return repository.deleteThing(thingToDelete);
        });
    };

    /**
     * List all things
     * @param p {object} params
     * @param [p.owner] {string} an optional filter on the thing owner
     * @param [p.statusFilter] {string} an optional filter on the thing status
     * @returns {Promise<object>}
     */
    this.listThings = function (p) {
        return Promise.try(function () {
            return repository.listThings(p)
                .then(function (list) {
                    _.forEach(list, function (thing) {
                        thingMongoIDToUUID(thing);
                    });
                    return list;
                });
        });
    };

    /**
     * List all things referencing an asset
     * @param p {object} params
     * @param p.assetId {string} id of the asset referenced
     * @param [p.owner] {string} an optional filter on the thing owner
     * @param [p.statusFilter] {string} an optional filter on the thing status
     * @returns {Promise<object>}
     */
    this.listThingsReferencingAsset = function (p) {
        return Promise.try(function () {
            return repository.listThingsReferencingAsset(p)
                .then(function (list) {
                    _.forEach(list, function (thing) {
                        thingMongoIDToUUID(thing);
                    });
                    return list;
                });
        });
    };

    /**
     * Search all things with one or more tags
     * @param p {object} params
     * @param [p.tags] {string[]} the thing tags to match
     * @param [p.locale] {string} the locale to use to match the tag
     * @param [p.owner] {string} an optional filter on the thing owner
     * @param [p.statusFilter] {string} an optional filter on the thing status
     * @returns {Promise<object>}
     */
    this.searchThingsByTags = function (p) {
        return Promise.try(function () {
            return repository.searchThingsByTags(p)
                .then(function (list) {
                    _.forEach(list, function (thing) {
                        thingMongoIDToUUID(thing);
                    });
                    return list;
                });
        });
    };

    this.listThingsReferencingCollection = function (owner, collectionId) {
        return Promise.try(function () {
            return repository.listThingsReferencingCollection(owner, collectionId)
                .then(function (list) {
                    _.forEach(list, function (thing) {
                        thingMongoIDToUUID(thing);
                    });
                    return list;
                });
        });
    };
}

RepositoryAdapter.$inject = ['logger', 'thing.repository'];

module.exports = RepositoryAdapter;
