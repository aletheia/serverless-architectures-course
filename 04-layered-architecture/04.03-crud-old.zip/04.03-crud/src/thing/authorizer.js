'use strict';

var Promise = require('bluebird');

function Authorizer (logger, logic) {

    this.createThing = function (principal, thing) {
        logger.verbose('ThingAuthorizer/createThing', { principal: principal, thing: thing });
        return Promise.try(function () {
            principal.checkAuthorization(['ROLE_PRODUCT_USER', 'ROLE_ADMIN'], 'create things');
            thing.owner = principal.getOwner(thing.owner);
            return logic.createThing(principal, thing);
        });
    };

    this.getThing = function (principal, p) {
        logger.verbose('ThingAuthorizer/getThing', { principal: principal, p: p });
        return Promise.try(function () {
            principal.checkAuthorization(
                ['ROLE_BROWSER', 'ROLE_PERMALINK', 'ROLE_PRODUCT_USER', 'ROLE_ADMIN'], 'get things');
            return logic.getThing(principal, p);
        });
    };

    this.updateThing = function (principal, uuid, thing) {
        logger.verbose('ThingAuthorizer/updateThing', { principal: principal, uuid: uuid, thing: thing });
        return Promise.try(function () {
            principal.checkAuthorization(['ROLE_PRODUCT_USER', 'ROLE_ADMIN'], 'update things');
            return logic.updateThing(principal, uuid, thing);
        });
    };

    this.deleteThing = function (principal, uuid) {
        logger.verbose('ThingAuthorizer/deleteThing', { principal: principal, uuid: uuid });
        return Promise.try(function () {
            principal.checkAuthorization(['ROLE_PRODUCT_USER', 'ROLE_ADMIN'], 'delete things');
            return logic.deleteThing(principal, uuid);
        });
    };

    this.listThings = function (principal, p) {
        logger.verbose('ThingAuthorizer/listThings', { principal: principal, p: p });
        return Promise.try(function () {
            principal.checkAuthorization(['ROLE_BROWSER', 'ROLE_PRODUCT_USER', 'ROLE_ADMIN'], 'list things');
            p.owner = principal.getFilterByOwner(p.owner);
            return logic.listThings(principal, p);
        });
    };

    this.searchThingsByTags = function (principal, p) {
        logger.verbose('ThingAuthorizer/searchThingsByTags', { principal: principal, p: p });
        return Promise.try(function () {
            principal.checkAuthorization(['ROLE_BROWSER', 'ROLE_PRODUCT_USER', 'ROLE_ADMIN'], 'search things');
            p.owner = principal.getFilterByOwner(p.owner);
            return logic.searchThingsByTags(principal, p);
        });
    };

}

Authorizer.$inject = ['logger', 'thing.logic'];

module.exports = Authorizer;
