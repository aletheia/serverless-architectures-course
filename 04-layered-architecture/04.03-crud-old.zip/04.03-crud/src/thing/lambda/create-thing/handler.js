'use strict';

var ApiGateway = require('../../../api-gateway.js'),
    Container = require('../../../container.js'),
    Promise = require('bluebird');

module.exports.handler = function (event, context, callback, container, apiGateway) {
    apiGateway = apiGateway || new ApiGateway(event);
    return Promise.try(function () {
        container = container || new Container();
        var principal = apiGateway.getPrincipal();
        var thing = apiGateway.getThingForCreate();
        return container.get('thing.authorizer').createThing(principal, thing)
            .then(function (thing) {
                var headers = apiGateway.createLocationHeader(thing.uuid);
                var response = apiGateway.createResponse(201, headers, thing);
                callback(null, response);
            });
    })
        .catch(function (error) {
            callback(null, apiGateway.createErrorResponse(error));
        })
        .finally(function () {
            return container.shutdown();
        });
};
