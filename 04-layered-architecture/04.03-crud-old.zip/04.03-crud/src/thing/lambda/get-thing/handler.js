'use strict';

var _ = require('lodash'),
    ApiGateway = require('../../../api-gateway.js'),
    Container = require('../../../container.js'),
    Promise = require('bluebird');

module.exports.handler = function (event, context, callback, container, apiGateway) {
    apiGateway = apiGateway || new ApiGateway(event);
    return Promise.try(function () {
        container = container || new Container();
        var principal = apiGateway.getPrincipal();
        var uuid = apiGateway.getUuid();
        var statusFilter = apiGateway.getStatusFilter();
        var params = _.omitBy({ uuid: uuid, statusFilter: statusFilter }, _.isUndefined);
        return container.get('thing.authorizer').getThing(principal, params)
            .then(function (thing) {
                var response;
                if (apiGateway.wasModifiedSinceIfModifiedSince(thing)) {
                    var headers = apiGateway.createLastModifiedHeader(thing);
                    headers['Cache-Control'] = 'must-revalidate';
                    response = apiGateway.createResponse(200, headers, thing);
                } else {
                    response = apiGateway.createResponse(304);
                }
                callback(null, response);
            });
    })
        .catch(function (error) {
            callback(null, apiGateway.createErrorResponse(error));
        })
        .finally(function () {
            return container.shutdown();
        });
};
