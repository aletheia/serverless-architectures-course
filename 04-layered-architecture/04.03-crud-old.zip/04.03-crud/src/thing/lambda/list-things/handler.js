'use strict';

var _ = require('lodash'),
    ApiGateway = require('../../../api-gateway.js'),
    Container = require('../../../container.js'),
    Promise = require('bluebird');

module.exports.handler = function (event, context, callback, container, apiGateway) {
    apiGateway = apiGateway || new ApiGateway(event);
    return Promise.try(function () {
        container = container || new Container();
        var principal = apiGateway.getPrincipal();
        var statusFilter = apiGateway.getStatusFilter();
        var owner = apiGateway.getOwner();
        var params = _.omitBy({ statusFilter: statusFilter, owner: owner }, _.isUndefined);
        return container.get('thing.authorizer').listThings(principal, params)
            .then(function (things) {
                var response = apiGateway.createResponse(200, {}, things);
                callback(null, response);
            });
    })
        .catch(function (error) {
            callback(null, apiGateway.createErrorResponse(error));
        })
        .finally(function () {
            return container.shutdown();
        });
};
