'use strict';

var _ = require('lodash'),
    NspError = require('../errors.js').NspError,
    localizationSchema = require('../../resources/json-schemas/thing-localization.json'),
    Promise = require('bluebird'),
    uuid = require('uuid');

function thingNotFoundErrorFactory (uuid) {
    return new NspError(NspError.codes.PRODUCT_NOT_FOUND, 'Thing "' + uuid + '" not found');
}

function checkOwnership (thing, principal, owner) {
    principal.checkOwnership(thing, thingNotFoundErrorFactory, owner);
}

function checkExistence (thing, uuid) {
    if (_.isNull(thing)) {
        throw thingNotFoundErrorFactory(uuid);
    }
}

function checkStatus (statusFilter, thing) {
    if (_.isString(statusFilter) && thing.status !== statusFilter) {
        throw thingNotFoundErrorFactory(thing.uuid);
    }
}

function checkUpdate (oldThing, newThing, principal) {
    var errors = [];
    if (
        oldThing.thumbnail.assetId === newThing.thumbnail.assetId &&
        oldThing.thumbnail.url !== newThing.thumbnail.url
    ) {
        errors.push('Cannot change service-managed property: thumbnail.url');
    }
    principal.checkReadOnlyProperties(
        oldThing,
        newThing,
        ['uuid', 'created', 'lastModified'],
        NspError.codes.PRODUCT_UNPROCESSABLE,
        errors
    );
}

function getPrincipalForContentManager (principal, owner) {
    if (owner && owner !== principal.organizationId) {
        principal = {
            organizationId: owner,
            roles: ['ROLE_ASSET_USER']
        };
        return principal;
    } else {
        return principal;
    }
}

function Logic (logger, repositoryAdapter, contentManager, messageBusClient, eventBus) {
    var assetManager = contentManager.assetManager;

    function resolveThumbnail (principal, thing) {
        return assetManager.resolveAssets(principal, [thing.thumbnail.assetId]).then(function (assets) {
            thing.thumbnail.url = assets[0].thumbnail;
        });
    }

    function referenceThumbnail (principal, thing) {
        return assetManager.referenceAssets(principal, [thing.thumbnail.assetId]);
    }

    function switchThumbnailReferences (principal, oldThing, newThing) {
        return assetManager.unreferenceAssets(principal, [oldThing.thumbnail.assetId]).then(function () {
            return assetManager.referenceAssets(principal, [newThing.thumbnail.assetId]);
        });
    }

    function unreferenceThumbnail (principal, thing) {
        return assetManager.unreferenceAssets(principal, [thing.thumbnail.assetId]);
    }

    function removeThingFromCollections (principal, thingId) {
        return messageBusClient.request('collection', 'remove-thing-from-collections', {
            principal: principal,
            uuid: thingId
        });
    }

    function checkCollectionExistence (principal, collectionId) {
        return messageBusClient.request('collection', 'get-collection', { principal: principal, uuid: collectionId });
    }

    function checkSku (thing) {
        return repositoryAdapter.getThingByOwnerAndSku(thing.owner, thing.sku).then(function (dbThing) {
            if (!_.isNull(dbThing) && dbThing.uuid !== thing.uuid) {
                var thingDescription = JSON.stringify(_.pick(dbThing, ['uuid', 'name', 'description']));
                throw new NspError(
                    NspError.codes.DUPLICATED_PRODUCT_SKU,
                    `Duplicated sku "${thing.sku}"`,
                    `It is already used by thing ${thingDescription}`
                );
            }
        });
    }

    this.subscribeTopics = function () {
        logger.verbose('ThingLogic/subscribeTopics');
        var self = this;
        return messageBusClient
            .subscribe('thing', 'get-thing-for-checks', function (data, envelope) {
                self
                    .getThingForChecks(data.principal, data.uuid, data.owner)
                    .then(function (result) {
                        envelope.reply(null, result);
                    })
                    .catch(function (err) {
                        envelope.reply(err);
                    });
            })
            .then(function () {
                messageBusClient.subscribe('thing', 'get-thing', function (data, envelope) {
                    self
                        .getThing(
                            data.principal,
                            _.omitBy(
                                {
                                    uuid: data.uuid,
                                    statusFilter: data.statusFilter
                                },
                                _.isUndefined
                            )
                        )
                        .then(function (result) {
                            envelope.reply(null, result);
                        })
                        .catch(function (err) {
                            envelope.reply(err);
                        });
                });
            })
            .then(function () {
                messageBusClient.subscribe('thing', 'list-things-referencing-collection', function (data, envelope) {
                    self
                        .listThingsReferencingCollection(data.principal, data.uuid)
                        .then(function (result) {
                            envelope.reply(null, result);
                        })
                        .catch(function (err) {
                            envelope.reply(err);
                        });
                });
            });
    };

    this.thingNotFoundErrorFactory = thingNotFoundErrorFactory;

    this.createThing = function (principal, thing) {
        logger.verbose('ThingLogic/createThing');
        return Promise.try(function () {
            var uuidCheck;
            if (_.isString(thing.uuid)) {
                uuidCheck = repositoryAdapter.getThing(thing.uuid).then(function (dbThing) {
                    if (!_.isNull(dbThing)) {
                        throw new NspError(
                            NspError.codes.PRODUCT_ALREADY_EXISTS,
                            'Thing "' + thing.uuid + '" already exists'
                        );
                    }
                });
            } else {
                thing.uuid = uuid.v4();
                uuidCheck = Promise.resolve();
            }
            var collectionCheck;
            if (_.isString(thing.relatedThingsCollectionId)) {
                collectionCheck = checkCollectionExistence(principal, thing.relatedThingsCollectionId);
            } else {
                collectionCheck = Promise.resolve();
            }
            var principal4ContentManager = getPrincipalForContentManager(principal, thing.owner);
            var createdThing;
            return uuidCheck
                .then(function () {
                    return collectionCheck;
                })
                .then(function () {
                    return checkSku(thing);
                })
                .then(function () {
                    return resolveThumbnail(principal4ContentManager, thing);
                })
                .then(function () {
                    return contentManager.createContent(principal4ContentManager, thing.content, localizationSchema);
                })
                .then(function () {
                    return referenceThumbnail(principal4ContentManager, thing);
                })
                .then(function () {
                    var now = new Date();
                    thing.created = now;
                    thing.lastModified = now;
                    return repositoryAdapter.createThing(thing);
                })
                .then(function (thing) {
                    createdThing = thing;
                    return eventBus.publishThingCreatedEvent(createdThing);
                })
                .then(function () {
                    return createdThing;
                });
        });
    };

    /**
     * Get a single thing by uuid
     * @param principal {object} authentication parameter
     * @param principal.organizationId {string} organization id
     * @param p {object} params
     * @param p.uuid {string} thing uuid
     * @param [p.statusFilter] {string} an optional filter on the thing status, cause 404 on non matching
     * @returns {Promise<object>}
     */
    this.getThing = function (principal, p) {
        logger.verbose('ThingLogic/getThing');
        return Promise.try(function () {
            return repositoryAdapter.getThing(p.uuid).then(function (thing) {
                checkExistence(thing, p.uuid);
                checkOwnership(thing, principal);
                checkStatus(p.statusFilter, thing);
                return thing;
            });
        });
    };

    this.getThingForChecks = function (principal, uuid, owner) {
        logger.verbose('ThingLogic/getThingForChecks');
        return Promise.try(function () {
            return repositoryAdapter.getThingForChecks(uuid).then(function (thing) {
                checkExistence(thing, uuid);
                checkOwnership(thing, principal, owner);
                return thing;
            });
        });
    };

    this.updateThing = function (principal, uuid, newThing) {
        logger.verbose('ThingLogic/updateThing');
        return Promise.try(function () {
            var oldThing;
            var updatedThing;
            return repositoryAdapter
                .getThing(uuid)
                .then(function (thing) {
                    oldThing = thing;
                    checkExistence(oldThing, uuid);
                    checkOwnership(oldThing, principal);
                    checkUpdate(oldThing, newThing, principal);
                })
                .then(function () {
                    return checkSku(newThing);
                })
                .then(function () {
                    if (
                        !_.isUndefined(newThing.relatedThingsCollectionId) &&
                        newThing.relatedThingsCollectionId !== oldThing.relatedThingsCollectionId
                    ) {
                        return checkCollectionExistence(principal, newThing.relatedThingsCollectionId);
                    }
                })
                .then(function () {
                    var principal4ContentManager = getPrincipalForContentManager(principal, newThing.owner);
                    if (newThing.thumbnail.assetId === oldThing.thumbnail.assetId) {
                        return contentManager.updateContent(
                            principal4ContentManager,
                            oldThing.content,
                            newThing.content,
                            localizationSchema
                        );
                    } else {
                        return resolveThumbnail(principal, newThing)
                            .then(function () {
                                return contentManager.updateContent(
                                    principal4ContentManager,
                                    oldThing.content,
                                    newThing.content,
                                    localizationSchema
                                );
                            })
                            .then(function () {
                                return switchThumbnailReferences(principal4ContentManager, oldThing, newThing);
                            });
                    }
                })
                .then(function () {
                    newThing.lastModified = new Date();
                    return repositoryAdapter.updateThing(newThing);
                })
                .then(function (thing) {
                    updatedThing = thing;
                    return eventBus.publishThingUpdatedEvent(oldThing, updatedThing);
                })
                .then(function () {
                    return updatedThing;
                });
        });
    };

    this.deleteThing = function (principal, uuid) {
        logger.verbose('ThingLogic/deleteThing');
        return Promise.try(function () {
            var thingToDelete;
            var principal4ContentManager;
            var deletedThing;
            return repositoryAdapter
                .getThing(uuid)
                .then(function (thing) {
                    checkExistence(thing, uuid);
                    checkOwnership(thing, principal);
                    thingToDelete = thing;
                    principal4ContentManager = getPrincipalForContentManager(principal, thingToDelete.owner);
                    return contentManager.deleteContent(principal4ContentManager, thing.content, localizationSchema);
                })
                .then(function () {
                    return unreferenceThumbnail(principal4ContentManager, thingToDelete);
                })
                .then(function () {
                    return removeThingFromCollections(principal, uuid);
                })
                .then(function () {
                    return repositoryAdapter.deleteThing(thingToDelete);
                })
                .then(function (thing) {
                    deletedThing = thing;
                    return eventBus.publishThingDeletedEvent(thingToDelete);
                })
                .then(function () {
                    return deletedThing;
                });
        });
    };

    /**
     * List all things
     * @param principal {object} authentication parameter
     * @param principal.organizationId {string} organization id
     * @param [p] {object} params
     * @param [p.owner] {string} an optional filter on the thing owner
     * @param [p.statusFilter] {string} an optional filter on the thing status
     * @returns {Promise<object>}
     */
    this.listThings = function (principal, p) {
        logger.verbose('ThingLogic/listThings');
        if (_.isUndefined(p)) {
            p = {};
        }
        return Promise.try(function () {
            return repositoryAdapter.listThings(
                _.omitBy(
                    {
                        owner: p.owner,
                        statusFilter: p.statusFilter
                    },
                    _.isUndefined
                )
            );
        });
    };

    /**
     * List all things referencing an asset
     * @param principal {object} authentication parameter
     * @param principal.organizationId {string} organization id
     * @param p {object} params
     * @param p.assetId {string} id of the asset referenced
     * @param [p.owner] {string} an optional filter on the owner
     * @param [p.statusFilter] {string} an optional filter on the thing status
     * @returns {Promise<object>}
     */
    this.listThingsReferencingAsset = function (principal, p) {
        logger.verbose('ThingLogic/listThingsReferencingAsset');
        return Promise.try(function () {
            return repositoryAdapter.listThingsReferencingAsset(
                _.omitBy(
                    {
                        owner: p.owner,
                        assetId: p.assetId,
                        statusFilter: p.statusFilter
                    },
                    _.isUndefined
                )
            );
        });
    };

    /**
     * Search all things with one or more tags
     * @param principal {object} authentication parameter
     * @param principal.organizationId {string} organization id
     * @param p {object} params
     * @param [p.tags] {string[]} the thing tags to match
     * @param [p.locale] {string} the locale to use to match the tag
     * @param [p.owner] {string} an optional filter on the owner
     * @param [p.statusFilter] {string} an optional filter on the thing status
     * @returns {Promise<object>}
     */
    this.searchThingsByTags = function (principal, p) {
        logger.verbose('ThingLogic/searchThingsByTags');
        return Promise.try(function () {
            return repositoryAdapter.searchThingsByTags(
                _.omitBy(
                    {
                        owner: p.owner,
                        tags: p.tags,
                        locale: p.locale,
                        statusFilter: p.statusFilter
                    },
                    _.isUndefined
                )
            );
        });
    };

    this.listThingsReferencingCollection = function (principal, collectionId) {
        logger.verbose('ThingLogic/listThingsReferencingCollection');
        return Promise.try(function () {
            return repositoryAdapter.listThingsReferencingCollection(principal.organizationId, collectionId);
        });
    };
}

Logic.$inject = ['logger', 'thing.repository-adapter', 'content-manager', 'message-bus-client', 'eventbus'];

module.exports = Logic;
