'use strict';

var Promise = require('bluebird'),
    NspError = require('../errors.js').NspError,
    _ = require('lodash');

function Repository (logger, db) {

    function collectionName () {
        return 'things';
    }

    this.createThing = function (thing) {
        logger.verbose('Repository/createThing', { thing: thing });
        return Promise.try(function () {
            if (!_.isString(thing._id) || thing._id.length === 0) {
                throw new NspError(NspError.codes.INTERNAL_SERVER_ERROR,
                    'cannot insert document with no uuid / invalid uuid');
            }
            return db.insertOne(collectionName(), thing)
                .then(function (result) {
                    var output = _.cloneDeep(thing);
                    if (output._id !== result.insertedId) {
                        var errMsg = 'inserted document uuid does not match requested uuid: ' +
                            'got "' + result.insertedId + '", ' +
                            'expected: "' + thing._id + '"';
                        throw new NspError(NspError.codes.INTERNAL_SERVER_ERROR, errMsg);
                    }
                    return output;
                });
        });
    };
    this.getThing = function (uuid) {
        logger.verbose('Repository/getThing', { uuid: uuid });
        return Promise.try(function () {
            return db.findOne(collectionName(), { _id: uuid });
        });
    };
    this.getThingByOwnerAndSku = function (owner, sku) {
        logger.verbose('Repository/getThingByOwnerAndSku', { owner: owner, sku: sku });
        return Promise.try(function () {
            return db.findOne(collectionName(), { owner: owner, sku: sku });
        });
    };
    this.getThingForChecks = function (uuid) {
        logger.verbose('Repository/getThingForChecks', { uuid: uuid });
        return Promise.try(function () {
            return db.findOne(collectionName(), { _id: uuid }, { owner: 1 });
        });
    };
    this.updateThing = function (replacementThing) {
        logger.verbose('Repository/updateThing', { newThing: replacementThing });
        return Promise.try(function () {
            if (_.isUndefined(replacementThing._id)) {
                throw new NspError(NspError.codes.INTERNAL_SERVER_ERROR, 'can\'t update document with unknown uuid');
            }
            return db.findOneAndReplace(collectionName(),
                { _id: replacementThing._id }, replacementThing, { returnOriginal: false })
                .then(function (result) {
                    if (_.isNull(result.value)) {
                        throw new NspError(NspError.codes.INTERNAL_SERVER_ERROR,
                            'can\'t replace document with uuid ' + replacementThing._id + ', not found');
                    }
                    return result.value;
                });
        });
    };
    this.deleteThing = function (thingToDelete) {
        logger.verbose('Repository/deleteThing', { thingToDelete: thingToDelete });
        return Promise.try(function () {
            if (_.isUndefined(thingToDelete._id)) {
                throw new NspError(NspError.codes.INTERNAL_SERVER_ERROR,
                    'can\'t delete document with unknown uuid');
            }
            return db.deleteOne(collectionName(), { _id: thingToDelete._id })
                .then(function (result) {
                    if (result.deletedCount === 0) {
                        throw new NspError(NspError.codes.INTERNAL_SERVER_ERROR,
                            'can\'t delete document with uuid ' + thingToDelete._id + ', not found');
                    }
                    if (result.deletedCount > 1) {
                        logger.warn('Repository/deleteThing deleted more then one document', {
                            _id: thingToDelete._id,
                            deletedCount: result.deletedCount
                        });
                    }
                    return {};
                });
        });
    };
    /**
     * List all things
     * @param p {object} params
     * @param [p.owner] {string} an optional filter on the thing owner
     * @param [p.statusFilter] {string} an optional filter on the thing status
     * @returns {Promise<object>}
     */
    this.listThings = function (p) {
        logger.verbose('Repository/listThings', { params: p });
        return Promise.try(function () {
            return db.find(collectionName(), _.omitBy({
                owner: p.owner,
                status: p.statusFilter
            }, _.isUndefined))
                .then(function (cursor) {
                    return cursor.toArray();
                });
        });
    };
    /**
     * List all things referencing an asset
     * @param p {object} params
     * @param p.assetId {string} id of the asset referenced
     * @param [p.owner] {string} an optional filter on the thing owner
     * @param [p.statusFilter] {string} an optional filter on the thing status
     * @returns {Promise<object>}
     */
    this.listThingsReferencingAsset = function (p) {
        var query = _.omitBy({
            owner: p.owner,
            $or: [
                { 'thumbnail.assetId': p.assetId },
                { 'content.imageList.asset.uuid': p.assetId },
                { 'content.audioList.asset.uuid': p.assetId },
                { 'content.videoList.asset.uuid': p.assetId }
            ],
            status: p.statusFilter
        }, _.isUndefined);
        logger.verbose('Repository/listThingsReferencingAsset', query);
        return Promise.try(function () {
            return db.find(collectionName(), query)
                .then(function (cursor) {
                    return cursor.toArray();
                });
        });
    };
    /**
     * Search all things with one or more tags
     * @param p {object} params
     * @param [p.tags] {string[]} the thing tags to match
     * @param [p.locale] {string} the locale to use to match the tag
     * @param [p.owner] {string} an optional filter on the thing owner
     * @param [p.statusFilter] {string} an optional filter on the thing status
     * @returns {Promise<object>}
     */
    this.searchThingsByTags = function (p) {
        var query = _.omitBy({
            owner: p.owner,
            status: p.statusFilter
        }, _.isUndefined);
        if (!_.isUndefined(p.tags) || !_.isUndefined(p.locale)) {
            query.content = {
                $elemMatch: {}
            };
            if (!_.isUndefined(p.tags)) {
                query.content.$elemMatch['tagList.text'] = {
                    $in: p.tags
                };
            }
            if (!_.isUndefined(p.locale)) {
                query.content.$elemMatch.locale = p.locale;
            }
        }
        logger.verbose('Repository/searchThingsByTags', query);
        return Promise.try(function () {
            return db.find(collectionName(), query)
                .then(function (cursor) {
                    return cursor.toArray();
                });
        });
    };

    this.listThingsReferencingCollection = function (owner, collectionId) {
        var query = {
            owner: owner,
            relatedThingsCollectionId: collectionId
        };
        var projection = {
            name: 1,
            description: 1
        };
        logger.verbose('Repository/listThingsReferencingCollection', query);
        return Promise.try(function () {
            return db.find(collectionName(), query, projection)
                .then(function (cursor) {
                    return cursor.toArray();
                });
        });
    };
}

Repository.$inject = ['logger', 'db-client'];

module.exports = Repository;
