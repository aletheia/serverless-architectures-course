'use strict';

var Commons = require('@neosperience/nsp-service-commons-lib'),
    intravenous = require('intravenous');

require('./errors.js');

function addCommonServices (container, awsClient, config) {
    container.register('db-client', require('./db-client.js'), 'singleton');
    container.register('db-client.config', config.database);
    if (awsClient) {
        container.register('aws-client', awsClient);
    }
}

function addThingServices (container) {
    container.register('thing.authorizer', require('./thing/authorizer.js'), 'singleton');
    container.register('thing.logic', require('./thing/logic.js'), 'singleton');
    container.register('thing.repository-adapter', require('./thing/repository-adapter.js'));
    container.register('thing.repository', require('./thing/repository.js'));
}

function addCollectionServices (container) {
    container.register('collection.authorizer', require('./collection/authorizer.js'), 'singleton');
    container.register('collection.logic', require('./collection/logic.js'), 'singleton');
    container.register('collection.repository-adapter', require('./collection/repository-adapter.js'));
    container.register('collection.repository', require('./collection/repository.js'));
}

function addContentManagerServices (container, lambdaClient, config) {
    container.register('content-manager', require('@neosperience/nsp-content-manager'));
    container.register('content-manager.config', config.contentManager);
    if (lambdaClient) {
        container.register('content-manager.lambda-client', lambdaClient);
    }
}

function subscribeTopics (container) {
    container.get('thing.logic').subscribeTopics();
    container.get('collection.logic').subscribeTopics();
}

function Container (lambdaClient) {

    var container = intravenous.create({
        onDispose: function (obj) {
            obj.dispose();
        }
    });

    var config = new Commons.Config('./config', 'ENV').get();
    var logger = new Commons.Logger(config.logger);
    container.register('logger', logger);

    addCommonServices(container, lambdaClient, config);
    addThingServices(container);
    addCollectionServices(container);
    addContentManagerServices(container, lambdaClient, config);
    subscribeTopics(container);

    container.shutdown = function () {
        var logger = container.get('logger');
        logger.verbose('Container/shutdown');
        return container.get('message-bus-client').dispose()
            .then (function () {
                return container.get('db-client').dispose();
            })
            .catch(function (err) {
                logger.error('Error shutting down container:\n' + JSON.stringify(err));
            });
    };

    return container;
}

module.exports = Container;
