'use strict';

require('jasmine-expect');
