'use strict';

var Commons = require('@neosperience/nsp-service-commons-lib'),
    Errors = require('../../src/errors.js');

var NspError = Errors.NspError;
var HttpError = Errors.HttpError;

describe('Errors', function () {
    it('should export Commons.NspError as NspError', function () {
        expect(NspError).toBe(Commons.NspError);
    });
    it('should export Commons.HttpError as HttpError', function () {
        expect(HttpError).toBeFunction(Commons.HttpError);
    });
    it('should add the expected codes to NspError.codes', function () {
        expect(NspError.codes).toEqual(jasmine.objectContaining({
            PRODUCT_NOT_FOUND: 'PRODUCT_NOT_FOUND',
            PRODUCT_UNPROCESSABLE: 'PRODUCT_UNPROCESSABLE',
            PRODUCT_ALREADY_EXISTS: 'PRODUCT_ALREADY_EXISTS',
            DUPLICATED_PRODUCT_SKU: 'DUPLICATED_PRODUCT_SKU',
            COLLECTION_NOT_FOUND: 'COLLECTION_NOT_FOUND',
            COLLECTION_UNPROCESSABLE: 'COLLECTION_UNPROCESSABLE',
            COLLECTION_ALREADY_EXISTS: 'COLLECTION_ALREADY_EXISTS',
            CANNOT_DELETE_COLLECTION: 'CANNOT_DELETE_COLLECTION',
        }));
    });
    it('should add the expected mapping to HttpError.nspErrorMapping', function () {
        var mapping = {};
        mapping[NspError.codes.PRODUCT_NOT_FOUND] = HttpError.statusCodes.NOT_FOUND;
        mapping[NspError.codes.PRODUCT_UNPROCESSABLE] = HttpError.statusCodes.UNPROCESSABLE_ENTITY;
        mapping[NspError.codes.PRODUCT_ALREADY_EXISTS] = HttpError.statusCodes.CONFLICT;
        mapping[NspError.codes.DUPLICATED_PRODUCT_SKU] = HttpError.statusCodes.CONFLICT;
        mapping[NspError.codes.COLLECTION_NOT_FOUND] = HttpError.statusCodes.NOT_FOUND;
        mapping[NspError.codes.COLLECTION_UNPROCESSABLE] = HttpError.statusCodes.UNPROCESSABLE_ENTITY;
        mapping[NspError.codes.COLLECTION_ALREADY_EXISTS] = HttpError.statusCodes.CONFLICT;
        mapping[NspError.codes.CANNOT_DELETE_COLLECTION] = HttpError.statusCodes.CONFLICT;
        expect(HttpError.nspErrorMapping).toEqual(jasmine.objectContaining(mapping));
    });
});
