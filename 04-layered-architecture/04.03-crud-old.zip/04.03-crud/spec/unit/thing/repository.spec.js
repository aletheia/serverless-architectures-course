'use strict';

var _ = require('lodash'),
    helper = require('../../helper'),
    NspError = require('../../../src/errors.js').NspError,
    Promise = require('bluebird'),
    Repository = require('../../../src/thing/repository.js');

describe('Thing Repository [Unit]', function () {
    var uuid, owner, sku, assetId,
        thing, replaceThing,
        cursor, db, logger, sut;
    beforeEach(function () {
        uuid = '3305ea8b-4f0d-422b-a1e2-e7ba27122c0c';
        owner = 'ORG001';
        sku = 'AC-0165';
        assetId = '61bc3863-5f81-4152-91d3-56ea7aed0391';
        thing = {
            _id: uuid,
            owner: owner,
            something: 'something'
        };
        replaceThing = {
            _id: uuid,
            owner: owner,
            something: 'something new'
        };
        cursor = {
            sort: function () {
                return cursor;
            },
            toArray: function () {
            }
        };
        db = {
            insertOne: function () {
            },
            find: function () {
            },
            findOne: function () {
            },
            findOneAndReplace: function () {
            },
            deleteOne: function () {
            }
        };
        logger = helper.getLoggerMock();
        sut = new Repository(logger, db);
    });
    describe('createThing()', function () {
        var createSuccess;
        beforeEach(function () {
            createSuccess = {
                insertedCount: 1,
                ops: [
                    {
                        _id: uuid,
                        owner: owner
                    }
                ],
                insertedId: uuid,
                raw: { 'n': 1, 'ok': 1 }
            };
        });
        it('should use the db to create a thing specifying the collection name', function () {
            spyOn(db, 'insertOne').and.returnValue(Promise.resolve(_.cloneDeep(createSuccess)));
            return sut.createThing(thing)
                .then(function () {
                    expect(db.insertOne).toHaveBeenCalled();
                    expect(db.insertOne.calls.mostRecent().args[0]).toBe('things');
                    expect(db.insertOne.calls.mostRecent().args[1]).toBe(thing);
                });
        });
        it('should return a thing', function () {
            spyOn(db, 'insertOne').and.returnValue(Promise.resolve(_.cloneDeep(createSuccess)));
            return sut.createThing(thing)
                .then(function (result) {
                    expect(result).toEqual(jasmine.objectContaining(thing));
                });
        });
        it('should not edit the input thing', function () {
            spyOn(db, 'insertOne').and.returnValue(Promise.resolve(_.cloneDeep(createSuccess)));
            var backup = _.cloneDeep(thing);
            return sut.createThing(thing)
                .then(function (result) {
                    expect(result).not.toBe(thing);
                    expect(thing).toEqual(backup);
                });
        });
        it('should throw if the _id is missing', function () {
            // this is to force a check
            spyOn(db, 'insertOne').and.returnValue(Promise.resolve(_.cloneDeep(createSuccess)));
            var noIdThing = _.clone(thing);
            delete noIdThing._id;
            return sut.createThing(noIdThing)
                .then(helper.thenFail)
                .catch(function (err) {
                    expect(err.code).toBe(NspError.codes.INTERNAL_SERVER_ERROR);
                    expect(err.message).toBe('cannot insert document with no uuid / invalid uuid');
                });
        });
        it('should throw if the _id on the created thing does not match the one provided', function () {
            // this is to force a check
            var fakeSuccess = _.cloneDeep(createSuccess);
            fakeSuccess.insertedId = 'not-original-id';
            spyOn(db, 'insertOne').and.returnValue(Promise.resolve(fakeSuccess));
            return sut.createThing(thing)
                .then(helper.thenFail)
                .catch(function (err) {
                    expect(err.code).toBe(NspError.codes.INTERNAL_SERVER_ERROR);
                    expect(err.message)
                        .toBe('inserted document uuid does not match requested uuid: got "not-original-id",' +
                            ' expected: "' + uuid + '"');
                });
        });
        it('should propagate any error of the db', function () {
            spyOn(db, 'insertOne').and.returnValue(Promise.reject(new Error('dummy')));
            return sut.createThing(thing)
                .then(helper.thenFail)
                .catch(function (err) {
                    expect(err.message).toBe('dummy');
                });
        });
    });
    describe('getThing()', function () {
        it('should get the thing from the db specifying the collection', function () {
            spyOn(db, 'findOne').and.returnValue(Promise.resolve(_.cloneDeep(thing)));
            return sut.getThing(uuid)
                .then(function () {
                    expect(db.findOne).toHaveBeenCalledWith('things', { _id: uuid });
                });
        });
        it('should return the thing provided by the database', function () {
            var output = _.cloneDeep(thing);
            spyOn(db, 'findOne').and.returnValue(Promise.resolve(output));
            return sut.getThing(uuid)
                .then(function (result) {
                    expect(result).toBe(output);
                });
        });
        it('it should resolve with null if no thing has been found', function () {
            spyOn(db, 'findOne').and.returnValue(Promise.resolve(null));
            return sut.getThing(uuid)
                .then(function (result) {
                    expect(result).toBeNull();
                });
        });
        it('should propagate any error of the db', function () {
            spyOn(db, 'findOne').and.returnValue(Promise.reject(new Error('dummy')));
            return sut.getThing(uuid)
                .then(helper.thenFail)
                .catch(function (err) {
                    expect(err.message).toBe('dummy');
                });
        });
    });
    describe('getThingByOwnerAndSku()', function () {
        it('should get the thing from the db specifying the collection', function () {
            spyOn(db, 'findOne').and.returnValue(Promise.resolve(_.cloneDeep(thing)));
            return sut.getThingByOwnerAndSku(owner, sku)
                .then(function () {
                    expect(db.findOne).toHaveBeenCalledWith('things', { owner: owner, sku: sku });
                });
        });
        it('should return the thing provided by the database', function () {
            var output = _.cloneDeep(thing);
            spyOn(db, 'findOne').and.returnValue(Promise.resolve(output));
            return sut.getThingByOwnerAndSku(owner, sku)
                .then(function (result) {
                    expect(result).toBe(output);
                });
        });
        it('it should resolve with null if no thing has been found', function () {
            spyOn(db, 'findOne').and.returnValue(Promise.resolve(null));
            return sut.getThingByOwnerAndSku(owner, sku)
                .then(function (result) {
                    expect(result).toBeNull();
                });
        });
        it('should propagate any error of the db', function () {
            spyOn(db, 'findOne').and.returnValue(Promise.reject(new Error('dummy')));
            return sut.getThingByOwnerAndSku(owner, sku)
                .then(helper.thenFail)
                .catch(function (err) {
                    expect(err.message).toBe('dummy');
                });
        });
    });
    describe('getThingForChecks()', function () {
        it('should get the thing from the db specifying the collection, the query and the projection', function () {
            spyOn(db, 'findOne').and.returnValue(Promise.resolve(_.cloneDeep(thing)));
            return sut.getThingForChecks(uuid)
                .then(function () {
                    expect(db.findOne).toHaveBeenCalledWith('things', { _id: uuid }, { owner: 1 });
                });
        });
        it('should return the thing provided by the database', function () {
            var output = _.cloneDeep(thing);
            delete output.something;
            spyOn(db, 'findOne').and.returnValue(Promise.resolve(output));
            return sut.getThingForChecks(uuid)
                .then(function (result) {
                    expect(result).toEqual(output);
                });
        });
        it('it should resolve with null if no thing has been found', function () {
            spyOn(db, 'findOne').and.returnValue(Promise.resolve(null));
            return sut.getThingForChecks(uuid)
                .then(function (result) {
                    expect(result).toBeNull();
                });
        });
        it('should propagate any error of the db', function () {
            spyOn(db, 'findOne').and.returnValue(Promise.reject(new Error('dummy')));
            return sut.getThingForChecks(uuid)
                .then(helper.thenFail)
                .catch(function (err) {
                    expect(err.message).toBe('dummy');
                });
        });
    });
    describe('updateThing()', function () {
        var replaceSuccess, replaceFailed;
        beforeEach(function () {
            replaceSuccess = {
                value: replaceThing,
                lastErrorObject: { 'updatedExisting': true, 'n': 1 },
                ok: 1
            };
            replaceFailed = {
                value: null,
                lastErrorObject: { 'updatedExisting': false, 'n': 0 },
                ok: 1
            };
        });
        it('should throw if the thing has no _id', function () {
            spyOn(db, 'findOneAndReplace').and.returnValue(Promise.resolve(_.cloneDeep(replaceFailed)));
            var noIdThing = _.clone(thing);
            delete noIdThing._id;
            return sut.updateThing(noIdThing)
                .then(helper.thenFail)
                .catch(function (err) {
                    expect(err.code).toBe(NspError.codes.INTERNAL_SERVER_ERROR);
                    expect(err.message).toBe('can\'t update document with unknown uuid');
                });
        });
        it('should call the db findOneAndReplace specifying the collection', function () {
            spyOn(db, 'findOneAndReplace').and.returnValue(Promise.resolve(_.cloneDeep(replaceSuccess)));
            return sut.updateThing(_.cloneDeep(replaceThing))
                .then(function () {
                    expect(db.findOneAndReplace).toHaveBeenCalled();
                    expect(db.findOneAndReplace.calls.mostRecent().args[0]).toBe('things');
                    expect(db.findOneAndReplace.calls.mostRecent().args[1]).toEqual({ _id: replaceThing._id });
                    expect(db.findOneAndReplace.calls.mostRecent().args[2]).toEqual(replaceThing);
                });
        });
        it('should call the db findOneAndReplace passing the _id and option to return the new value', function () {
            spyOn(db, 'findOneAndReplace').and.returnValue(Promise.resolve(_.cloneDeep(replaceSuccess)));
            return sut.updateThing(_.cloneDeep(replaceThing))
                .then(function () {
                    expect(db.findOneAndReplace).toHaveBeenCalled();
                    expect(db.findOneAndReplace.calls.mostRecent().args[1]).toEqual({ _id: replaceThing._id });
                    expect(db.findOneAndReplace.calls.mostRecent().args[2]).toEqual(replaceThing);
                    expect(db.findOneAndReplace.calls.mostRecent().args[3]).toEqual({ returnOriginal: false });
                });
        });
        it('should return the replaced thing', function () {
            spyOn(db, 'findOneAndReplace').and.returnValue(Promise.resolve(_.cloneDeep(replaceSuccess)));
            return sut.updateThing(_.cloneDeep(replaceThing))
                .then(function (result) {
                    expect(result).toEqual(replaceThing);
                });
        });
        it('should not modify the input thing', function () {
            spyOn(db, 'findOneAndReplace').and.returnValue(Promise.resolve(_.cloneDeep(replaceSuccess)));
            var backupCopy = _.cloneDeep(replaceThing);
            return sut.updateThing(replaceThing)
                .then(function () {
                    expect(replaceThing).toEqual(backupCopy);
                });
        });
        it('should throw if no thing has been found with a matching _id', function () {
            spyOn(db, 'findOneAndReplace').and.returnValue(Promise.resolve(replaceFailed));
            return sut.updateThing(replaceThing)
                .then(helper.thenFail)
                .catch(function (err) {
                    expect(err.code).toBe(NspError.codes.INTERNAL_SERVER_ERROR);
                    expect(err.message).toBe('can\'t replace document with uuid ' + replaceThing._id + ', not found');
                });
        });
        it('should propagate any error of the db', function () {
            spyOn(db, 'findOneAndReplace').and.returnValue(Promise.reject(new Error('dummy')));
            return sut.updateThing(replaceThing)
                .then(helper.thenFail)
                .catch(function (err) {
                    expect(err.message).toBe('dummy');
                });
        });
    });
    describe('deleteThing()', function () {
        var deleteSuccess, deleteFailed, deleteTooMany;
        beforeEach(function () {
            deleteSuccess = {
                deletedCount: 1,
                raw: { 'n': 1, 'ok': 1 }
            };
            deleteFailed = {
                deletedCount: 0,
                raw: { 'n': 0, 'ok': 1 }
            };
            deleteTooMany = {
                deletedCount: 2,
                raw: { n: 2, ok: 1 }
            };
        });
        it('should throw if the input thing has no _id', function () {
            spyOn(db, 'deleteOne').and.returnValue(Promise.resolve(deleteFailed));
            var noIdThing = _.clone(thing);
            delete noIdThing._id;
            return sut.deleteThing(noIdThing)
                .then(helper.thenFail)
                .catch(function (err) {
                    expect(err.code).toBe(NspError.codes.INTERNAL_SERVER_ERROR);
                    expect(err.message).toBe('can\'t delete document with unknown uuid');
                });
        });
        it('should delete call the db to delete the thing specifying the collection', function () {
            spyOn(db, 'deleteOne').and.returnValue(Promise.resolve(deleteSuccess));
            return sut.deleteThing(_.cloneDeep(thing))
                .then(function () {
                    expect(db.deleteOne).toHaveBeenCalled();
                    expect(db.deleteOne.calls.mostRecent().args[0]).toBe('things');
                    expect(db.deleteOne.calls.mostRecent().args[1]).toEqual({ _id: thing._id });
                });
        });
        it('should delete call the db to delete the thing using the _id of the input thing', function () {
            spyOn(db, 'deleteOne').and.returnValue(Promise.resolve(deleteSuccess));
            return sut.deleteThing(_.cloneDeep(thing))
                .then(function () {
                    expect(db.deleteOne).toHaveBeenCalled();
                    expect(db.deleteOne.calls.mostRecent().args[1]).toEqual({ _id: thing._id });
                });
        });
        it('should return an empty object on thing successfully deleted', function () {
            spyOn(db, 'deleteOne').and.returnValue(Promise.resolve(deleteSuccess));
            return sut.deleteThing(_.cloneDeep(thing))
                .then(function (result) {
                    expect(result).toBeEmptyObject();
                });
        });
        it('should throw if the thing could not be deleted (not found)', function () {
            spyOn(db, 'deleteOne').and.returnValue(Promise.resolve(deleteFailed));
            return sut.deleteThing(thing)
                .then(helper.thenFail)
                .catch(function (err) {
                    expect(err.code).toBe(NspError.codes.INTERNAL_SERVER_ERROR);
                    expect(err.message).toBe('can\'t delete document with uuid ' + thing._id + ', not found');
                });
        });
        it('should log warning if the db deletes more then one document', function () {
            spyOn(db, 'deleteOne').and.returnValue(Promise.resolve(deleteTooMany));
            spyOn(logger, 'warn');
            return sut.deleteThing(thing)
                .then(function (result) {
                    expect(result).toBeEmptyObject();
                    expect(logger.warn).toHaveBeenCalledWith(
                        'Repository/deleteThing deleted more then one document',
                        { _id: thing._id, deletedCount: deleteTooMany.deletedCount }
                    );
                });
        });
        it('should propagate any error of the db', function () {
            spyOn(db, 'deleteOne').and.returnValue(Promise.reject(new Error('dummy')));
            return sut.deleteThing(replaceThing)
                .then(helper.thenFail)
                .catch(function (err) {
                    expect(err.message).toBe('dummy');
                });
        });
    });
    describe('listThings()', function () {
        var listResult;
        beforeEach(function () {
            listResult = [
                thing,
                {
                    _id: 'anotherResult',
                    otherKey: 'otherValue'
                }
            ];
        });
        it('should call the DB to obtain the cursor specifying the collection', function () {
            spyOn(db, 'find').and.returnValue(Promise.resolve(cursor));
            spyOn(cursor, 'toArray').and.returnValue(Promise.resolve(listResult));
            return sut.listThings({ owner: owner })
                .then(function () {
                    expect(db.find).toHaveBeenCalled();
                    expect(db.find.calls.mostRecent().args[0]).toBe('things');
                });
        });
        it('should call the DB to obtain the cursor specifying the owner', function () {
            spyOn(db, 'find').and.returnValue(Promise.resolve(cursor));
            spyOn(cursor, 'toArray').and.returnValue(Promise.resolve(listResult));
            return sut.listThings({ owner: owner })
                .then(function () {
                    expect(db.find).toHaveBeenCalled();
                    expect(db.find.calls.mostRecent().args[1]).toEqual({ owner: owner });
                });
        });
        it('should convert the cursor into an array (kinda testing implementation)', function () {
            spyOn(db, 'find').and.returnValue(Promise.resolve(cursor));
            spyOn(cursor, 'toArray').and.returnValue(Promise.resolve(listResult));
            return sut.listThings({ owner: owner })
                .then(function () {
                    expect(db.find).toHaveBeenCalled();
                    expect(cursor.toArray).toHaveBeenCalled();
                });
        });
        it('should return the array', function () {
            spyOn(db, 'find').and.returnValue(Promise.resolve(cursor));
            spyOn(cursor, 'toArray').and.returnValue(Promise.resolve(listResult));
            return sut.listThings({ owner: owner })
                .then(function (result) {
                    expect(result).toBe(listResult);
                });
        });
        it('should propagate any error of the db', function () {
            spyOn(db, 'find').and.callFake(function (collection, filter) {
                if (filter.owner === 'testingFind') {
                    return Promise.reject(new Error('dummyFind'));
                }
                return Promise.resolve(cursor);
            });
            spyOn(cursor, 'toArray').and.returnValue(Promise.reject(new Error('dummyCursor')));
            var findTest = sut.listThings({ owner: 'testingFind' })
                .then(helper.thenFail)
                .catch(function (err) {
                    expect(err.message).toBe('dummyFind');
                });
            var cursorTest = sut.listThings({ owner: 'testingCursor' })
                .then(helper.thenFail)
                .catch(function (err) {
                    expect(err.message).toBe('dummyCursor');
                });
            return Promise.all([ findTest, cursorTest ]);
        });
        it('should call the DB to filtering by status if statusFilter is specified', function () {
            spyOn(db, 'find').and.returnValue(Promise.resolve(cursor));
            spyOn(cursor, 'toArray').and.returnValue(Promise.resolve(listResult));
            return sut.listThings({ owner: owner, statusFilter: 'a-status' })
                .then(function () {
                    expect(db.find).toHaveBeenCalled();
                    expect(db.find.calls.mostRecent().args[1])
                        .toEqual(jasmine.objectContaining({ status: 'a-status' }));
                });
        });
    });
    describe('listThingsReferencingAsset()', function () {
        var listResult;
        beforeEach(function () {
            listResult = [
                thing,
                {
                    _id: 'anotherResult',
                    otherKey: 'otherValue'
                }
            ];
        });
        it('should call the DB to obtain the cursor specifying the collection', function () {
            spyOn(db, 'find').and.returnValue(Promise.resolve(cursor));
            spyOn(cursor, 'toArray').and.returnValue(Promise.resolve(listResult));
            return sut.listThingsReferencingAsset({ owner: owner, assetId: assetId })
                .then(function () {
                    expect(db.find).toHaveBeenCalled();
                    expect(db.find.calls.mostRecent().args[0]).toBe('things');
                });
        });
        it('should call the DB to obtain the cursor specifying the right query', function () {
            var query = {
                owner: owner,
                $or: [
                    { 'thumbnail.assetId': assetId },
                    { 'content.imageList.asset.uuid': assetId },
                    { 'content.audioList.asset.uuid': assetId },
                    { 'content.videoList.asset.uuid': assetId }
                ]
            };
            spyOn(db, 'find').and.returnValue(Promise.resolve(cursor));
            spyOn(cursor, 'toArray').and.returnValue(Promise.resolve(listResult));
            return sut.listThingsReferencingAsset({ owner: owner, assetId: assetId })
                .then(function () {
                    expect(db.find).toHaveBeenCalled();
                    expect(db.find.calls.mostRecent().args[1]).toEqual(query);
                });
        });
        it('should convert the cursor into an array (kinda testing implementation)', function () {
            spyOn(db, 'find').and.returnValue(Promise.resolve(cursor));
            spyOn(cursor, 'toArray').and.returnValue(Promise.resolve(listResult));
            return sut.listThingsReferencingAsset({ owner: owner, assetId: assetId })
                .then(function () {
                    expect(db.find).toHaveBeenCalled();
                    expect(cursor.toArray).toHaveBeenCalled();
                });
        });
        it('should return the array', function () {
            spyOn(db, 'find').and.returnValue(Promise.resolve(cursor));
            spyOn(cursor, 'toArray').and.returnValue(Promise.resolve(listResult));
            return sut.listThingsReferencingAsset({ owner: owner })
                .then(function (result) {
                    expect(result).toBe(listResult);
                });
        });
        it('should propagate any error of the db', function () {
            spyOn(db, 'find').and.callFake(function (collection, filter) {
                if (filter.owner === 'testingFind') {
                    return Promise.reject(new Error('dummyFind'));
                }
                return Promise.resolve(cursor);
            });
            spyOn(cursor, 'toArray').and.returnValue(Promise.reject(new Error('dummyCursor')));
            var findTest = sut.listThingsReferencingAsset({ owner: 'testingFind', assetId: assetId })
                .then(helper.thenFail)
                .catch(function (err) {
                    expect(err.message).toBe('dummyFind');
                });
            var cursorTest = sut.listThingsReferencingAsset({ owner: 'testingCursor', assetId: assetId })
                .then(helper.thenFail)
                .catch(function (err) {
                    expect(err.message).toBe('dummyCursor');
                });
            return Promise.all([ findTest, cursorTest ]);
        });
        it('should call the DB to filtering by status if statusFilter is specified', function () {
            spyOn(db, 'find').and.returnValue(Promise.resolve(cursor));
            spyOn(cursor, 'toArray').and.returnValue(Promise.resolve(listResult));
            return sut.listThingsReferencingAsset({ owner: owner, assetId: assetId, statusFilter: 'a-status' })
                .then(function () {
                    expect(db.find).toHaveBeenCalled();
                    expect(db.find.calls.mostRecent().args[1])
                        .toEqual(jasmine.objectContaining({ status: 'a-status' }));
                });
        });
    });
    describe('searchThingsByTags()', function () {
        var listResult;
        beforeEach(function () {
            listResult = [];
        });
        it('should call db.find() specifying the collection', function () {
            spyOn(db, 'find').and.returnValue(Promise.resolve(cursor));
            spyOn(cursor, 'toArray').and.returnValue(Promise.resolve(listResult));
            return sut.searchThingsByTags({ owner: owner, tags: ['tag'] })
                .then(function () {
                    expect(db.find).toHaveBeenCalled();
                    expect(db.find.calls.mostRecent().args[0]).toBe('things');
                });
        });
        it('should call db.find() passing owner as the value of query.owner', function () {
            spyOn(db, 'find').and.returnValue(Promise.resolve(cursor));
            spyOn(cursor, 'toArray').and.returnValue(Promise.resolve(listResult));
            return sut.searchThingsByTags({ owner: owner, tags: ['tag1', 'tag2'] })
                .then(function () {
                    expect(db.find).toHaveBeenCalled();
                    expect(db.find.calls.mostRecent().args[1]).toEqual(jasmine.objectContaining({ owner: owner }));
                });
        });
        it('should call db.find() passing tags as the value of query.content.$elemMatch[\'tagList.text\']' +
            '.$in', function () {
            spyOn(db, 'find').and.returnValue(Promise.resolve(cursor));
            spyOn(cursor, 'toArray').and.returnValue(Promise.resolve(listResult));
            return sut.searchThingsByTags({ owner: owner, tags: ['tag1', 'tag2'] })
                .then(function () {
                    expect(db.find).toHaveBeenCalled();
                    var query = db.find.calls.mostRecent().args[1];
                    expect(query).toBeNonEmptyObject();
                    expect(query.content).toBeNonEmptyObject();
                    expect(query.content.$elemMatch).toBeNonEmptyObject();
                    expect(query.content.$elemMatch['tagList.text']).toBeNonEmptyObject();
                    expect(query.content.$elemMatch['tagList.text'].$in).toEqual(['tag1', 'tag2']);
                });
        });
        it('should call db.find() without query.content.$elemMatch[\'tags.text\'] if tags is undefined', function () {
            spyOn(db, 'find').and.returnValue(Promise.resolve(cursor));
            spyOn(cursor, 'toArray').and.returnValue(Promise.resolve(listResult));
            return sut.searchThingsByTags({ owner: owner, locale: 'it' })
                .then(function () {
                    expect(db.find).toHaveBeenCalled();
                    var query = db.find.calls.mostRecent().args[1];
                    expect(query).toBeNonEmptyObject();
                    expect(query.content).toBeNonEmptyObject();
                    expect(query.content.$elemMatch).toBeNonEmptyObject();
                    expect(query.content.$elemMatch['tags.text']).toBeUndefined();
                });
        });
        it('should call db.find() passing locale as the value of query.content.$elemMatch.locale', function () {
            spyOn(db, 'find').and.returnValue(Promise.resolve(cursor));
            spyOn(cursor, 'toArray').and.returnValue(Promise.resolve(listResult));
            return sut.searchThingsByTags({ owner: owner, tags: ['tag1', 'tag2'], locale: 'it' })
                .then(function () {
                    expect(db.find).toHaveBeenCalled();
                    var query = db.find.calls.mostRecent().args[1];
                    expect(query).toBeNonEmptyObject();
                    expect(query.content).toBeNonEmptyObject();
                    expect(query.content.$elemMatch).toBeNonEmptyObject();
                    expect(query.content.$elemMatch.locale).toBe('it');
                });
        });
        it('should call db.find() without query.content.$elemMatch.locale if locale is undefined', function () {
            spyOn(db, 'find').and.returnValue(Promise.resolve(cursor));
            spyOn(cursor, 'toArray').and.returnValue(Promise.resolve(listResult));
            return sut.searchThingsByTags({ owner: owner, tags: ['tag1', 'tag2'] })
                .then(function () {
                    expect(db.find).toHaveBeenCalled();
                    var query = db.find.calls.mostRecent().args[1];
                    expect(query).toBeNonEmptyObject();
                    expect(query.content).toBeNonEmptyObject();
                    expect(query.content.$elemMatch).toBeNonEmptyObject();
                    expect(query.content.$elemMatch.locale).toBeUndefined();
                });
        });
        it('should convert the cursor into an array', function () {
            spyOn(db, 'find').and.returnValue(Promise.resolve(cursor));
            spyOn(cursor, 'toArray').and.returnValue(Promise.resolve(listResult));
            return sut.searchThingsByTags(owner, ['tag1', 'tag2'], 'it')
                .then(function () {
                    expect(db.find).toHaveBeenCalled();
                    expect(cursor.toArray).toHaveBeenCalled();
                });
        });
        it('should return the array', function () {
            spyOn(db, 'find').and.returnValue(Promise.resolve(cursor));
            spyOn(cursor, 'toArray').and.returnValue(Promise.resolve(listResult));
            return sut.searchThingsByTags({
                owner: owner, tags: ['tag1', 'tag2'], locale: 'it'
            })
                .then(function (result) {
                    expect(result).toBe(listResult);
                });
        });
        it('should propagate any error of the db', function () {
            spyOn(db, 'find').and.callFake(function (collection, filter) {
                if (filter.owner === 'testingFind') {
                    return Promise.reject(new Error('dummyFind'));
                }
                return Promise.resolve(cursor);
            });
            spyOn(cursor, 'toArray').and.returnValue(Promise.reject(new Error('dummyCursor')));
            var findTest = sut.searchThingsByTags({
                owner: 'testingFind', tags: ['tag1', 'tag2'], locale: 'it'
            })
                .then(helper.thenFail)
                .catch(function (err) {
                    expect(err.message).toBe('dummyFind');
                });
            var cursorTest = sut.searchThingsByTags({
                owner: 'testingCursor', tags: ['tag1', 'tag2'], locale: 'it'
            })
                .then(helper.thenFail)
                .catch(function (err) {
                    expect(err.message).toBe('dummyCursor');
                });
            return Promise.all([ findTest, cursorTest ]);
        });
        it('should call the DB to filtering by status if statusFilter is specified', function () {
            spyOn(db, 'find').and.returnValue(Promise.resolve(cursor));
            spyOn(cursor, 'toArray').and.returnValue(Promise.resolve(listResult));
            return sut.searchThingsByTags({ owner: owner, tags: ['tag1', 'tag2'], statusFilter: 'a-status' })
                .then(function () {
                    expect(db.find).toHaveBeenCalled();
                    expect(db.find.calls.mostRecent().args[1])
                        .toEqual(jasmine.objectContaining({ status: 'a-status' }));
                });
        });
    });
    describe('listThingsReferencingCollection()', function () {
        var collectionId = 'collectionId';
        var listResult;
        beforeEach(function () {
            listResult = [
                thing,
                {
                    _id: 'anotherResult',
                    otherKey: 'otherValue'
                }
            ];
        });
        it('should call the DB to obtain the cursor specifying the collection', function () {
            spyOn(db, 'find').and.returnValue(Promise.resolve(cursor));
            spyOn(cursor, 'toArray').and.returnValue(Promise.resolve(listResult));
            return sut.listThingsReferencingCollection(owner, collectionId)
                .then(function () {
                    expect(db.find).toHaveBeenCalled();
                    expect(db.find.calls.mostRecent().args[0]).toBe('things');
                });
        });
        it('should call the DB to obtain the cursor specifying the right query', function () {
            var query = {
                owner: owner,
                'relatedThingsCollectionId': collectionId
            };
            spyOn(db, 'find').and.returnValue(Promise.resolve(cursor));
            spyOn(cursor, 'toArray').and.returnValue(Promise.resolve(listResult));
            return sut.listThingsReferencingCollection(owner, collectionId)
                .then(function () {
                    expect(db.find).toHaveBeenCalled();
                    expect(db.find.calls.mostRecent().args[1]).toEqual(query);
                });
        });
        it('should convert the cursor into an array (kinda testing implementation)', function () {
            spyOn(db, 'find').and.returnValue(Promise.resolve(cursor));
            spyOn(cursor, 'toArray').and.returnValue(Promise.resolve(listResult));
            return sut.listThingsReferencingCollection(owner, collectionId)
                .then(function () {
                    expect(db.find).toHaveBeenCalled();
                    expect(cursor.toArray).toHaveBeenCalled();
                });
        });
        it('should return the array', function () {
            spyOn(db, 'find').and.returnValue(Promise.resolve(cursor));
            spyOn(cursor, 'toArray').and.returnValue(Promise.resolve(listResult));
            return sut.listThingsReferencingCollection(owner, collectionId)
                .then(function (result) {
                    expect(result).toBe(listResult);
                });
        });
        it('should propagate any error of the db', function () {
            spyOn(db, 'find').and.callFake(function (collection, filter) {
                if (filter.owner === 'testingFind') {
                    return Promise.reject(new Error('dummyFind'));
                }
                return Promise.resolve(cursor);
            });
            spyOn(cursor, 'toArray').and.returnValue(Promise.reject(new Error('dummyCursor')));
            var findTest = sut.listThingsReferencingCollection('testingFind', collectionId)
                .then(helper.thenFail)
                .catch(function (err) {
                    expect(err.message).toBe('dummyFind');
                });
            var cursorTest = sut.listThingsReferencingCollection(owner, collectionId)
                .then(helper.thenFail)
                .catch(function (err) {
                    expect(err.message).toBe('dummyCursor');
                });
            return Promise.all([ findTest, cursorTest ]);
        });
    });
});
