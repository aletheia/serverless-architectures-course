'use strict';

var helper = require('../../helper'),
    Authorizer = require('../../../src/thing/authorizer.js'),
    Promise = require('bluebird');

describe('Thing Authorizer', function () {
    var logic, sut, principal;
    beforeEach(function () {
        logic = {
            createThing: function () {
            },
            getThing: function () {
            },
            updateThing: function () {
            },
            deleteThing: function () {
            },
            listThings: function () {
            },
            searchThingsByTags: function () {
            }
        };
        sut = new Authorizer(helper.getLoggerMock(), logic);
        principal = {
            checkAuthorization: function () {
            },
            getFilterByOwner: function () {
            },
            getOwner: function () {
            }
        };
    });

    describe('createThing', function () {
        it('should call principal.checkAuthorization() with the right parameters', function () {
            var thing = { name: 'name' };
            spyOn(principal, 'checkAuthorization');
            spyOn(logic, 'createThing').and.returnValue(Promise.resolve());
            return sut.createThing(principal, thing)
                .then(function () {
                    expect(principal.checkAuthorization)
                        .toHaveBeenCalledWith(['ROLE_PRODUCT_USER', 'ROLE_ADMIN'], 'create things');
                });
        });
        it('should throw the error thrown by principal.checkAuthorization()', function () {
            var thing = { name: 'name' };
            spyOn(principal, 'checkAuthorization').and.throwError(new Error('error'));
            spyOn(logic, 'createThing');
            return sut.createThing(principal, thing)
                .then(helper.thenFail)
                .catch(function (error) {
                    expect(error.message).toBe('error');
                    expect(principal.checkAuthorization).toHaveBeenCalled();
                    expect(logic.createThing).not.toHaveBeenCalled();
                });
        });
        it('should call principal.getOwner() with the right parameters', function () {
            var thing = { name: 'name', owner: 'owner' };
            spyOn(principal, 'getOwner');
            spyOn(logic, 'createThing').and.returnValue(Promise.resolve());
            return sut.createThing(principal, thing)
                .then(function () {
                    expect(principal.getOwner).toHaveBeenCalledWith('owner');
                });
        });
        it('should throw the error thrown by principal.getOwner()', function () {
            var thing = { name: 'name' };
            spyOn(principal, 'getOwner').and.throwError(new Error('error'));
            spyOn(logic, 'createThing');
            return sut.createThing(principal, thing)
                .then(helper.thenFail)
                .catch(function (error) {
                    expect(error.message).toBe('error');
                    expect(principal.getOwner).toHaveBeenCalled();
                    expect(logic.createThing).not.toHaveBeenCalled();
                });
        });
        it('should call logic.createThing() with the right parameters', function () {
            var thing = { name: 'name' };
            spyOn(principal, 'checkAuthorization');
            spyOn(logic, 'createThing').and.returnValue(Promise.resolve());
            return sut.createThing(principal, thing)
                .then(function () {
                    expect(principal.checkAuthorization).toHaveBeenCalled();
                    expect(logic.createThing).toHaveBeenCalledWith(principal, thing);
                });
        });
        it('should throw the error thrown by logic.createThing()', function () {
            var thing = { name: 'name' };
            spyOn(principal, 'checkAuthorization');
            spyOn(logic, 'createThing').and.returnValue(Promise.reject(new Error('error')));
            return sut.createThing(principal, thing)
                .then(helper.thenFail)
                .catch(function (error) {
                    expect(error.message).toBe('error');
                    expect(principal.checkAuthorization).toHaveBeenCalled();
                    expect(logic.createThing).toHaveBeenCalled();
                });
        });
        it('should return the result of logic.createThing()', function () {
            var thing = { name: 'name' };
            var result = 'result';
            spyOn(principal, 'checkAuthorization');
            spyOn(logic, 'createThing').and.returnValue(Promise.resolve(result));
            return sut.createThing(principal, thing)
                .then(function (res) {
                    expect(res).toBe(result);
                    expect(principal.checkAuthorization).toHaveBeenCalled();
                    expect(logic.createThing).toHaveBeenCalled();
                });
        });
    });

    describe('getThing', function () {
        it('should call principal.checkAuthorization() with the right parameters', function () {
            var p = 'p';
            spyOn(principal, 'checkAuthorization');
            spyOn(logic, 'getThing').and.returnValue(Promise.resolve());
            return sut.getThing(principal, p)
                .then(function () {
                    expect(principal.checkAuthorization).toHaveBeenCalledWith(
                        ['ROLE_BROWSER', 'ROLE_PERMALINK', 'ROLE_PRODUCT_USER', 'ROLE_ADMIN'],
                        'get things'
                    );
                });
        });
        it('should throw the error thrown by principal.checkAuthorization()', function () {
            var p = 'p';
            spyOn(principal, 'checkAuthorization').and.throwError(new Error('error'));
            spyOn(logic, 'getThing');
            return sut.getThing(principal, p)
                .then(helper.thenFail)
                .catch(function (error) {
                    expect(error.message).toBe('error');
                    expect(principal.checkAuthorization).toHaveBeenCalled();
                    expect(logic.getThing).not.toHaveBeenCalled();
                });
        });
        it('should call logic.getThing() with the right parameters', function () {
            var p = 'p';
            spyOn(principal, 'checkAuthorization');
            spyOn(logic, 'getThing').and.returnValue(Promise.resolve());
            return sut.getThing(principal, p)
                .then(function () {
                    expect(principal.checkAuthorization).toHaveBeenCalled();
                    expect(logic.getThing).toHaveBeenCalledWith(principal, p);
                });
        });
        it('should throw the error thrown by logic.getThing()', function () {
            var p = 'p';
            spyOn(principal, 'checkAuthorization');
            spyOn(logic, 'getThing').and.returnValue(Promise.reject(new Error('error')));
            return sut.getThing(principal, p)
                .then(helper.thenFail)
                .catch(function (error) {
                    expect(error.message).toBe('error');
                    expect(principal.checkAuthorization).toHaveBeenCalled();
                    expect(logic.getThing).toHaveBeenCalled();
                });
        });
        it('should return the result of logic.getThing()', function () {
            var p = 'p';
            var result = 'result';
            spyOn(principal, 'checkAuthorization');
            spyOn(logic, 'getThing').and.returnValue(Promise.resolve(result));
            return sut.getThing(principal, p)
                .then(function (res) {
                    expect(res).toBe(result);
                    expect(principal.checkAuthorization).toHaveBeenCalled();
                    expect(logic.getThing).toHaveBeenCalled();
                });
        });
    });

    describe('updateThing', function () {
        it('should call principal.checkAuthorization() with the right parameters', function () {
            var uuid = 'uuid';
            var thing = 'thing';
            spyOn(principal, 'checkAuthorization');
            spyOn(logic, 'updateThing').and.returnValue(Promise.resolve());
            return sut.updateThing(principal, uuid, thing)
                .then(function () {
                    expect(principal.checkAuthorization).toHaveBeenCalledWith(
                        ['ROLE_PRODUCT_USER', 'ROLE_ADMIN'],
                        'update things'
                    );
                });
        });
        it('should throw the error thrown by principal.checkAuthorization()', function () {
            var uuid = 'uuid';
            var thing = 'thing';
            spyOn(principal, 'checkAuthorization').and.throwError(new Error('error'));
            spyOn(logic, 'updateThing');
            return sut.updateThing(principal, uuid, thing)
                .then(helper.thenFail)
                .catch(function (error) {
                    expect(error.message).toBe('error');
                    expect(principal.checkAuthorization).toHaveBeenCalled();
                    expect(logic.updateThing).not.toHaveBeenCalled();
                });
        });
        it('should call logic.updateThing() with the right parameters', function () {
            var uuid = 'uuid';
            var thing = 'thing';
            spyOn(principal, 'checkAuthorization');
            spyOn(logic, 'updateThing').and.returnValue(Promise.resolve());
            return sut.updateThing(principal, uuid, thing)
                .then(function () {
                    expect(principal.checkAuthorization).toHaveBeenCalled();
                    expect(logic.updateThing).toHaveBeenCalledWith(principal, uuid, thing);
                });
        });
        it('should throw the error thrown by logic.updateThing()', function () {
            var uuid = 'uuid';
            var thing = 'thing';
            spyOn(principal, 'checkAuthorization');
            spyOn(logic, 'updateThing').and.returnValue(Promise.reject(new Error('error')));
            return sut.updateThing(principal, uuid, thing)
                .then(helper.thenFail)
                .catch(function (error) {
                    expect(error.message).toBe('error');
                    expect(principal.checkAuthorization).toHaveBeenCalled();
                    expect(logic.updateThing).toHaveBeenCalled();
                });
        });
        it('should return the result of logic.updateThing()', function () {
            var uuid = 'uuid';
            var thing = 'thing';
            var result = 'result';
            spyOn(principal, 'checkAuthorization');
            spyOn(logic, 'updateThing').and.returnValue(Promise.resolve(result));
            return sut.updateThing(principal, uuid, thing)
                .then(function (res) {
                    expect(res).toBe(result);
                    expect(principal.checkAuthorization).toHaveBeenCalled();
                    expect(logic.updateThing).toHaveBeenCalled();
                });
        });
    });

    describe('deleteThing', function () {
        it('should call principal.checkAuthorization() with the right parameters', function () {
            var uuid = 'uuid';
            spyOn(principal, 'checkAuthorization');
            spyOn(logic, 'deleteThing').and.returnValue(Promise.resolve());
            return sut.deleteThing(principal, uuid)
                .then(function () {
                    expect(principal.checkAuthorization).toHaveBeenCalledWith(
                        ['ROLE_PRODUCT_USER', 'ROLE_ADMIN'],
                        'delete things'
                    );
                });
        });
        it('should throw the error thrown by principal.checkAuthorization()', function () {
            var uuid = 'uuid';
            spyOn(principal, 'checkAuthorization').and.throwError(new Error('error'));
            spyOn(logic, 'deleteThing');
            return sut.deleteThing(principal, uuid)
                .then(helper.thenFail)
                .catch(function (error) {
                    expect(error.message).toBe('error');
                    expect(principal.checkAuthorization).toHaveBeenCalled();
                    expect(logic.deleteThing).not.toHaveBeenCalled();
                });
        });
        it('should call logic.deleteThing() with the right parameters', function () {
            var uuid = 'uuid';
            spyOn(principal, 'checkAuthorization');
            spyOn(logic, 'deleteThing').and.returnValue(Promise.resolve());
            return sut.deleteThing(principal, uuid)
                .then(function () {
                    expect(principal.checkAuthorization).toHaveBeenCalled();
                    expect(logic.deleteThing).toHaveBeenCalledWith(principal, uuid);
                });
        });
        it('should throw the error thrown by logic.deleteThing()', function () {
            var uuid = 'uuid';
            spyOn(principal, 'checkAuthorization');
            spyOn(logic, 'deleteThing').and.returnValue(Promise.reject(new Error('error')));
            return sut.deleteThing(principal, uuid)
                .then(helper.thenFail)
                .catch(function (error) {
                    expect(error.message).toBe('error');
                    expect(principal.checkAuthorization).toHaveBeenCalled();
                    expect(logic.deleteThing).toHaveBeenCalled();
                });
        });
        it('should return the result of logic.deleteThing()', function () {
            var uuid = 'uuid';
            var result = 'result';
            spyOn(principal, 'checkAuthorization');
            spyOn(logic, 'deleteThing').and.returnValue(Promise.resolve(result));
            return sut.deleteThing(principal, uuid)
                .then(function (res) {
                    expect(res).toBe(result);
                    expect(principal.checkAuthorization).toHaveBeenCalled();
                    expect(logic.deleteThing).toHaveBeenCalled();
                });
        });
    });

    describe('listThings', function () {
        it('should call principal.checkAuthorization() with the right parameters', function () {
            var p = {};
            spyOn(principal, 'checkAuthorization');
            spyOn(logic, 'listThings').and.returnValue(Promise.resolve());
            return sut.listThings(principal, p)
                .then(function () {
                    expect(principal.checkAuthorization).toHaveBeenCalledWith(
                        ['ROLE_BROWSER', 'ROLE_PRODUCT_USER', 'ROLE_ADMIN'],
                        'list things'
                    );
                });
        });
        it('should throw the error thrown by principal.checkAuthorization()', function () {
            var p = {};
            spyOn(principal, 'checkAuthorization').and.throwError(new Error('error'));
            spyOn(logic, 'listThings');
            return sut.listThings(principal, p)
                .then(helper.thenFail)
                .catch(function (error) {
                    expect(error.message).toBe('error');
                    expect(principal.checkAuthorization).toHaveBeenCalled();
                    expect(logic.listThings).not.toHaveBeenCalled();
                });
        });
        it('should call principal.getFilterByOwner() with the right parameters', function () {
            var p = { owner: 'owner' };
            spyOn(principal, 'checkAuthorization');
            spyOn(principal, 'getFilterByOwner');
            spyOn(logic, 'listThings').and.returnValue(Promise.resolve());
            return sut.listThings(principal, p)
                .then(function () {
                    expect(principal.getFilterByOwner).toHaveBeenCalledWith('owner');
                });
        });
        it('should throw the error thrown by principal.getFilterByOwner()', function () {
            var p = { owner: 'owner' };
            spyOn(principal, 'getFilterByOwner').and.throwError(new Error('error'));
            spyOn(logic, 'listThings');
            return sut.listThings(principal, p)
                .then(helper.thenFail)
                .catch(function (error) {
                    expect(error.message).toBe('error');
                    expect(principal.getFilterByOwner).toHaveBeenCalled();
                    expect(logic.listThings).not.toHaveBeenCalled();
                });
        });
        it('should call logic.listThings() with the right parameters', function () {
            var p = {};
            spyOn(principal, 'checkAuthorization');
            spyOn(principal, 'getFilterByOwner');
            spyOn(logic, 'listThings').and.returnValue(Promise.resolve());
            return sut.listThings(principal, p)
                .then(function () {
                    expect(principal.checkAuthorization).toHaveBeenCalled();
                    expect(principal.getFilterByOwner).toHaveBeenCalled();
                    expect(logic.listThings).toHaveBeenCalledWith(principal, p);
                });
        });
        it('should throw the error thrown by logic.listThings()', function () {
            var p = {};
            spyOn(principal, 'checkAuthorization');
            spyOn(principal, 'getFilterByOwner');
            spyOn(logic, 'listThings').and.returnValue(Promise.reject(new Error('error')));
            return sut.listThings(principal, p)
                .then(helper.thenFail)
                .catch(function (error) {
                    expect(error.message).toBe('error');
                    expect(principal.checkAuthorization).toHaveBeenCalled();
                    expect(principal.getFilterByOwner).toHaveBeenCalled();
                    expect(logic.listThings).toHaveBeenCalled();
                });
        });
        it('should return the result of logic.listThings()', function () {
            var p = {};
            var result = 'result';
            spyOn(principal, 'checkAuthorization');
            spyOn(principal, 'getFilterByOwner');
            spyOn(logic, 'listThings').and.returnValue(Promise.resolve(result));
            return sut.listThings(principal, p)
                .then(function (res) {
                    expect(res).toBe(result);
                    expect(principal.getFilterByOwner).toHaveBeenCalled();
                    expect(principal.checkAuthorization).toHaveBeenCalled();
                    expect(logic.listThings).toHaveBeenCalled();
                });
        });
    });

    describe('searchThingsByTags', function () {
        it('should call principal.checkAuthorization() with the right parameters', function () {
            var p = {};
            spyOn(principal, 'checkAuthorization');
            spyOn(logic, 'searchThingsByTags').and.returnValue(Promise.resolve());
            return sut.searchThingsByTags(principal, p)
                .then(function () {
                    expect(principal.checkAuthorization).toHaveBeenCalledWith(
                        ['ROLE_BROWSER', 'ROLE_PRODUCT_USER', 'ROLE_ADMIN'],
                        'search things'
                    );
                });
        });
        it('should throw the error thrown by principal.checkAuthorization()', function () {
            var p = {};
            spyOn(principal, 'checkAuthorization').and.throwError(new Error('error'));
            spyOn(logic, 'searchThingsByTags');
            return sut.searchThingsByTags(principal, p)
                .then(helper.thenFail)
                .catch(function (error) {
                    expect(error.message).toBe('error');
                    expect(principal.checkAuthorization).toHaveBeenCalled();
                    expect(logic.searchThingsByTags).not.toHaveBeenCalled();
                });
        });
        it('should call principal.getFilterByOwner() with the right parameters', function () {
            var p = { owner: 'owner' };
            spyOn(principal, 'checkAuthorization');
            spyOn(principal, 'getFilterByOwner');
            spyOn(logic, 'searchThingsByTags').and.returnValue(Promise.resolve());
            return sut.searchThingsByTags(principal, p)
                .then(function () {
                    expect(principal.getFilterByOwner).toHaveBeenCalledWith('owner');
                });
        });
        it('should throw the error thrown by principal.getOwnerFilter()', function () {
            var p = { owner: 'owner' };
            spyOn(principal, 'getFilterByOwner').and.throwError(new Error('error'));
            spyOn(logic, 'searchThingsByTags');
            return sut.searchThingsByTags(principal, p)
                .then(helper.thenFail)
                .catch(function (error) {
                    expect(error.message).toBe('error');
                    expect(principal.getFilterByOwner).toHaveBeenCalled();
                    expect(logic.searchThingsByTags).not.toHaveBeenCalled();
                });
        });
        it('should call logic.searchThingsByTags() with the right parameters', function () {
            var p = {};
            spyOn(principal, 'checkAuthorization');
            spyOn(principal, 'getFilterByOwner');
            spyOn(logic, 'searchThingsByTags').and.returnValue(Promise.resolve());
            return sut.searchThingsByTags(principal, p)
                .then(function () {
                    expect(principal.checkAuthorization).toHaveBeenCalled();
                    expect(principal.getFilterByOwner).toHaveBeenCalled();
                    expect(logic.searchThingsByTags).toHaveBeenCalledWith(principal, p);
                });
        });
        it('should throw the error thrown by logic.searchThingsByTags()', function () {
            var p = {};
            spyOn(principal, 'checkAuthorization');
            spyOn(principal, 'getFilterByOwner');
            spyOn(logic, 'searchThingsByTags').and.returnValue(Promise.reject(new Error('error')));
            return sut.searchThingsByTags(principal, p)
                .then(helper.thenFail)
                .catch(function (error) {
                    expect(error.message).toBe('error');
                    expect(principal.checkAuthorization).toHaveBeenCalled();
                    expect(principal.getFilterByOwner).toHaveBeenCalled();
                    expect(logic.searchThingsByTags).toHaveBeenCalled();
                });
        });
        it('should return the result of logic.searchThingsByTags()', function () {
            var p = {};
            var result = 'result';
            spyOn(principal, 'checkAuthorization');
            spyOn(principal, 'getFilterByOwner');
            spyOn(logic, 'searchThingsByTags').and.returnValue(Promise.resolve(result));
            return sut.searchThingsByTags(principal, p)
                .then(function (res) {
                    expect(res).toBe(result);
                    expect(principal.getFilterByOwner).toHaveBeenCalled();
                    expect(principal.checkAuthorization).toHaveBeenCalled();
                    expect(logic.searchThingsByTags).toHaveBeenCalled();
                });
        });
    });

});
