'use strict';

var Handler = require('../../../../../src/thing/lambda/create-thing/handler.js'),
    Promise = require('bluebird');

describe('CreateThing lambda', function () {
    var event, context, authorizer, container, apiGateway, sut;
    beforeEach(function () {
        event = 'event';
        context = 'context';
        authorizer = {
            createThing: function () {
            }
        };
        container = {
            get: function () {
            },
            shutdown: function () {
            },
        };
        apiGateway = {
            getPrincipal: function () {
            },
            getThingForCreate: function () {
            },
            createLocationHeader: function () {
            },
            createResponse: function () {
            },
            createErrorResponse: function () {
            }
        };
        sut = Handler.handler;
    });

    describe('handler()', function () {
        it('should call apiGateway.getPrincipal(), apiGateway.getThingForCreate(), container.get(), ' +
            'authorizer.createThing(), apiGateway.createLocationHeader(), apiGateway.createResponse(), ' +
            'container.shutdown() with the right parameters and callback() with the result of ' +
            'apiGateway.createResponse()', function () {
            var thingToCreate = 'thing';
            var principal = 'principal';
            var createdThing = { uuid: 'uuid' };
            var header = 'header';
            var response = 'response';
            spyOn(apiGateway, 'getPrincipal').and.returnValue(principal);
            spyOn(apiGateway, 'getThingForCreate').and.returnValue(thingToCreate);
            spyOn(container, 'get').and.returnValue(authorizer);
            spyOn(authorizer, 'createThing').and.returnValue(Promise.resolve(createdThing));
            spyOn(apiGateway, 'createLocationHeader').and.returnValue(header);
            spyOn(apiGateway, 'createResponse').and.returnValue(response);
            spyOn(apiGateway, 'createErrorResponse');
            spyOn(container, 'shutdown').and.returnValue(Promise.resolve());
            return sut(event, context, function (err, result) {
                expect(apiGateway.getPrincipal).toHaveBeenCalled();
                expect(apiGateway.getThingForCreate).toHaveBeenCalled();
                expect(container.get).toHaveBeenCalledWith('thing.authorizer');
                expect(authorizer.createThing).toHaveBeenCalledWith(principal, thingToCreate);
                expect(apiGateway.createLocationHeader).toHaveBeenCalledWith(createdThing.uuid);
                expect(apiGateway.createResponse).toHaveBeenCalledWith(201, header, createdThing);
                expect(apiGateway.createErrorResponse).not.toHaveBeenCalled();
                expect(result).toEqual(response);
            }, container, apiGateway)
                .then(function () {
                    expect(container.shutdown).toHaveBeenCalled();
                });
        });
        it('should call apiGateway.createErrorResponse() with the right parameters and callback() with its result ' +
            'if apiGateway.getPrincipal() throws', function () {
            var error = new Error('error');
            var response = 'response';
            spyOn(apiGateway, 'getPrincipal').and.throwError(error);
            spyOn(apiGateway, 'getThingForCreate');
            spyOn(container, 'get');
            spyOn(authorizer, 'createThing');
            spyOn(apiGateway, 'createLocationHeader');
            spyOn(apiGateway, 'createResponse');
            spyOn(apiGateway, 'createErrorResponse').and.returnValue(response);
            spyOn(container, 'shutdown').and.returnValue(Promise.resolve());
            return sut(event, context, function (err, result) {
                expect(apiGateway.getPrincipal).toHaveBeenCalled();
                expect(apiGateway.getThingForCreate).not.toHaveBeenCalled();
                expect(container.get).not.toHaveBeenCalled();
                expect(authorizer.createThing).not.toHaveBeenCalled();
                expect(apiGateway.createLocationHeader).not.toHaveBeenCalled();
                expect(apiGateway.createResponse).not.toHaveBeenCalled();
                expect(apiGateway.createErrorResponse).toHaveBeenCalledWith(error);
                expect(result).toEqual(response);
            }, container, apiGateway)
                .then(function () {
                    expect(container.shutdown).toHaveBeenCalled();
                });
        });
        it('should call apiGateway.createErrorResponse() with the right parameters and callback() with its result ' +
            'if apiGateway.getThingForCreate() throws', function () {
            var error = new Error('error');
            var response = 'response';
            spyOn(apiGateway, 'getPrincipal');
            spyOn(apiGateway, 'getThingForCreate').and.throwError(error);
            spyOn(container, 'get');
            spyOn(authorizer, 'createThing');
            spyOn(apiGateway, 'createLocationHeader');
            spyOn(apiGateway, 'createResponse');
            spyOn(apiGateway, 'createErrorResponse').and.returnValue(response);
            spyOn(container, 'shutdown').and.returnValue(Promise.resolve());
            return sut(event, context, function (err, result) {
                expect(apiGateway.getPrincipal).toHaveBeenCalled();
                expect(apiGateway.getThingForCreate).toHaveBeenCalled();
                expect(container.get).not.toHaveBeenCalled();
                expect(authorizer.createThing).not.toHaveBeenCalled();
                expect(apiGateway.createLocationHeader).not.toHaveBeenCalled();
                expect(apiGateway.createResponse).not.toHaveBeenCalled();
                expect(apiGateway.createErrorResponse).toHaveBeenCalledWith(error);
                expect(result).toEqual(response);
            }, container, apiGateway)
                .then(function () {
                    expect(container.shutdown).toHaveBeenCalled();
                });
        });
        it('should call apiGateway.createErrorResponse() with the right parameters and callback() with its result ' +
            'if container.get() throws', function () {
            var error = new Error('error');
            var response = 'response';
            spyOn(apiGateway, 'getPrincipal');
            spyOn(apiGateway, 'getThingForCreate');
            spyOn(container, 'get').and.throwError(error);
            spyOn(authorizer, 'createThing');
            spyOn(apiGateway, 'createLocationHeader');
            spyOn(apiGateway, 'createResponse');
            spyOn(apiGateway, 'createErrorResponse').and.returnValue(response);
            spyOn(container, 'shutdown').and.returnValue(Promise.resolve());
            return sut(event, context, function (err, result) {
                expect(apiGateway.getPrincipal).toHaveBeenCalled();
                expect(apiGateway.getThingForCreate).toHaveBeenCalled();
                expect(container.get).toHaveBeenCalled();
                expect(authorizer.createThing).not.toHaveBeenCalled();
                expect(apiGateway.createLocationHeader).not.toHaveBeenCalled();
                expect(apiGateway.createResponse).not.toHaveBeenCalled();
                expect(apiGateway.createErrorResponse).toHaveBeenCalledWith(error);
                expect(result).toEqual(response);
            }, container, apiGateway)
                .then(function () {
                    expect(container.shutdown).toHaveBeenCalled();
                });
        });
        it('should call apiGateway.createErrorResponse() with the right parameters and callback() with its result ' +
            'if authorizer.createThing() throws', function () {
            var error = new Error('error');
            var response = 'response';
            spyOn(apiGateway, 'getPrincipal');
            spyOn(apiGateway, 'getThingForCreate');
            spyOn(container, 'get').and.returnValue(authorizer);
            spyOn(authorizer, 'createThing').and.returnValue(Promise.reject(error));
            spyOn(apiGateway, 'createLocationHeader');
            spyOn(apiGateway, 'createResponse');
            spyOn(apiGateway, 'createErrorResponse').and.returnValue(response);
            spyOn(container, 'shutdown').and.returnValue(Promise.resolve());
            return sut(event, context, function (err, result) {
                expect(apiGateway.getPrincipal).toHaveBeenCalled();
                expect(apiGateway.getThingForCreate).toHaveBeenCalled();
                expect(container.get).toHaveBeenCalled();
                expect(authorizer.createThing).toHaveBeenCalled();
                expect(apiGateway.createLocationHeader).not.toHaveBeenCalled();
                expect(apiGateway.createResponse).not.toHaveBeenCalled();
                expect(apiGateway.createErrorResponse).toHaveBeenCalledWith(error);
                expect(result).toEqual(response);
            }, container, apiGateway)
                .then(function () {
                    expect(container.shutdown).toHaveBeenCalled();
                });
        });
    });

});
