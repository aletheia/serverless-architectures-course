'use strict';

var Handler = require('../../../../../src/thing/lambda/list-things/handler.js'),
    Promise = require('bluebird');

describe('ListThings lambda', function () {
    var event, context, authorizer, container, apiGateway, sut;
    beforeEach(function () {
        event = 'event';
        context = 'context';
        authorizer = {
            listThings: function () {
            }
        };
        container = {
            get: function () {
            },
            shutdown: function () {
            },
        };
        apiGateway = {
            getPrincipal: function () {
            },
            getStatusFilter: function () {
            },
            getOwner: function () {
            },
            createResponse: function () {
            },
            createErrorResponse: function () {
            }
        };
        sut = Handler.handler;
    });

    describe('handler()', function () {
        it('should call apiGateway.getPrincipal(), apiGateway.getStatusFilter(), apiGateway.getOwner(), ' +
            'container.get(), authorizer.listThings(), apiGateway.createResponse(), container.shutdown() ' +
            'with the right parameters and callback() with the result of apiGateway.createResponse()', function () {
            var owner = 'owner';
            var statusFilter = 'statusFilter';
            var principal = 'principal';
            var things = [1, 2, 3];
            var response = 'response';
            spyOn(apiGateway, 'getPrincipal').and.returnValue(principal);
            spyOn(apiGateway, 'getStatusFilter').and.returnValue(statusFilter);
            spyOn(apiGateway, 'getOwner').and.returnValue(owner);
            spyOn(container, 'get').and.returnValue(authorizer);
            spyOn(authorizer, 'listThings').and.returnValue(Promise.resolve(things));
            spyOn(apiGateway, 'createResponse').and.returnValue(response);
            spyOn(apiGateway, 'createErrorResponse');
            spyOn(container, 'shutdown').and.returnValue(Promise.resolve());
            return sut(event, context, function (err, result) {
                expect(apiGateway.getPrincipal).toHaveBeenCalled();
                expect(apiGateway.getStatusFilter).toHaveBeenCalled();
                expect(apiGateway.getOwner).toHaveBeenCalled();
                expect(container.get).toHaveBeenCalledWith('thing.authorizer');
                expect(authorizer.listThings).toHaveBeenCalledWith(
                    principal,
                    { owner: owner, statusFilter: statusFilter }
                );
                expect(apiGateway.createResponse).toHaveBeenCalledWith(200, {}, things);
                expect(apiGateway.createErrorResponse).not.toHaveBeenCalled();
                expect(result).toEqual(response);
            }, container, apiGateway)
                .then(function () {
                    expect(container.shutdown).toHaveBeenCalled();
                });
        });
        it('should call apiGateway.createErrorResponse() with the right parameters and callback() with its result ' +
            'if apiGateway.getPrincipal() throws', function () {
            var error = new Error('error');
            var response = 'response';
            spyOn(apiGateway, 'getPrincipal').and.throwError(error);
            spyOn(apiGateway, 'getStatusFilter');
            spyOn(apiGateway, 'getOwner');
            spyOn(container, 'get');
            spyOn(authorizer, 'listThings');
            spyOn(apiGateway, 'createResponse');
            spyOn(apiGateway, 'createErrorResponse').and.returnValue(response);
            spyOn(container, 'shutdown').and.returnValue(Promise.resolve());
            return sut(event, context, function (err, result) {
                expect(apiGateway.getPrincipal).toHaveBeenCalled();
                expect(apiGateway.getStatusFilter).not.toHaveBeenCalled();
                expect(apiGateway.getOwner).not.toHaveBeenCalled();
                expect(container.get).not.toHaveBeenCalled();
                expect(authorizer.listThings).not.toHaveBeenCalled();
                expect(apiGateway.createResponse).not.toHaveBeenCalled();
                expect(apiGateway.createErrorResponse).toHaveBeenCalledWith(error);
                expect(result).toEqual(response);
            }, container, apiGateway)
                .then(function () {
                    expect(container.shutdown).toHaveBeenCalled();
                });
        });
        it('should call apiGateway.createErrorResponse() with the right parameters and callback() with its result ' +
            'if apiGateway.getStatusFilter() throws', function () {
            var error = new Error('error');
            var response = 'response';
            spyOn(apiGateway, 'getPrincipal');
            spyOn(apiGateway, 'getStatusFilter').and.throwError(error);
            spyOn(apiGateway, 'getOwner');
            spyOn(container, 'get');
            spyOn(authorizer, 'listThings');
            spyOn(apiGateway, 'createResponse');
            spyOn(apiGateway, 'createErrorResponse').and.returnValue(response);
            spyOn(container, 'shutdown').and.returnValue(Promise.resolve());
            return sut(event, context, function (err, result) {
                expect(apiGateway.getPrincipal).toHaveBeenCalled();
                expect(apiGateway.getStatusFilter).toHaveBeenCalled();
                expect(apiGateway.getOwner).not.toHaveBeenCalled();
                expect(container.get).not.toHaveBeenCalled();
                expect(authorizer.listThings).not.toHaveBeenCalled();
                expect(apiGateway.createResponse).not.toHaveBeenCalled();
                expect(apiGateway.createErrorResponse).toHaveBeenCalledWith(error);
                expect(result).toEqual(response);
            }, container, apiGateway)
                .then(function () {
                    expect(container.shutdown).toHaveBeenCalled();
                });
        });
        it('should call apiGateway.createErrorResponse() with the right parameters and callback() with its result ' +
            'if apiGateway.getOwner() throws', function () {
            var error = new Error('error');
            var response = 'response';
            spyOn(apiGateway, 'getPrincipal');
            spyOn(apiGateway, 'getStatusFilter');
            spyOn(apiGateway, 'getOwner').and.throwError(error);
            spyOn(container, 'get');
            spyOn(authorizer, 'listThings');
            spyOn(apiGateway, 'createResponse');
            spyOn(apiGateway, 'createErrorResponse').and.returnValue(response);
            spyOn(container, 'shutdown').and.returnValue(Promise.resolve());
            return sut(event, context, function (err, result) {
                expect(apiGateway.getPrincipal).toHaveBeenCalled();
                expect(apiGateway.getStatusFilter).toHaveBeenCalled();
                expect(apiGateway.getOwner).toHaveBeenCalled();
                expect(container.get).not.toHaveBeenCalled();
                expect(authorizer.listThings).not.toHaveBeenCalled();
                expect(apiGateway.createResponse).not.toHaveBeenCalled();
                expect(apiGateway.createErrorResponse).toHaveBeenCalledWith(error);
                expect(result).toEqual(response);
            }, container, apiGateway)
                .then(function () {
                    expect(container.shutdown).toHaveBeenCalled();
                });
        });
        it('should call apiGateway.createErrorResponse() with the right parameters and callback() with its result ' +
            'if container.get() throws', function () {
            var error = new Error('error');
            var response = 'response';
            spyOn(apiGateway, 'getPrincipal');
            spyOn(apiGateway, 'getStatusFilter');
            spyOn(apiGateway, 'getOwner');
            spyOn(container, 'get').and.throwError(error);
            spyOn(authorizer, 'listThings');
            spyOn(apiGateway, 'createResponse');
            spyOn(apiGateway, 'createErrorResponse').and.returnValue(response);
            spyOn(container, 'shutdown').and.returnValue(Promise.resolve());
            return sut(event, context, function (err, result) {
                expect(apiGateway.getPrincipal).toHaveBeenCalled();
                expect(apiGateway.getStatusFilter).toHaveBeenCalled();
                expect(apiGateway.getOwner).toHaveBeenCalled();
                expect(container.get).toHaveBeenCalled();
                expect(authorizer.listThings).not.toHaveBeenCalled();
                expect(apiGateway.createResponse).not.toHaveBeenCalled();
                expect(apiGateway.createErrorResponse).toHaveBeenCalledWith(error);
                expect(result).toEqual(response);
            }, container, apiGateway)
                .then(function () {
                    expect(container.shutdown).toHaveBeenCalled();
                });
        });
        it('should call apiGateway.createErrorResponse() with the right parameters and callback() with its result ' +
            'if authorizer.listThings() throws', function () {
            var error = new Error('error');
            var response = 'response';
            spyOn(apiGateway, 'getPrincipal');
            spyOn(apiGateway, 'getStatusFilter');
            spyOn(apiGateway, 'getOwner');
            spyOn(container, 'get').and.returnValue(authorizer);
            spyOn(authorizer, 'listThings').and.returnValue(Promise.reject(error));
            spyOn(apiGateway, 'createResponse');
            spyOn(apiGateway, 'createErrorResponse').and.returnValue(response);
            spyOn(container, 'shutdown').and.returnValue(Promise.resolve());
            return sut(event, context, function (err, result) {
                expect(apiGateway.getPrincipal).toHaveBeenCalled();
                expect(apiGateway.getStatusFilter).toHaveBeenCalled();
                expect(apiGateway.getOwner).toHaveBeenCalled();
                expect(container.get).toHaveBeenCalled();
                expect(authorizer.listThings).toHaveBeenCalled();
                expect(apiGateway.createResponse).not.toHaveBeenCalled();
                expect(apiGateway.createErrorResponse).toHaveBeenCalledWith(error);
                expect(result).toEqual(response);
            }, container, apiGateway)
                .then(function () {
                    expect(container.shutdown).toHaveBeenCalled();
                });
        });
    });

});
