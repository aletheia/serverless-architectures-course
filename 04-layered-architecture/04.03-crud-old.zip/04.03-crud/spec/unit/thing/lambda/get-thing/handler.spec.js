'use strict';

var Handler = require('../../../../../src/thing/lambda/get-thing/handler.js'),
    Promise = require('bluebird');

describe('GetThing lambda', function () {
    var event, context, authorizer, container, apiGateway, sut;
    beforeEach(function () {
        event = 'event';
        context = 'context';
        authorizer = {
            getThing: function () {
            }
        };
        container = {
            get: function () {
            },
            shutdown: function () {
            },
        };
        apiGateway = {
            getPrincipal: function () {
            },
            getUuid: function () {
            },
            getStatusFilter: function () {
            },
            createLastModifiedHeader: function () {
            },
            wasModifiedSinceIfModifiedSince: function () {
            },
            createResponse: function () {
            },
            createErrorResponse: function () {
            }
        };
        sut = Handler.handler;
    });

    describe('handler()', function () {
        it('should call apiGateway.getPrincipal(), apiGateway.getUuid(), apiGateway.getStatusFilter(), ' +
            'container.get(), authorizer.getThing(), apiGateway.wasModifiedSinceIfModifiedSince(), ' +
            'apiGateway.createLastModifiedHeader(), apiGateway.createResponse(), container.shutdown() ' +
            'with the right parameters and callback() with the result of apiGateway.createResponse() ' +
            '[when the thing has been modified since If-Modified-Since]', function () {
            var uuid = 'uuid';
            var statusFilter = 'statusFilter';
            var principal = 'principal';
            var thing = { uuid: 'uuid' };
            var header = { 'header': 'value' };
            var response = 'response';
            spyOn(apiGateway, 'getPrincipal').and.returnValue(principal);
            spyOn(apiGateway, 'getUuid').and.returnValue(uuid);
            spyOn(apiGateway, 'getStatusFilter').and.returnValue(statusFilter);
            spyOn(container, 'get').and.returnValue(authorizer);
            spyOn(authorizer, 'getThing').and.returnValue(Promise.resolve(thing));
            spyOn(apiGateway, 'wasModifiedSinceIfModifiedSince').and.returnValue(true);
            spyOn(apiGateway, 'createLastModifiedHeader').and.returnValue(header);
            spyOn(apiGateway, 'createResponse').and.returnValue(response);
            spyOn(apiGateway, 'createErrorResponse');
            spyOn(container, 'shutdown').and.returnValue(Promise.resolve());
            return sut(event, context, function (err, result) {
                expect(apiGateway.getPrincipal).toHaveBeenCalled();
                expect(apiGateway.getUuid).toHaveBeenCalled();
                expect(apiGateway.getStatusFilter).toHaveBeenCalled();
                expect(container.get).toHaveBeenCalledWith('thing.authorizer');
                expect(authorizer.getThing).toHaveBeenCalledWith(
                    principal,
                    { uuid: uuid, statusFilter: statusFilter }
                );
                expect(apiGateway.wasModifiedSinceIfModifiedSince).toHaveBeenCalled();
                expect(apiGateway.createLastModifiedHeader).toHaveBeenCalledWith(thing);
                expect(apiGateway.createResponse).toHaveBeenCalledWith(
                    200,
                    { 'header': 'value', 'Cache-Control': 'must-revalidate' },
                    thing
                );
                expect(apiGateway.createErrorResponse).not.toHaveBeenCalled();
                expect(result).toEqual(response);
            }, container, apiGateway)
                .then(function () {
                    expect(container.shutdown).toHaveBeenCalled();
                });
        });
        it('should call apiGateway.getPrincipal(), apiGateway.getUuid(), apiGateway.getStatusFilter(), ' +
            'container.get(), authorizer.getThing(), apiGateway.wasModifiedSinceIfModifiedSince(), ' +
            'apiGateway.createResponse(), container.shutdown() ' +
            'with the right parameters and callback() with the result of apiGateway.createResponse() ' +
            '[when the thing has not been modified since If-Modified-Since]', function () {
            var uuid = 'uuid';
            var statusFilter = 'statusFilter';
            var principal = 'principal';
            var thing = { uuid: 'uuid' };
            var response = 'response';
            spyOn(apiGateway, 'getPrincipal').and.returnValue(principal);
            spyOn(apiGateway, 'getUuid').and.returnValue(uuid);
            spyOn(apiGateway, 'getStatusFilter').and.returnValue(statusFilter);
            spyOn(container, 'get').and.returnValue(authorizer);
            spyOn(authorizer, 'getThing').and.returnValue(Promise.resolve(thing));
            spyOn(apiGateway, 'wasModifiedSinceIfModifiedSince').and.returnValue(false);
            spyOn(apiGateway, 'createLastModifiedHeader');
            spyOn(apiGateway, 'createResponse').and.returnValue(response);
            spyOn(apiGateway, 'createErrorResponse');
            spyOn(container, 'shutdown').and.returnValue(Promise.resolve());
            return sut(event, context, function (err, result) {
                expect(apiGateway.getPrincipal).toHaveBeenCalled();
                expect(apiGateway.getUuid).toHaveBeenCalled();
                expect(apiGateway.getStatusFilter).toHaveBeenCalled();
                expect(container.get).toHaveBeenCalledWith('thing.authorizer');
                expect(authorizer.getThing).toHaveBeenCalledWith(
                    principal,
                    { uuid: uuid, statusFilter: statusFilter }
                );
                expect(apiGateway.wasModifiedSinceIfModifiedSince).toHaveBeenCalled();
                expect(apiGateway.createResponse).toHaveBeenCalledWith(304);
                expect(apiGateway.createErrorResponse).not.toHaveBeenCalled();
                expect(result).toEqual(response);
            }, container, apiGateway)
                .then(function () {
                    expect(container.shutdown).toHaveBeenCalled();
                });
        });
        it('should call apiGateway.createErrorResponse() with the right parameters and callback() with its result ' +
            'if apiGateway.getPrincipal() throws', function () {
            var error = new Error('error');
            var response = 'response';
            spyOn(apiGateway, 'getPrincipal').and.throwError(error);
            spyOn(apiGateway, 'getUuid');
            spyOn(apiGateway, 'getStatusFilter');
            spyOn(container, 'get');
            spyOn(authorizer, 'getThing');
            spyOn(apiGateway, 'wasModifiedSinceIfModifiedSince');
            spyOn(apiGateway, 'createLastModifiedHeader');
            spyOn(apiGateway, 'createResponse');
            spyOn(apiGateway, 'createErrorResponse').and.returnValue(response);
            spyOn(container, 'shutdown').and.returnValue(Promise.resolve());
            return sut(event, context, function (err, result) {
                expect(apiGateway.getPrincipal).toHaveBeenCalled();
                expect(apiGateway.getUuid).not.toHaveBeenCalled();
                expect(apiGateway.getStatusFilter).not.toHaveBeenCalled();
                expect(container.get).not.toHaveBeenCalled();
                expect(authorizer.getThing).not.toHaveBeenCalled();
                expect(apiGateway.wasModifiedSinceIfModifiedSince).not.toHaveBeenCalled();
                expect(apiGateway.createLastModifiedHeader).not.toHaveBeenCalled();
                expect(apiGateway.createResponse).not.toHaveBeenCalled();
                expect(apiGateway.createErrorResponse).toHaveBeenCalledWith(error);
                expect(result).toEqual(response);
            }, container, apiGateway)
                .then(function () {
                    expect(container.shutdown).toHaveBeenCalled();
                });
        });
        it('should call apiGateway.createErrorResponse() with the right parameters and callback() with its result ' +
            'if apiGateway.getUuid() throws', function () {
            var error = new Error('error');
            var response = 'response';
            spyOn(apiGateway, 'getPrincipal');
            spyOn(apiGateway, 'getUuid').and.throwError(error);
            spyOn(apiGateway, 'getStatusFilter');
            spyOn(container, 'get');
            spyOn(authorizer, 'getThing');
            spyOn(apiGateway, 'wasModifiedSinceIfModifiedSince');
            spyOn(apiGateway, 'createLastModifiedHeader');
            spyOn(apiGateway, 'createResponse');
            spyOn(apiGateway, 'createErrorResponse').and.returnValue(response);
            spyOn(container, 'shutdown').and.returnValue(Promise.resolve());
            return sut(event, context, function (err, result) {
                expect(apiGateway.getPrincipal).toHaveBeenCalled();
                expect(apiGateway.getUuid).toHaveBeenCalled();
                expect(apiGateway.getStatusFilter).not.toHaveBeenCalled();
                expect(container.get).not.toHaveBeenCalled();
                expect(authorizer.getThing).not.toHaveBeenCalled();
                expect(apiGateway.wasModifiedSinceIfModifiedSince).not.toHaveBeenCalled();
                expect(apiGateway.createLastModifiedHeader).not.toHaveBeenCalled();
                expect(apiGateway.createResponse).not.toHaveBeenCalled();
                expect(apiGateway.createErrorResponse).toHaveBeenCalledWith(error);
                expect(result).toEqual(response);
            }, container, apiGateway)
                .then(function () {
                    expect(container.shutdown).toHaveBeenCalled();
                });
        });
        it('should call apiGateway.createErrorResponse() with the right parameters and callback() with its result ' +
            'if apiGateway.getStatusFilter() throws', function () {
            var error = new Error('error');
            var response = 'response';
            spyOn(apiGateway, 'getPrincipal');
            spyOn(apiGateway, 'getUuid');
            spyOn(apiGateway, 'getStatusFilter').and.throwError(error);
            spyOn(container, 'get');
            spyOn(authorizer, 'getThing');
            spyOn(apiGateway, 'wasModifiedSinceIfModifiedSince');
            spyOn(apiGateway, 'createLastModifiedHeader');
            spyOn(apiGateway, 'createResponse');
            spyOn(apiGateway, 'createErrorResponse').and.returnValue(response);
            spyOn(container, 'shutdown').and.returnValue(Promise.resolve());
            return sut(event, context, function (err, result) {
                expect(apiGateway.getPrincipal).toHaveBeenCalled();
                expect(apiGateway.getUuid).toHaveBeenCalled();
                expect(apiGateway.getStatusFilter).toHaveBeenCalled();
                expect(container.get).not.toHaveBeenCalled();
                expect(authorizer.getThing).not.toHaveBeenCalled();
                expect(apiGateway.wasModifiedSinceIfModifiedSince).not.toHaveBeenCalled();
                expect(apiGateway.createLastModifiedHeader).not.toHaveBeenCalled();
                expect(apiGateway.createResponse).not.toHaveBeenCalled();
                expect(apiGateway.createErrorResponse).toHaveBeenCalledWith(error);
                expect(result).toEqual(response);
            }, container, apiGateway)
                .then(function () {
                    expect(container.shutdown).toHaveBeenCalled();
                });
        });
        it('should call apiGateway.createErrorResponse() with the right parameters and callback() with its result ' +
            'if container.get() throws', function () {
            var error = new Error('error');
            var response = 'response';
            spyOn(apiGateway, 'getPrincipal');
            spyOn(apiGateway, 'getUuid');
            spyOn(apiGateway, 'getStatusFilter');
            spyOn(container, 'get').and.throwError(error);
            spyOn(authorizer, 'getThing');
            spyOn(apiGateway, 'wasModifiedSinceIfModifiedSince');
            spyOn(apiGateway, 'createLastModifiedHeader');
            spyOn(apiGateway, 'createResponse');
            spyOn(apiGateway, 'createErrorResponse').and.returnValue(response);
            spyOn(container, 'shutdown').and.returnValue(Promise.resolve());
            return sut(event, context, function (err, result) {
                expect(apiGateway.getPrincipal).toHaveBeenCalled();
                expect(apiGateway.getUuid).toHaveBeenCalled();
                expect(apiGateway.getStatusFilter).toHaveBeenCalled();
                expect(container.get).toHaveBeenCalled();
                expect(authorizer.getThing).not.toHaveBeenCalled();
                expect(apiGateway.wasModifiedSinceIfModifiedSince).not.toHaveBeenCalled();
                expect(apiGateway.createLastModifiedHeader).not.toHaveBeenCalled();
                expect(apiGateway.createResponse).not.toHaveBeenCalled();
                expect(apiGateway.createErrorResponse).toHaveBeenCalledWith(error);
                expect(result).toEqual(response);
            }, container, apiGateway)
                .then(function () {
                    expect(container.shutdown).toHaveBeenCalled();
                });
        });
        it('should call apiGateway.createErrorResponse() with the right parameters and callback() with its result ' +
            'if authorizer.getThing() throws', function () {
            var error = new Error('error');
            var response = 'response';
            spyOn(apiGateway, 'getPrincipal');
            spyOn(apiGateway, 'getUuid');
            spyOn(apiGateway, 'getStatusFilter');
            spyOn(container, 'get').and.returnValue(authorizer);
            spyOn(authorizer, 'getThing').and.returnValue(Promise.reject(error));
            spyOn(apiGateway, 'wasModifiedSinceIfModifiedSince');
            spyOn(apiGateway, 'createLastModifiedHeader');
            spyOn(apiGateway, 'createResponse');
            spyOn(apiGateway, 'createErrorResponse').and.returnValue(response);
            spyOn(container, 'shutdown').and.returnValue(Promise.resolve());
            return sut(event, context, function (err, result) {
                expect(apiGateway.getPrincipal).toHaveBeenCalled();
                expect(apiGateway.getUuid).toHaveBeenCalled();
                expect(apiGateway.getStatusFilter).toHaveBeenCalled();
                expect(container.get).toHaveBeenCalled();
                expect(authorizer.getThing).toHaveBeenCalled();
                expect(apiGateway.wasModifiedSinceIfModifiedSince).not.toHaveBeenCalled();
                expect(apiGateway.createLastModifiedHeader).not.toHaveBeenCalled();
                expect(apiGateway.createResponse).not.toHaveBeenCalled();
                expect(apiGateway.createErrorResponse).toHaveBeenCalledWith(error);
                expect(result).toEqual(response);
            }, container, apiGateway)
                .then(function () {
                    expect(container.shutdown).toHaveBeenCalled();
                });
        });
        it('should call apiGateway.createErrorResponse() with the right parameters and callback() with its result ' +
            'if apiGateway.wasModifiedSinceIfModifiedSince() throws', function () {
            var error = new Error('error');
            var response = 'response';
            spyOn(apiGateway, 'getPrincipal');
            spyOn(apiGateway, 'getUuid');
            spyOn(apiGateway, 'getStatusFilter');
            spyOn(container, 'get').and.returnValue(authorizer);
            spyOn(authorizer, 'getThing').and.returnValue(Promise.resolve());
            spyOn(apiGateway, 'wasModifiedSinceIfModifiedSince').and.throwError(error);
            spyOn(apiGateway, 'createLastModifiedHeader');
            spyOn(apiGateway, 'createResponse');
            spyOn(apiGateway, 'createErrorResponse').and.returnValue(response);
            spyOn(container, 'shutdown').and.returnValue(Promise.resolve());
            return sut(event, context, function (err, result) {
                expect(apiGateway.getPrincipal).toHaveBeenCalled();
                expect(apiGateway.getUuid).toHaveBeenCalled();
                expect(apiGateway.getStatusFilter).toHaveBeenCalled();
                expect(container.get).toHaveBeenCalled();
                expect(authorizer.getThing).toHaveBeenCalled();
                expect(apiGateway.wasModifiedSinceIfModifiedSince).toHaveBeenCalled();
                expect(apiGateway.createLastModifiedHeader).not.toHaveBeenCalled();
                expect(apiGateway.createResponse).not.toHaveBeenCalled();
                expect(apiGateway.createErrorResponse).toHaveBeenCalledWith(error);
                expect(result).toEqual(response);
            }, container, apiGateway)
                .then(function () {
                    expect(container.shutdown).toHaveBeenCalled();
                });
        });
        it('should call apiGateway.createErrorResponse() with the right parameters and callback() with its result ' +
            'if apiGateway.createLastModifiedHeader() throws', function () {
            var error = new Error('error');
            var response = 'response';
            spyOn(apiGateway, 'getPrincipal');
            spyOn(apiGateway, 'getUuid');
            spyOn(apiGateway, 'getStatusFilter');
            spyOn(container, 'get').and.returnValue(authorizer);
            spyOn(authorizer, 'getThing').and.returnValue(Promise.resolve());
            spyOn(apiGateway, 'wasModifiedSinceIfModifiedSince').and.returnValue(true);
            spyOn(apiGateway, 'createLastModifiedHeader').and.throwError(error);
            spyOn(apiGateway, 'createResponse');
            spyOn(apiGateway, 'createErrorResponse').and.returnValue(response);
            spyOn(container, 'shutdown').and.returnValue(Promise.resolve());
            return sut(event, context, function (err, result) {
                expect(apiGateway.getPrincipal).toHaveBeenCalled();
                expect(apiGateway.getUuid).toHaveBeenCalled();
                expect(apiGateway.getStatusFilter).toHaveBeenCalled();
                expect(container.get).toHaveBeenCalled();
                expect(authorizer.getThing).toHaveBeenCalled();
                expect(apiGateway.wasModifiedSinceIfModifiedSince).toHaveBeenCalled();
                expect(apiGateway.createLastModifiedHeader).toHaveBeenCalled();
                expect(apiGateway.createResponse).not.toHaveBeenCalled();
                expect(apiGateway.createErrorResponse).toHaveBeenCalledWith(error);
                expect(result).toEqual(response);
            }, container, apiGateway)
                .then(function () {
                    expect(container.shutdown).toHaveBeenCalled();
                });
        });
    });

});
