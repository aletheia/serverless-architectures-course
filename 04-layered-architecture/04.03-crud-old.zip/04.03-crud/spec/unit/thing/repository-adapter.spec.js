'use strict';

var helper = require('../../helper'),
    RepositoryAdapter = require('../../../src/thing/repository-adapter.js'),
    Promise = require('bluebird'),
    NspError = require('../../../src/errors.js').NspError,
    _ = require('lodash');

describe('Thing RepositoryAdapter', function () {
    var thing, thingOutput, thingInput, thingInvalid, repository, sut;
    beforeEach(function () {
        thing = {
            uuid: '3305ea8b-4f0d-422b-a1e2-e7ba27122c0c',
            owner: 'ORG001',
            sku: 'AC-0165',
            content: [
                {
                    locale: 'en',
                    title: {
                        text: 'Very <b>important</b> title',
                        format: 'html'
                    }
                },
                {
                    locale: 'it',
                    title: {
                        text: 'Questo titolo &egrave;<br>molto <b style="color:red">importante</b>',
                        format: 'html'
                    }
                }
            ]
        };
        thingOutput = _.cloneDeep(thing);
        thingOutput._id = thing.uuid;
        delete thingOutput.uuid;
        thingInput = _.cloneDeep(thing);
        thingInvalid = _.cloneDeep(thing);
        delete thingInvalid.uuid;
        repository = {
            createThing: function () {
            },
            getThing: function () {
            },
            getThingByOwnerAndSku: function () {
            },
            getThingForChecks: function () {
            },
            updateThing: function () {
            },
            deleteThing: function () {
            },
            listThings: function () {
            },
            listThingsReferencingAsset: function () {
            },
            searchThingsByTags: function () {
            },
            listThingsReferencingCollection: function () {
            }
        };
        sut = new RepositoryAdapter(helper.getLoggerMock(), repository);
    });
    describe('createThing()', function () {
        it('should rename the input uuid string into _id', function () {
            spyOn(repository, 'createThing').and.returnValue(Promise.resolve(_.cloneDeep(thingOutput)));
            return sut.createThing(thingInput)
                .then(function () {
                    var repoCallParam = repository.createThing.calls.mostRecent().args[0];
                    expect(repoCallParam._id).toBe(thing.uuid);
                    expect(repoCallParam.uuid).toBeUndefined();
                });
        });
        it('should rename the output _id into uuid', function () {
            spyOn(repository, 'createThing').and.returnValue(Promise.resolve(_.cloneDeep(thingOutput)));
            return sut.createThing(thing)
                .then(function (result) {
                    expect(result._id).toBeUndefined();
                    expect(result.uuid).toBe(thingOutput._id);
                });
        });
        it('should pass a thing with no uuid as-is, without adding _id', function () {
            spyOn(repository, 'createThing').and.returnValue(Promise.resolve(_.cloneDeep(thingOutput)));
            return sut.createThing(thingInvalid)
                .then(function () {
                    expect(repository.createThing).toHaveBeenCalled();
                    var thingArgument = repository.createThing.calls.mostRecent().args[0];
                    expect(thingArgument._id).toBeUndefined();
                    expect(thingArgument.uuid).toBeUndefined();
                    expect(thingArgument.owner).toBe(thing.owner);
                    expect(thingArgument.content[0].locale).toBe(thing.content[0].locale);
                    expect(thingArgument.content[1].locale).toBe(thing.content[1].locale);
                    expect(thingArgument.content[0].title.text).toBe(thing.content[0].title.text);
                    expect(thingArgument.content[1].title.format).toBe(thing.content[1].title.format);
                });
        });
        it('should return a thing with no _id as-is, without adding uuid', function () {
            spyOn(repository, 'createThing').and.returnValue(Promise.resolve(_.cloneDeep(thingInvalid)));
            return sut.createThing(thing)
                .then(function (result) {
                    expect(result._id).toBeUndefined();
                    expect(result.uuid).toBeUndefined();
                    expect(result.owner).toBe(thingInvalid.owner);
                    expect(result.content[0].locale).toBe(thingInvalid.content[0].locale);
                    expect(result.content[1].locale).toBe(thingInvalid.content[1].locale);
                    expect(result.content[0].title.text).toBe(thingInvalid.content[0].title.text);
                    expect(result.content[1].title.format).toBe(thingInvalid.content[1].title.format);
                });
        });
        it('should not mangle the input', function () {
            spyOn(repository, 'createThing').and.returnValue(Promise.resolve(_.cloneDeep(thingOutput)));
            return sut.createThing(thingInput)
                .then(function () {
                    var repoCallParam = repository.createThing.calls.mostRecent().args[0];
                    expect(thingInput._id).toBeUndefined();
                    expect(thingInput.uuid).toBe(thing.uuid);
                    expect(repoCallParam._id).toBe(thing.uuid);
                });
        });
        it('should throw if an invalid ID is passed (non-string)', function () {
            spyOn(repository, 'createThing').and.returnValue(Promise.resolve(_.cloneDeep(thingOutput)));
            thingInvalid.uuid = 213;
            return sut.createThing(thingInvalid)
                .then(helper.thenFail)
                .catch(function (err) {
                    expect(err.code).toBe(NspError.codes.INTERNAL_SERVER_ERROR);
                    expect(err.message).toBe('Invalid UUID');
                    expect(repository.createThing).not.toHaveBeenCalled();
                });
        });
        it('should propagate any error from the repository', function () {
            spyOn(repository, 'createThing').and.returnValue(Promise.reject(new Error('dummy')));
            return sut.createThing(thingInput)
                .then(helper.thenFail)
                .catch(function (err) {
                    expect(err.message).toBe('dummy');
                });
        });
    });
    describe('getThing()', function () {
        it('should call repository.getThing() with the given uuid', function () {
            spyOn(repository, 'getThing').and.returnValue(Promise.resolve(_.cloneDeep(thingOutput)));
            return sut.getThing(thing.uuid)
                .then(function () {
                    expect(repository.getThing).toHaveBeenCalledWith(thing.uuid);
                });
        });
        it('should rename the output _id into uuid', function () {
            spyOn(repository, 'getThing').and.returnValue(Promise.resolve(_.cloneDeep(thingOutput)));
            return sut.getThing(thing.uuid)
                .then(function (result) {
                    expect(result._id).toBeUndefined();
                    expect(result.uuid).toBe(thingOutput._id);
                });
        });
        it('it should return a null value if received from repository', function () {
            spyOn(repository, 'getThing').and.returnValue(Promise.resolve(null));
            return sut.getThing(thing.uuid)
                .then(function (result) {
                    expect(result).toBeNull();
                });
        });
        it('should propagate any error from the repository', function () {
            spyOn(repository, 'getThing').and.returnValue(Promise.reject(new Error('dummy')));
            return sut.getThing(thing.uuid)
                .then(helper.thenFail)
                .catch(function (err) {
                    expect(err.message).toBe('dummy');
                });
        });
    });
    describe('getThingByOwnerAndSku()', function () {
        it('should call repository.getThingByOwnerAndSku() with the given owner and sku', function () {
            spyOn(repository, 'getThingByOwnerAndSku').and.returnValue(Promise.resolve(_.cloneDeep(thingOutput)));
            return sut.getThingByOwnerAndSku(thing.owner, thing.sku)
                .then(function () {
                    expect(repository.getThingByOwnerAndSku).toHaveBeenCalledWith(thing.owner, thing.sku);
                });
        });
        it('should rename the output _id into uuid', function () {
            spyOn(repository, 'getThingByOwnerAndSku').and.returnValue(Promise.resolve(_.cloneDeep(thingOutput)));
            return sut.getThingByOwnerAndSku(thing.owner, thing.sku)
                .then(function (result) {
                    expect(result._id).toBeUndefined();
                    expect(result.uuid).toBe(thingOutput._id);
                });
        });
        it('it should return a null value if received from repository', function () {
            spyOn(repository, 'getThingByOwnerAndSku').and.returnValue(Promise.resolve(null));
            return sut.getThingByOwnerAndSku(thing.owner, thing.sku)
                .then(function (result) {
                    expect(result).toBeNull();
                });
        });
        it('should propagate any error from the repository', function () {
            spyOn(repository, 'getThingByOwnerAndSku').and.returnValue(Promise.reject(new Error('dummy')));
            return sut.getThingByOwnerAndSku(thing.owner, thing.sku)
                .then(helper.thenFail)
                .catch(function (err) {
                    expect(err.message).toBe('dummy');
                });
        });
    });
    describe('getThingForChecks()', function () {
        it('should call repository.getThingForChecks() with the given uuid', function () {
            spyOn(repository, 'getThingForChecks').and.returnValue(Promise.resolve(_.cloneDeep({
                _id: thingOutput._id,
                owner: thingOutput.owner
            })));
            return sut.getThingForChecks(thing.uuid)
                .then(function () {
                    expect(repository.getThingForChecks).toHaveBeenCalledWith(thing.uuid);
                });
        });
        it('should rename the output _id into uuid', function () {
            spyOn(repository, 'getThingForChecks').and.returnValue(Promise.resolve(_.cloneDeep({
                _id: thingOutput._id,
                owner: thingOutput.owner
            })));
            return sut.getThingForChecks(thing.uuid)
                .then(function (result) {
                    expect(result._id).toBeUndefined();
                    expect(result.uuid).toBe(thingOutput._id);
                });
        });
        it('it should return a null value if received from repository', function () {
            spyOn(repository, 'getThingForChecks').and.returnValue(Promise.resolve(null));
            return sut.getThingForChecks(thing.uuid)
                .then(function (result) {
                    expect(result).toBeNull();
                });
        });
        it('should propagate any error from the repository', function () {
            spyOn(repository, 'getThingForChecks').and.returnValue(Promise.reject(new Error('dummy')));
            return sut.getThingForChecks(thing.uuid)
                .then(helper.thenFail)
                .catch(function (err) {
                    expect(err.message).toBe('dummy');
                });
        });
    });
    describe('updateThing()', function () {
        it('should rename the input uuid string into _id', function () {
            spyOn(repository, 'updateThing').and.returnValue(Promise.resolve(_.cloneDeep(thingOutput)));
            return sut.updateThing(thingInput)
                .then(function () {
                    var repoCallParam = repository.updateThing.calls.mostRecent().args[0];
                    expect(repoCallParam._id).toBe(thing.uuid);
                    expect(repoCallParam.uuid).toBeUndefined();
                });
        });
        it('should rename the output _id into uuid', function () {
            spyOn(repository, 'updateThing').and.returnValue(Promise.resolve(_.cloneDeep(thingOutput)));
            return sut.updateThing(thing)
                .then(function (result) {
                    expect(result._id).toBeUndefined();
                    expect(result.uuid).toBe(thingOutput._id);
                });
        });
        it('should not mangle the input', function () {
            spyOn(repository, 'updateThing').and.returnValue(Promise.resolve(_.cloneDeep(thingOutput)));
            return sut.updateThing(thingInput)
                .then(function () {
                    var repoCallParam = repository.updateThing.calls.mostRecent().args[0];
                    expect(thingInput._id).toBeUndefined();
                    expect(thingInput.uuid).toBe(thing.uuid);
                    expect(repoCallParam._id).toBe(thing.uuid);
                });
        });
        it('should throw if an invalid ID is passed (non-string)', function () {
            spyOn(repository, 'updateThing').and.returnValue(Promise.resolve(_.cloneDeep(thingOutput)));
            thingInvalid.uuid = 213;
            return sut.updateThing(thingInvalid)
                .then(helper.thenFail)
                .catch(function (err) {
                    expect(err.code).toBe(NspError.codes.INTERNAL_SERVER_ERROR);
                    expect(err.message).toBe('Invalid UUID');
                    expect(repository.updateThing).not.toHaveBeenCalled();
                });
        });
        it('should propagate any error from the repository', function () {
            spyOn(repository, 'updateThing').and.returnValue(Promise.reject(new Error('dummy')));
            return sut.updateThing(thingInput)
                .then(helper.thenFail)
                .catch(function (err) {
                    expect(err.message).toBe('dummy');
                });
        });
    });
    describe('deleteThing()', function () {
        it('should rename the input uuid string into _id', function () {
            spyOn(repository, 'deleteThing').and.returnValue(Promise.resolve({}));
            return sut.deleteThing(thingInput)
                .then(function () {
                    var repoCallParam = repository.deleteThing.calls.mostRecent().args[0];
                    expect(repoCallParam._id).toBe(thing.uuid);
                    expect(repoCallParam.uuid).toBeUndefined();
                });
        });
        it('should not mangle the input', function () {
            spyOn(repository, 'deleteThing').and.returnValue(Promise.resolve({}));
            return sut.deleteThing(thingInput)
                .then(function () {
                    var repoCallParam = repository.deleteThing.calls.mostRecent().args[0];
                    expect(thingInput._id).toBeUndefined();
                    expect(thingInput.uuid).toBe(thing.uuid);
                    expect(repoCallParam._id).toBe(thing.uuid);
                });
        });
        it('should propagate any error from the repository', function () {
            spyOn(repository, 'deleteThing').and.returnValue(Promise.reject(new Error('dummy')));
            return sut.deleteThing(thingInput)
                .then(helper.thenFail)
                .catch(function (err) {
                    expect(err.message).toBe('dummy');
                });
        });
        it('should throw if an invalid ID is passed (non-string)', function () {
            spyOn(repository, 'deleteThing').and.returnValue(Promise.resolve({}));
            thingInvalid.uuid = 213;
            return sut.deleteThing(thingInvalid)
                .then(helper.thenFail)
                .catch(function (err) {
                    expect(err.code).toBe(NspError.codes.INTERNAL_SERVER_ERROR);
                    expect(err.message).toBe('Invalid UUID');
                    expect(repository.deleteThing).not.toHaveBeenCalled();
                });
        });
    });
    describe('listThings()', function () {
        var listResult;
        beforeEach(function () {
            var outputStub = _.clone(thingOutput);
            delete outputStub._id;
            listResult = [
                _.merge({ _id: 'uuid1' }, _.cloneDeep(outputStub)),
                _.merge({ _id: 'uuid2' }, _.cloneDeep(outputStub)),
                _.merge({ _id: 'uuid3' }, _.cloneDeep(outputStub)),
                _.merge({ _id: 'uuid4' }, _.cloneDeep(outputStub))
            ];
        });
        it('should call the repository.listThings with the given parameter', function () {
            spyOn(repository, 'listThings').and.returnValue(Promise.resolve(_.cloneDeep(listResult)));
            return sut.listThings({ owner: 'dummy' })
                .then(function () {
                    expect(repository.listThings).toHaveBeenCalledWith({ owner: 'dummy' });
                });
        });
        it('should rename the all output _id(s) into uuid(s)', function () {
            spyOn(repository, 'listThings').and.returnValue(Promise.resolve(_.cloneDeep(listResult)));
            return sut.listThings({ owner: 'dummy' })
                .then(function (result) {
                    expect(result).toBeArrayOfSize(listResult.length);
                    _.forEach(result, function (doc, idx) {
                        expect(doc._id).toBeUndefined();
                        expect(doc.uuid).toBe(listResult[idx]._id);
                    });
                });
        });
        it('should propagate any error from the repository', function () {
            spyOn(repository, 'listThings').and.returnValue(Promise.reject(new Error('dummy err')));
            return sut.listThings({ owner: 'dummy' })
                .then(helper.thenFail)
                .catch(function (err) {
                    expect(err.message).toBe('dummy err');
                });
        });
        it('should propagate any statusFilter to the repository', function () {
            spyOn(repository, 'listThings').and.returnValue(Promise.resolve(_.cloneDeep(listResult)));
            return sut.listThings({ owner: 'dummy', statusFilter: 'a-status' })
                .then(function () {
                    var params = repository.listThings.calls.mostRecent().args[0];
                    expect(params.statusFilter).toBe('a-status');
                });
        });
    });

    describe('listThingsReferencingAsset()', function () {
        var listResult;
        beforeEach(function () {
            var outputStub = _.clone(thingOutput);
            delete outputStub._id;
            listResult = [
                _.merge({ _id: 'uuid1' }, _.cloneDeep(outputStub)),
                _.merge({ _id: 'uuid2' }, _.cloneDeep(outputStub)),
                _.merge({ _id: 'uuid3' }, _.cloneDeep(outputStub)),
                _.merge({ _id: 'uuid4' }, _.cloneDeep(outputStub))
            ];
        });
        it('should call the repository.listThingsReferencingAsset with the given parameters', function () {
            spyOn(repository, 'listThingsReferencingAsset').and.returnValue(Promise.resolve(listResult));
            return sut.listThingsReferencingAsset({ owner: 'arg1', assetId: 'arg2' })
                .then(function () {
                    expect(repository.listThingsReferencingAsset).toHaveBeenCalledWith(
                        { owner: 'arg1', assetId: 'arg2' }
                    );
                });
        });
        it('should rename the all output _id(s) into uuid(s)', function () {
            spyOn(repository, 'listThingsReferencingAsset').and
                .returnValue(Promise.resolve(_.cloneDeep(listResult)));
            return sut.listThingsReferencingAsset({ owner: 'arg1', assetId: 'arg2' })
                .then(function (result) {
                    expect(result).toBeArrayOfSize(listResult.length);
                    _.forEach(result, function (doc, idx) {
                        expect(doc._id).toBeUndefined();
                        expect(doc.uuid).toBe(listResult[idx]._id);
                    });
                });
        });
        it('should propagate any error from the repository', function () {
            spyOn(repository, 'listThingsReferencingAsset').and.returnValue(Promise.reject(new Error('dummy')));
            return sut.listThingsReferencingAsset({ owner: 'dummy' })
                .then(helper.thenFail)
                .catch(function (err) {
                    expect(err.message).toBe('dummy');
                });
        });
        it('should propagate any statusFilter to the repository', function () {
            spyOn(repository, 'listThingsReferencingAsset').and.returnValue(Promise.resolve(_.cloneDeep(listResult)));
            return sut.listThingsReferencingAsset({ owner: 'a', assetId: 'b', statusFilter: 'a-status' })
                .then(function () {
                    var params = repository.listThingsReferencingAsset.calls.mostRecent().args[0];
                    expect(params.statusFilter).toBe('a-status');
                });
        });
    });

    describe('searchThingsByTags()', function () {
        var listResult;
        beforeEach(function () {
            var outputStub = _.clone(thingOutput);
            delete outputStub._id;
            listResult = [
                _.merge({ _id: 'uuid1' }, _.cloneDeep(outputStub)),
                _.merge({ _id: 'uuid2' }, _.cloneDeep(outputStub)),
                _.merge({ _id: 'uuid3' }, _.cloneDeep(outputStub)),
                _.merge({ _id: 'uuid4' }, _.cloneDeep(outputStub))
            ];
        });
        it('should call the repository.searchThingsByTags with the given parameters', function () {
            spyOn(repository, 'searchThingsByTags').and.returnValue(Promise.resolve(listResult));
            return sut.searchThingsByTags({ owner: 'arg1', tags: ['arg2'], locale: 'arg3' })
                .then(function () {
                    expect(repository.searchThingsByTags).toHaveBeenCalledWith(
                        { owner: 'arg1', tags: ['arg2'], locale: 'arg3' }
                    );
                });
        });
        it('should call the repository.searchThingsByTags with the given parameters, missing locale' +
            ' should be passed as undefined', function () {
            spyOn(repository, 'searchThingsByTags').and.returnValue(Promise.resolve(listResult));
            return sut.searchThingsByTags({ owner: 'arg1', tags: ['arg2-1', 'arg2-2'] })
                .then(function () {
                    expect(repository.searchThingsByTags)
                        .toHaveBeenCalledWith({ owner: 'arg1', tags: ['arg2-1', 'arg2-2'] });
                });
        });
        it('should call the repository.searchThingsByTags with the given parameters, locale can be an ' +
            ' array', function () {
            spyOn(repository, 'searchThingsByTags').and.returnValue(Promise.resolve(listResult));
            return sut.searchThingsByTags({ owner: 'arg1', tags: ['arg2-1', 'arg2-2'], locale: ['arg3'] })
                .then(function () {
                    expect(repository.searchThingsByTags)
                        .toHaveBeenCalledWith({ owner: 'arg1', tags: ['arg2-1', 'arg2-2'], locale: ['arg3'] });
                });
        });
        it('should rename the all output _id(s) into uuid(s)', function () {
            spyOn(repository, 'searchThingsByTags').and
                .returnValue(Promise.resolve(_.cloneDeep(listResult)));
            return sut.searchThingsByTags({ owner: 'arg1', tags: 'arg2', locale: 'arg3' })
                .then(function (result) {
                    expect(result).toBeArrayOfSize(listResult.length);
                    _.forEach(result, function (doc, idx) {
                        expect(doc._id).toBeUndefined();
                        expect(doc.uuid).toBe(listResult[idx]._id);
                    });
                });
        });
        it('should propagate any error from the repository', function () {
            spyOn(repository, 'searchThingsByTags').and.returnValue(Promise.reject(new Error('dummy')));
            return sut.searchThingsByTags({ owner: 'dummy' })
                .then(helper.thenFail)
                .catch(function (err) {
                    expect(err.message).toBe('dummy');
                });
        });
        it('should propagate any statusFilter to the repository', function () {
            spyOn(repository, 'searchThingsByTags').and.returnValue(Promise.resolve(_.cloneDeep(listResult)));
            return sut.searchThingsByTags({ owner: 'a', tags: 'b', statusFilter: 'a-status' })
                .then(function () {
                    var params = repository.searchThingsByTags.calls.mostRecent().args[0];
                    expect(params.statusFilter).toBe('a-status');
                });
        });
    });

    describe('listThingsReferencingCollection()', function () {
        var listResult;
        beforeEach(function () {
            listResult = [
                { uuid: 'uuid1', name: 'name1', description: 'description1' },
                { uuid: 'uuid2', name: 'name2', description: 'description2' },
                { uuid: 'uuid3', name: 'name3', description: 'description3' },
                { uuid: 'uuid4', name: 'name4', description: 'description4' },
            ];
        });
        it('should call the repository.listThingsReferencingCollection with the given parameters', function () {
            spyOn(repository, 'listThingsReferencingCollection').and.returnValue(Promise.resolve(listResult));
            return sut.listThingsReferencingCollection('arg1', 'arg2')
                .then(function () {
                    expect(repository.listThingsReferencingCollection).toHaveBeenCalledWith('arg1', 'arg2');
                });
        });
        it('should rename the all output _id(s) into uuid(s)', function () {
            spyOn(repository, 'listThingsReferencingCollection').and
                .returnValue(Promise.resolve(_.cloneDeep(listResult)));
            return sut.listThingsReferencingCollection('arg1', 'arg2')
                .then(function (result) {
                    expect(result).toBeArrayOfSize(listResult.length);
                    _.forEach(result, function (doc, idx) {
                        expect(doc._id).toBeUndefined();
                        expect(doc.uuid).toBe(listResult[idx]._id);
                    });
                });
        });
        it('should propagate any error from the repository', function () {
            spyOn(repository, 'listThingsReferencingCollection').and.returnValue(Promise.reject(new Error('dummy')));
            return sut.listThingsReferencingCollection('arg1', 'arg2')
                .then(helper.thenFail)
                .catch(function (err) {
                    expect(err.message).toBe('dummy');
                });
        });
    });

});
