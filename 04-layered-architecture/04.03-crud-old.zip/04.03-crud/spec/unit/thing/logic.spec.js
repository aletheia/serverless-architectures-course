'use strict';

var helper = require('../../helper'),
    localizationSchema = require('../../../resources/json-schemas/thing-localization.json'),
    Logic = require('../../../src/thing/logic.js'),
    Promise = require('bluebird');

describe('Thing Logic', function () {
    var repository, sut, uuid;
    beforeEach(function () {
        repository = {
            createThing: function () {
            },
            getThing: function () {
            },
            getThingForChecks: function () {
            },
            getThingByOwnerAndSku: function () {
            },
            updateThing: function () {
            },
            deleteThing: function () {
            },
            listThings: function () {
            },
            searchThingsByTags: function () {
            }
        };
        sut = new Logic(helper.getLoggerMock(), repository);
        uuid = '3305ea8b-4f0d-422b-a1e2-e7ba27122c0c';
    });

    describe('thingNotFoundErrorFactory()', function () {
        it('should create the expected PRODUCT_NOT_FOUND NspError', function () {
            var err = sut.thingNotFoundErrorFactory(uuid);
            expect(err.code).toBe('PRODUCT_NOT_FOUND');
            expect(err.message).toBe('Thing "' + uuid + '" not found');
            expect(err.causes).toBeEmptyArray();
        });
    });

    describe('createThing()', function () {
        it('should check for duplicates if thing contains uuid', function () {
            var thing = {
                uuid: 'foo',
                owner: principal.organizationId,
                thumbnail: {
                    assetId: '001'
                }
            };
            spyOn(repository, 'getThing').and.returnValue(Promise.resolve(null));
            spyOn(repository, 'getThingByOwnerAndSku').and.returnValue(Promise.resolve(null));
            spyOn(contentManager, 'createContent').and.returnValue(Promise.resolve());
            spyOn(contentManager.assetManager, 'resolveAssets').and.returnValue(Promise.resolve([
                { thumbnail: 'http://www.example.com/thumb.jpg' }
            ]));
            spyOn(contentManager.assetManager, 'referenceAssets').and.returnValue(Promise.resolve());
            spyOn(repository, 'createThing').and.returnValue(Promise.resolve('dummyObject'));
            return sut.createThing(principal, thing)
                .then(function (result) {
                    expect(result).toBe('dummyObject');
                    expect(repository.getThing).toHaveBeenCalledWith('foo');
                });
        });
        it('should throw if a conflicting thing uuid is detected', function () {
            var thing = { uuid: 'foo', owner: principal.organizationId };
            spyOn(repository, 'getThing').and.returnValue(Promise.resolve(thing));
            spyOn(contentManager, 'createContent');
            spyOn(contentManager.assetManager, 'resolveAssets');
            spyOn(contentManager.assetManager, 'referenceAssets');
            spyOn(repository, 'createThing');
            return sut.createThing(principal, thing)
                .then(helper.thenFail)
                .catch(function (err) {
                    expect(err.code).toBe('PRODUCT_ALREADY_EXISTS');
                    expect(err.message).toBe('Thing "' + thing.uuid + '" already exists');
                    expect(err.causes).toBeEmptyArray();
                    expect(contentManager.createContent).not.toHaveBeenCalled();
                    expect(contentManager.assetManager.resolveAssets).not.toHaveBeenCalled();
                    expect(contentManager.assetManager.referenceAssets).not.toHaveBeenCalled();
                    expect(repository.createThing).not.toHaveBeenCalled();
                });
        });
        it('should throw on invalid relatedThingsCollectionId', function () {
            var thing = {
                owner: principal.organizationId,
                thumbnail: {
                    assetId: '001'
                },
                relatedThingsCollectionId: 'unknown'
            };
            spyOn(messageBusClient, 'request').and.returnValue(Promise.reject(new Error('error')));
            spyOn(contentManager, 'createContent');
            spyOn(contentManager.assetManager, 'resolveAssets');
            spyOn(contentManager.assetManager, 'referenceAssets');
            spyOn(repository, 'createThing');
            spyOn(eventBus, 'publishThingCreatedEvent');
            return sut.createThing(principal, thing)
                .then(helper.thenFail)
                .catch(function (err) {
                    expect(err).toEqual(new Error('error'));
                    expect(messageBusClient.request).toHaveBeenCalledWith(
                        'collection',
                        'get-collection',
                        { principal: principal, uuid: 'unknown' }
                    );
                    expect(contentManager.createContent).not.toHaveBeenCalled();
                    expect(contentManager.assetManager.resolveAssets).not.toHaveBeenCalled();
                    expect(contentManager.assetManager.referenceAssets).not.toHaveBeenCalled();
                    expect(repository.createThing).not.toHaveBeenCalled();
                    expect(eventBus.publishThingCreatedEvent).not.toHaveBeenCalled();
                });
        });
        it('should throw on duplicated sku', function () {
            var thing = {
                sku: 'sku',
                owner: 'owner'
            };
            var thingBySku = {
                uuid: 'uuid',
                name: 'name',
                description: 'description',
                otherData: 'otherData'
            };
            spyOn(repository, 'getThingByOwnerAndSku').and.returnValue(Promise.resolve(thingBySku));
            return sut.createThing(principal, thing)
                .then(helper.thenFail)
                .catch(function (err) {
                    expect(err.code).toBe('DUPLICATED_PRODUCT_SKU');
                    expect(err.message).toBe('Duplicated sku "sku"');
                    expect(err.causes).toEqual([
                        'It is already used by thing {"uuid":"uuid","name":"name","description":"description"}'
                    ]);
                    expect(repository.getThingByOwnerAndSku).toHaveBeenCalledWith('owner', 'sku');
                });
        });
        it('should throw on invalid thumbnail', function () {
            spyOn(repository, 'getThingByOwnerAndSku').and.returnValue(Promise.resolve(null));
            spyOn(contentManager, 'createContent').and.returnValue(Promise.resolve());
            spyOn(contentManager.assetManager, 'resolveAssets')
                .and.returnValue(Promise.reject(new Error('Unknown assetId')));
            spyOn(contentManager.assetManager, 'referenceAssets');
            spyOn(repository, 'createThing');
            spyOn(eventBus, 'publishThingCreatedEvent');
            return sut.createThing(principal, { thumbnail: { assetId: '001' } })
                .then(helper.thenFail)
                .catch(function (err) {
                    expect(err).toEqual(new Error('Unknown assetId'));
                    expect(contentManager.createContent).not.toHaveBeenCalled();
                    expect(contentManager.assetManager.resolveAssets).toHaveBeenCalledWith(principal, ['001']);
                    expect(contentManager.assetManager.referenceAssets).not.toHaveBeenCalled();
                    expect(repository.createThing).not.toHaveBeenCalled();
                    expect(eventBus.publishThingCreatedEvent).not.toHaveBeenCalled();
                });
        });
        it('should throw on invalid content', function () {
            spyOn(repository, 'getThingByOwnerAndSku').and.returnValue(Promise.resolve(null));
            spyOn(contentManager, 'createContent').and.returnValue(Promise.reject(new Error('Invalid content')));
            spyOn(contentManager.assetManager, 'resolveAssets')
                .and.returnValue(Promise.resolve([{ thumbnail: 'dummy' }]));
            spyOn(contentManager.assetManager, 'referenceAssets').and.returnValue(Promise.resolve());
            spyOn(repository, 'createThing');
            spyOn(eventBus, 'publishThingCreatedEvent');
            var thing = {
                thumbnail: { assetId: '001' },
                content: ['localization1', 'localization2']
            };
            return sut.createThing(principal, thing)
                .then(helper.thenFail)
                .catch(function (err) {
                    expect(err).toEqual(new Error('Invalid content'));
                    expect(contentManager.assetManager.resolveAssets).toHaveBeenCalled();
                    expect(contentManager.createContent)
                        .toHaveBeenCalledWith(principal, thing.content, localizationSchema);
                    expect(contentManager.assetManager.referenceAssets).not.toHaveBeenCalled();
                    expect(repository.createThing).not.toHaveBeenCalled();
                    expect(eventBus.publishThingCreatedEvent).not.toHaveBeenCalled();
                });
        });
        it('should reference the thumbnail', function () {
            spyOn(repository, 'getThingByOwnerAndSku').and.returnValue(Promise.resolve(null));
            spyOn(contentManager, 'createContent').and.returnValue(Promise.resolve());
            spyOn(contentManager.assetManager, 'resolveAssets')
                .and.returnValue(Promise.resolve([{ thumbnail: 'dummy' }]));
            spyOn(contentManager.assetManager, 'referenceAssets').and.returnValue(Promise.resolve());
            spyOn(repository, 'createThing').and.returnValue(Promise.resolve());
            var thing = {
                thumbnail: { assetId: '001' }
            };
            return sut.createThing(principal, thing)
                .then(function () {
                    expect(contentManager.assetManager.referenceAssets).toHaveBeenCalledWith(
                        principal,
                        ['001']
                    );
                });
        });
        it('should return the created thing', function () {
            var thing = {
                owner: principal.organizationId,
                thumbnail: {
                    assetId: '001'
                }
            };
            spyOn(repository, 'getThingByOwnerAndSku').and.returnValue(Promise.resolve(null));
            spyOn(contentManager, 'createContent').and.returnValue(Promise.resolve());
            spyOn(contentManager.assetManager, 'resolveAssets').and.returnValue(Promise.resolve([
                { thumbnail: 'http://www.example.com/thumb.jpg' }
            ]));
            spyOn(contentManager.assetManager, 'referenceAssets').and.returnValue(Promise.resolve());
            spyOn(repository, 'createThing').and.returnValue(Promise.resolve(thing));
            return sut.createThing(principal, thing)
                .then(function (result) {
                    expect(contentManager.createContent).toHaveBeenCalled();
                    expect(contentManager.assetManager.resolveAssets).toHaveBeenCalledWith(principal, ['001']);
                    expect(contentManager.assetManager.referenceAssets).toHaveBeenCalledWith(principal, ['001']);
                    expect(repository.createThing).toHaveBeenCalled();
                    expect(result).toBe(thing);
                });
        });
        it('should set `uuid`, `created`, `lastModified`, `thumbnail.url`', function () {
            var thing = {
                thumbnail: {
                    assetId: '001'
                }
            };
            spyOn(repository, 'getThingByOwnerAndSku').and.returnValue(Promise.resolve(null));
            spyOn(contentManager, 'createContent').and.returnValue(Promise.resolve());
            spyOn(contentManager.assetManager, 'resolveAssets').and.returnValue(Promise.resolve([
                { thumbnail: 'http://www.example.com/thumb.jpg' }
            ]));
            spyOn(contentManager.assetManager, 'referenceAssets').and.returnValue(Promise.resolve());
            spyOn(repository, 'createThing').and.callFake(function (thing) {return Promise.resolve(thing);});
            return sut.createThing(principal, thing)
                .then(function (result) {
                    expect(contentManager.createContent).toHaveBeenCalled();
                    expect(contentManager.assetManager.resolveAssets).toHaveBeenCalled();
                    expect(contentManager.assetManager.referenceAssets).toHaveBeenCalled();
                    expect(repository.createThing).toHaveBeenCalled();
                    expect(result.uuid).toMatch(/^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/);
                    expect(result.created).toBeDate();
                    expect(result.lastModified).toEqual(result.created);
                    expect(result.thumbnail).toEqual({ assetId: '001', url: 'http://www.example.com/thumb.jpg' });
                });
        });
        it('should publish a PRODUCT_CREATED event with the created thing', function () {
            var thing = {
                uuid: 'foo',
                thumbnail: {}
            };
            spyOn(repository, 'getThing').and.returnValue(Promise.resolve(null));
            spyOn(repository, 'getThingByOwnerAndSku').and.returnValue(Promise.resolve(null));
            spyOn(contentManager, 'createContent').and.returnValue(Promise.resolve());
            spyOn(contentManager.assetManager, 'resolveAssets').and.returnValue(Promise.resolve([{}]));
            spyOn(contentManager.assetManager, 'referenceAssets').and.returnValue(Promise.resolve());
            spyOn(repository, 'createThing').and.returnValue(Promise.resolve(thing));
            spyOn(eventBus, 'publishThingCreatedEvent').and.returnValue(Promise.resolve());
            return sut.createThing(principal, thing)
                .then(function () {
                    expect(eventBus.publishThingCreatedEvent).toHaveBeenCalledWith(thing);
                });
        });
    });

    describe('getThing()', function () {
        it('should throw on thing not found', function () {
            spyOn(repository, 'getThing').and.returnValue(Promise.resolve(null));
            spyOn(principal, 'checkOwnership');
            return sut.getThing(principal, { uuid: uuid })
                .then(helper.thenFail)
                .catch(function (err) {
                    expect(repository.getThing).toHaveBeenCalled();
                    expect(principal.checkOwnership).not.toHaveBeenCalled();
                    expect(err.code).toBe('PRODUCT_NOT_FOUND');
                    expect(err.message).toBe('Thing "' + uuid + '" not found');
                    expect(err.causes).toBeEmptyArray();
                });
        });
        it('should call principal.checkOwnership() with the right parameters', function () {
            var thing = 'thing';
            spyOn(repository, 'getThing').and.returnValue(Promise.resolve(thing));
            spyOn(principal, 'checkOwnership');
            return sut.getThing(principal, { uuid: uuid })
                .then(function () {
                    expect(repository.getThing).toHaveBeenCalled();
                    expect(principal.checkOwnership)
                        .toHaveBeenCalledWith(thing, sut.thingNotFoundErrorFactory, undefined);
                });
        });
        it('should throw the error thrown by principal.checkOwnership()', function () {
            var thing = 'thing';
            spyOn(repository, 'getThing').and.returnValue(Promise.resolve(thing));
            spyOn(principal, 'checkOwnership').and.throwError(new Error('error'));
            return sut.getThing(principal, { uuid: uuid })
                .then(helper.thenFail)
                .catch(function (err) {
                    expect(err.message).toBe('error');
                    expect(repository.getThing).toHaveBeenCalled();
                    expect(principal.checkOwnership).toHaveBeenCalled();
                });
        });
        it('should return the thing', function () {
            var thing = 'thing';
            spyOn(repository, 'getThing').and.returnValue(Promise.resolve(thing));
            spyOn(principal, 'checkOwnership');
            return sut.getThing(principal, { uuid: uuid })
                .then(function (result) {
                    expect(repository.getThing).toHaveBeenCalled();
                    expect(principal.checkOwnership).toHaveBeenCalled();
                    expect(result).toBe(thing);
                });
        });
        it('should throw on thing with status not matching statusFilter', function () {
            var thing = { owner: 'ORG001', uuid: uuid, status: 'draft' };
            spyOn(repository, 'getThing').and.returnValue(Promise.resolve(thing));
            spyOn(principal, 'checkOwnership');
            return sut.getThing(principal, { uuid: uuid, statusFilter: 'published' })
                .then(helper.thenFail)
                .catch(function (err) {
                    expect(repository.getThing).toHaveBeenCalled();
                    expect(principal.checkOwnership).toHaveBeenCalled();
                    expect(err.code).toBe('PRODUCT_NOT_FOUND');
                    expect(err.message).toBe('Thing "' + uuid + '" not found');
                    expect(err.causes).toBeEmptyArray();
                });
        });
    });

    describe('getThingForChecks()', function () {
        it('should throw on thing not found', function () {
            spyOn(repository, 'getThingForChecks').and.returnValue(Promise.resolve(null));
            spyOn(principal, 'checkOwnership');
            return sut.getThingForChecks(principal, uuid)
                .then(helper.thenFail)
                .catch(function (err) {
                    expect(repository.getThingForChecks).toHaveBeenCalled();
                    expect(principal.checkOwnership).not.toHaveBeenCalled();
                    expect(err.code).toBe('PRODUCT_NOT_FOUND');
                    expect(err.message).toBe('Thing "' + uuid + '" not found');
                    expect(err.causes).toBeEmptyArray();
                });
        });
        it('should call principal.checkOwnership() with the right parameters', function () {
            var thing = 'thing';
            var owner = 'owner';
            spyOn(repository, 'getThingForChecks').and.returnValue(Promise.resolve(thing));
            spyOn(principal, 'checkOwnership');
            return sut.getThingForChecks(principal, uuid, owner)
                .then(function () {
                    expect(repository.getThingForChecks).toHaveBeenCalled();
                    expect(principal.checkOwnership)
                        .toHaveBeenCalledWith(thing, sut.thingNotFoundErrorFactory, owner);
                });
        });
        it('should throw the error thrown by principal.checkOwnership()', function () {
            var thing = 'thing';
            spyOn(repository, 'getThingForChecks').and.returnValue(Promise.resolve(thing));
            spyOn(principal, 'checkOwnership').and.throwError(new Error('error'));
            return sut.getThingForChecks(principal, uuid)
                .then(helper.thenFail)
                .catch(function (err) {
                    expect(err.message).toBe('error');
                    expect(repository.getThingForChecks).toHaveBeenCalled();
                    expect(principal.checkOwnership).toHaveBeenCalled();
                });
        });
        it('should return the thing', function () {
            var thing = 'thing';
            spyOn(repository, 'getThingForChecks').and.returnValue(Promise.resolve(thing));
            spyOn(principal, 'checkOwnership');
            return sut.getThingForChecks(principal, uuid)
                .then(function (result) {
                    expect(repository.getThingForChecks).toHaveBeenCalled();
                    expect(principal.checkOwnership).toHaveBeenCalled();
                    expect(result).toBe(thing);
                });
        });
    });

    describe('updateThing()', function () {
        it('should throw on thing not found', function () {
            spyOn(repository, 'getThing').and.returnValue(Promise.resolve(null));
            return sut.updateThing(principal, uuid, {})
                .then(helper.thenFail)
                .catch(function (err) {
                    expect(repository.getThing).toHaveBeenCalled();
                    expect(err.code).toBe('PRODUCT_NOT_FOUND');
                    expect(err.message).toBe('Thing "' + uuid + '" not found');
                    expect(err.causes).toBeEmptyArray();
                });
        });
        it('should call principal.checkOwnership() with the right parameters', function () {
            var oldThing = {
                thumbnail: {
                    assetId: '001',
                    url: 'http://www.example.com/thumbnails/thing001.png'
                }
            };
            var newThing = {
                thumbnail: {
                    assetId: '001',
                    url: 'http://www.example.com/thumbnails/thing001.png'
                }
            };
            spyOn(repository, 'getThing').and.returnValue(Promise.resolve(oldThing));
            spyOn(repository, 'getThingByOwnerAndSku').and.returnValue(Promise.resolve(oldThing));
            spyOn(principal, 'checkOwnership');
            return sut.updateThing(principal, uuid, newThing)
                .then(function () {
                    expect(repository.getThing).toHaveBeenCalled();
                    expect(principal.checkOwnership)
                        .toHaveBeenCalledWith(oldThing, sut.thingNotFoundErrorFactory, undefined);
                });
        });
        it('should throw the error thrown by principal.checkOwnership()', function () {
            var thing = 'thing';
            spyOn(repository, 'getThing').and.returnValue(Promise.resolve(thing));
            spyOn(principal, 'checkOwnership').and.throwError(new Error('error'));
            return sut.updateThing(principal, uuid, {})
                .then(helper.thenFail)
                .catch(function (err) {
                    expect(err.message).toBe('error');
                    expect(repository.getThing).toHaveBeenCalled();
                    expect(principal.checkOwnership).toHaveBeenCalled();
                });
        });
        it('should call principal.checkReadOnlyProperties() with the right parameters', function () {
            var oldThing = {
                thumbnail: {
                    assetId: '001',
                    url: 'http://www.example.com/thumbnails/thing001.png'
                }
            };
            var newThing = {
                thumbnail: {
                    assetId: '001',
                    url: 'http://www.example.com/thumbnails/thing001.png'
                }
            };
            spyOn(repository, 'getThing').and.returnValue(Promise.resolve(oldThing));
            spyOn(repository, 'getThingByOwnerAndSku').and.returnValue(Promise.resolve(oldThing));
            spyOn(principal, 'checkOwnership');
            spyOn(principal, 'checkReadOnlyProperties');
            return sut.updateThing(principal, uuid, newThing)
                .then(function () {
                    expect(repository.getThing).toHaveBeenCalled();
                    expect(principal.checkOwnership).toHaveBeenCalled();
                    expect(principal.checkReadOnlyProperties).toHaveBeenCalledWith(
                        oldThing,
                        newThing,
                        ['uuid', 'created', 'lastModified'],
                        'PRODUCT_UNPROCESSABLE',
                        []
                    );
                });
        });
        it('should call principal.checkReadOnlyProperties() with the right parameters ' +
            '[with modified thumbnail.url]', function () {
            var oldThing = {
                thumbnail: {
                    assetId: '001',
                    url: 'http://www.example.com/thumbnails/thing001.png'
                }
            };
            var newThing = {
                thumbnail: {
                    assetId: '001',
                    url: 'http://www.example.com/thumbnails/thing002.png'
                }
            };
            spyOn(repository, 'getThing').and.returnValue(Promise.resolve(oldThing));
            spyOn(repository, 'getThingByOwnerAndSku').and.returnValue(Promise.resolve(oldThing));
            spyOn(principal, 'checkOwnership');
            spyOn(principal, 'checkReadOnlyProperties');
            return sut.updateThing(principal, uuid, newThing)
                .then(function () {
                    expect(repository.getThing).toHaveBeenCalled();
                    expect(principal.checkOwnership).toHaveBeenCalled();
                    expect(principal.checkReadOnlyProperties).toHaveBeenCalledWith(
                        oldThing,
                        newThing,
                        ['uuid', 'created', 'lastModified'],
                        'PRODUCT_UNPROCESSABLE',
                        ['Cannot change service-managed property: thumbnail.url']
                    );
                });
        });
        it('should throw the error thrown by principal.checkReadOnlyProperties()', function () {
            var oldThing = {
                thumbnail: {
                    assetId: '001',
                    url: 'http://www.example.com/thumbnails/thing001.png'
                }
            };
            var newThing = {
                thumbnail: {
                    assetId: '001',
                    url: 'http://www.example.com/thumbnails/thing001.png'
                }
            };
            spyOn(repository, 'getThing').and.returnValue(Promise.resolve(oldThing));
            spyOn(principal, 'checkOwnership');
            spyOn(principal, 'checkReadOnlyProperties').and.throwError(new Error('error'));
            return sut.updateThing(principal, uuid, newThing)
                .then(helper.thenFail)
                .catch(function (err) {
                    expect(err.message).toBe('error');
                    expect(repository.getThing).toHaveBeenCalled();
                    expect(principal.checkOwnership).toHaveBeenCalled();
                    expect(principal.checkReadOnlyProperties).toHaveBeenCalled();
                });
        });
        it('should throw on duplicated sku', function () {
            var oldThing = {
                uuid: uuid,
                thumbnail: {
                    assetId: '001',
                    url: 'http://www.example.com/thumbnails/thing001.png'
                },
                owner: 'owner',
                sku: 'sku'
            };
            var newThing = {
                uuid: uuid,
                thumbnail: {
                    assetId: '001',
                    url: 'http://www.example.com/thumbnails/thing001.png'
                },
                owner: 'owner',
                sku: 'used-sku'
            };
            var otherThing = {
                uuid: 'uuid',
                name: 'name',
                description: 'description',
                owner: 'owner',
                sku: 'used-sku'
            };
            spyOn(repository, 'getThing').and.returnValue(Promise.resolve(oldThing));
            spyOn(principal, 'checkOwnership');
            spyOn(principal, 'checkReadOnlyProperties');
            spyOn(repository, 'getThingByOwnerAndSku').and.returnValue(Promise.resolve(otherThing));
            return sut.updateThing(principal, uuid, newThing)
                .then(helper.thenFail)
                .catch(function (err) {
                    expect(err.code).toBe('DUPLICATED_PRODUCT_SKU');
                    expect(err.message).toBe('Duplicated sku "used-sku"');
                    expect(err.causes).toEqual([
                        'It is already used by thing {"uuid":"uuid","name":"name","description":"description"}'
                    ]);
                    expect(repository.getThing).toHaveBeenCalled();
                    expect(principal.checkOwnership).toHaveBeenCalled();
                    expect(principal.checkReadOnlyProperties).toHaveBeenCalled();
                    expect(repository.getThingByOwnerAndSku).toHaveBeenCalledWith('owner', 'used-sku');
                });
        });
        it('should throw on invalid relatedThingsCollectionId', function () {
            var oldThing = {
                uuid: uuid,
                owner: principal.organizationId,
                name: 'PRODUCT001',
                description: 'Prima Thing',
                thumbnail: {
                    assetId: '001',
                    url: 'http://www.example.com/thumbnails/thing001.png'
                },
                created: new Date('2016-12-08T17:00:00Z'),
                lastModified: new Date('2016-12-08T17:00:00Z'),
                content: [],
                relatedThingsCollectionId: 'collection1'
            };
            var newThing = {
                uuid: uuid,
                owner: principal.organizationId,
                name: 'PRODUCT001',
                description: 'Prima Thing',
                thumbnail: {
                    assetId: '001',
                    url: 'http://www.example.com/thumbnails/thing001.png'
                },
                created: new Date('2016-12-08T17:00:00Z'),
                lastModified: new Date('2016-12-08T17:00:00Z'),
                content: [],
                relatedThingsCollectionId: 'collection2'
            };
            spyOn(messageBusClient, 'request').and.returnValue(Promise.reject(new Error('error')));
            spyOn(contentManager, 'updateContent');
            spyOn(contentManager.assetManager, 'resolveAssets');
            spyOn(contentManager.assetManager, 'referenceAssets');
            spyOn(contentManager.assetManager, 'unreferenceAssets');
            spyOn(repository, 'getThing').and.returnValue(Promise.resolve(oldThing));
            spyOn(repository, 'getThingByOwnerAndSku').and.returnValue(Promise.resolve(null));
            spyOn(repository, 'updateThing');
            spyOn(eventBus, 'publishThingUpdatedEvent');
            return sut.updateThing(principal, uuid, newThing)
                .catch(function (err) {
                    expect(err).toEqual(new Error('error'));
                    expect(messageBusClient.request).toHaveBeenCalledWith(
                        'collection',
                        'get-collection',
                        { principal: principal, uuid: 'collection2' }
                    );
                    expect(contentManager.updateContent).not.toHaveBeenCalled();
                    expect(contentManager.assetManager.resolveAssets).not.toHaveBeenCalled();
                    expect(contentManager.assetManager.referenceAssets).not.toHaveBeenCalled();
                    expect(contentManager.assetManager.unreferenceAssets).not.toHaveBeenCalled();
                    expect(repository.updateThing).not.toHaveBeenCalled();
                    expect(eventBus.publishThingUpdatedEvent).not.toHaveBeenCalled();
                });
        });
        it('should throw on invalid content', function () {
            var oldThing = {
                uuid: uuid,
                owner: principal.organizationId,
                name: 'PRODUCT001',
                description: 'Prima Thing',
                thumbnail: {
                    assetId: '001',
                    url: 'http://www.example.com/thumbnails/thing001.png'
                },
                created: new Date('2016-12-08T17:00:00Z'),
                lastModified: new Date('2016-12-08T17:00:00Z'),
                content: 'a'
            };
            var newThing = {
                uuid: uuid,
                owner: principal.organizationId,
                name: 'PRODUCT001',
                description: 'Prima Thing',
                thumbnail: {
                    assetId: '001',
                    url: 'http://www.example.com/thumbnails/thing001.png'
                },
                created: new Date('2016-12-08T17:00:00Z'),
                lastModified: new Date('2016-12-08T17:00:00Z'),
                content: 'b'
            };
            spyOn(contentManager, 'updateContent').and.returnValue(Promise.reject(new Error('Invalid content')));
            spyOn(contentManager.assetManager, 'resolveAssets');
            spyOn(contentManager.assetManager, 'referenceAssets');
            spyOn(contentManager.assetManager, 'unreferenceAssets');
            spyOn(repository, 'getThing').and.returnValue(Promise.resolve(oldThing));
            spyOn(repository, 'getThingByOwnerAndSku').and.returnValue(Promise.resolve(oldThing));
            spyOn(repository, 'updateThing');
            spyOn(eventBus, 'publishThingUpdatedEvent');
            return sut.updateThing(principal, uuid, newThing)
                .catch(function (err) {
                    expect(err).toEqual(new Error('Invalid content'));
                    expect(contentManager.updateContent).toHaveBeenCalledWith(
                        principal,
                        oldThing.content,
                        newThing.content,
                        localizationSchema
                    );
                    expect(contentManager.assetManager.resolveAssets).not.toHaveBeenCalled();
                    expect(contentManager.assetManager.referenceAssets).not.toHaveBeenCalled();
                    expect(contentManager.assetManager.unreferenceAssets).not.toHaveBeenCalled();
                    expect(repository.updateThing).not.toHaveBeenCalled();
                    expect(eventBus.publishThingUpdatedEvent).not.toHaveBeenCalled();
                });
        });
        it('should throw on invalid thumbnail', function () {
            var oldThing = {
                uuid: uuid,
                owner: principal.organizationId,
                name: 'PRODUCT001',
                description: 'Prima Thing',
                thumbnail: {
                    assetId: '001',
                    url: 'http://www.example.com/thumbnails/thing001.png'
                },
                created: new Date('2016-12-08T17:00:00Z'),
                lastModified: new Date('2016-12-08T17:00:00Z'),
                content: []
            };
            var newThing = {
                uuid: uuid,
                owner: principal.organizationId,
                name: 'PRODUCT001',
                description: 'Prima Thing',
                thumbnail: {
                    assetId: '002'
                },
                created: new Date('2016-12-08T17:00:00Z'),
                lastModified: new Date('2016-12-08T17:00:00Z'),
                content: []
            };
            spyOn(contentManager, 'updateContent').and.returnValue(Promise.resolve());
            spyOn(contentManager.assetManager, 'resolveAssets')
                .and.returnValue(Promise.reject(new Error('Unknown assetId')));
            spyOn(contentManager.assetManager, 'referenceAssets');
            spyOn(contentManager.assetManager, 'unreferenceAssets');
            spyOn(repository, 'getThing').and.returnValue(Promise.resolve(oldThing));
            spyOn(repository, 'getThingByOwnerAndSku').and.returnValue(Promise.resolve(oldThing));
            spyOn(repository, 'updateThing');
            spyOn(eventBus, 'publishThingUpdatedEvent');
            return sut.updateThing(principal, uuid, newThing)
                .catch(function (err) {
                    expect(err).toEqual(new Error('Unknown assetId'));
                    expect(contentManager.updateContent).not.toHaveBeenCalled();
                    expect(contentManager.assetManager.resolveAssets).toHaveBeenCalledWith(principal, ['002']);
                    expect(contentManager.assetManager.referenceAssets).not.toHaveBeenCalled();
                    expect(contentManager.assetManager.unreferenceAssets).not.toHaveBeenCalled();
                    expect(repository.updateThing).not.toHaveBeenCalled();
                    expect(eventBus.publishThingUpdatedEvent).not.toHaveBeenCalled();
                });
        });
        it('should return the updated thing', function () {
            var oldThing = {
                uuid: uuid,
                owner: principal.organizationId,
                name: 'PRODUCT001',
                description: 'Prima Thing',
                thumbnail: {
                    assetId: '001',
                    url: 'http://www.example.com/thumbnails/thing001.png'
                },
                created: new Date('2016-12-08T17:00:00Z'),
                lastModified: new Date('2016-12-08T17:00:00Z'),
                content: []
            };
            var newThing = {
                uuid: uuid,
                owner: principal.organizationId,
                name: 'PRODUCT002',
                description: 'Seconda Thing',
                thumbnail: {
                    assetId: '002',
                },
                created: new Date('2016-12-08T17:00:00Z'),
                lastModified: new Date('2016-12-08T17:00:00Z'),
                content: []
            };
            spyOn(contentManager, 'updateContent').and.returnValue(Promise.resolve());
            spyOn(contentManager.assetManager, 'resolveAssets').and.returnValue(Promise.resolve([
                { thumbnail: 'http://www.example.com/thumbnails/thing002.png' }
            ]));
            spyOn(contentManager.assetManager, 'referenceAssets').and.returnValue(Promise.resolve());
            spyOn(contentManager.assetManager, 'unreferenceAssets').and.returnValue(Promise.resolve());
            spyOn(repository, 'getThing').and.returnValue(Promise.resolve(oldThing));
            spyOn(repository, 'getThingByOwnerAndSku').and.returnValue(Promise.resolve(oldThing));
            spyOn(repository, 'updateThing').and.returnValue(Promise.resolve(newThing));
            return sut.updateThing(principal, uuid, newThing)
                .then(function (result) {
                    expect(contentManager.updateContent).toHaveBeenCalled();
                    expect(contentManager.assetManager.resolveAssets).toHaveBeenCalledWith(principal, ['002']);
                    expect(contentManager.assetManager.unreferenceAssets).toHaveBeenCalledWith(principal, ['001']);
                    expect(contentManager.assetManager.referenceAssets).toHaveBeenCalledWith(principal, ['002']);
                    expect(repository.updateThing).toHaveBeenCalled();
                    expect(result).toBe(newThing);
                });
        });
        it('should update `lastModified` and preserve `created`', function () {
            var oldThing = {
                uuid: uuid,
                owner: principal.organizationId,
                name: 'PRODUCT001',
                description: 'Prima Thing',
                thumbnail: {
                    assetId: '001',
                    url: 'http://www.example.com/thumbnails/thing001.png'
                },
                created: new Date('2016-12-08T17:00:00Z'),
                lastModified: new Date('2016-12-08T17:00:00Z'),
                content: []
            };
            var newThing = {
                uuid: uuid,
                owner: principal.organizationId,
                name: 'PRODUCT002',
                description: 'Seconda Thing',
                thumbnail: {
                    assetId: '001',
                    url: 'http://www.example.com/thumbnails/thing001.png'
                },
                created: new Date('2016-12-08T17:00:00Z'),
                lastModified: new Date('2016-12-08T17:00:00Z'),
                content: []
            };
            spyOn(contentManager, 'updateContent').and.returnValue(Promise.resolve());
            spyOn(contentManager.assetManager, 'resolveAssets');
            spyOn(contentManager.assetManager, 'referenceAssets');
            spyOn(contentManager.assetManager, 'unreferenceAssets');
            spyOn(repository, 'getThing').and.returnValue(Promise.resolve(oldThing));
            spyOn(repository, 'getThingByOwnerAndSku').and.returnValue(Promise.resolve(oldThing));
            spyOn(repository, 'updateThing').and.callFake(function (thing) {return Promise.resolve(thing);});
            return sut.updateThing(principal, uuid, newThing)
                .then(function (result) {
                    expect(repository.getThing).toHaveBeenCalled();
                    expect(contentManager.updateContent).toHaveBeenCalled();
                    expect(contentManager.assetManager.resolveAssets).not.toHaveBeenCalled();
                    expect(contentManager.assetManager.unreferenceAssets).not.toHaveBeenCalled();
                    expect(contentManager.assetManager.referenceAssets).not.toHaveBeenCalled();
                    expect(repository.updateThing).toHaveBeenCalled();
                    expect(result.created).toEqual(oldThing.created);
                    expect(result.lastModified).toBeDate();
                    expect(result.lastModified).not.toEqual(oldThing.lastModified);
                });
        });
        it('should publish a PRODUCT_UPDATED event with the original and the updated thing', function () {
            var oldThing = {
                uuid: uuid,
                name: 'PRODUCT001',
                thumbnail: {}
            };
            var newThing = {
                uuid: uuid,
                name: 'PRODUCT002',
                thumbnail: {}
            };
            spyOn(contentManager, 'updateContent').and.returnValue(Promise.resolve());
            spyOn(repository, 'getThing').and.returnValue(Promise.resolve(oldThing));
            spyOn(repository, 'getThingByOwnerAndSku').and.returnValue(Promise.resolve(oldThing));
            spyOn(repository, 'updateThing').and.returnValue(Promise.resolve(newThing));
            spyOn(eventBus, 'publishThingUpdatedEvent').and.returnValue(Promise.resolve());
            return sut.updateThing(principal, uuid, newThing)
                .then(function () {
                    expect(eventBus.publishThingUpdatedEvent).toHaveBeenCalledWith(oldThing, newThing);
                });
        });
    });

    describe('deleteThing()', function () {
        it('should throw on thing not found', function () {
            spyOn(repository, 'getThing').and.returnValue(Promise.resolve(null));
            spyOn(repository, 'deleteThing');
            spyOn(messageBusClient, 'request');
            spyOn(contentManager, 'deleteContent');
            spyOn(contentManager.assetManager, 'unreferenceAssets');
            return sut.deleteThing(principal, uuid)
                .then(helper.thenFail)
                .catch(function (err) {
                    expect(repository.getThing).toHaveBeenCalled();
                    expect(contentManager.deleteContent).not.toHaveBeenCalled();
                    expect(contentManager.assetManager.unreferenceAssets).not.toHaveBeenCalled();
                    expect(repository.deleteThing).not.toHaveBeenCalled();
                    expect(messageBusClient.request).not.toHaveBeenCalled();
                    expect(err.code).toBe('PRODUCT_NOT_FOUND');
                    expect(err.message).toBe('Thing "' + uuid + '" not found');
                    expect(err.causes).toBeEmptyArray();
                });
        });
        it('should call principal.checkOwnership() with the right parameters', function () {
            var thing = {
                uuid: uuid,
                owner: principal.organizationId,
                thumbnail: {
                    assetId: '001'
                }
            };
            spyOn(repository, 'getThing').and.returnValue(Promise.resolve(thing));
            spyOn(principal, 'checkOwnership');
            spyOn(repository, 'deleteThing').and.returnValue(Promise.resolve());
            spyOn(messageBusClient, 'request');
            spyOn(contentManager, 'deleteContent').and.returnValue(Promise.resolve());
            spyOn(contentManager.assetManager, 'unreferenceAssets').and.returnValue(Promise.resolve());
            return sut.deleteThing(principal, { uuid: uuid })
                .then(function () {
                    expect(repository.getThing).toHaveBeenCalled();
                    expect(principal.checkOwnership)
                        .toHaveBeenCalledWith(thing, sut.thingNotFoundErrorFactory, undefined);
                });
        });
        it('should throw the error thrown by principal.checkOwnership()', function () {
            var thing = 'thing';
            spyOn(repository, 'getThing').and.returnValue(Promise.resolve(thing));
            spyOn(principal, 'checkOwnership').and.throwError(new Error('error'));
            spyOn(repository, 'deleteThing');
            spyOn(contentManager, 'deleteContent');
            spyOn(messageBusClient, 'request');
            spyOn(contentManager.assetManager, 'unreferenceAssets');
            return sut.deleteThing(principal, { uuid: uuid })
                .then(helper.thenFail)
                .catch(function (err) {
                    expect(err.message).toBe('error');
                    expect(repository.getThing).toHaveBeenCalled();
                    expect(principal.checkOwnership).toHaveBeenCalled();
                    expect(contentManager.deleteContent).not.toHaveBeenCalled();
                    expect(contentManager.assetManager.unreferenceAssets).not.toHaveBeenCalled();
                    expect(repository.deleteThing).not.toHaveBeenCalled();
                    expect(messageBusClient.request).not.toHaveBeenCalled();
                });
        });
        it('should return', function () {
            var thing = {
                uuid: uuid,
                owner: principal.organizationId,
                thumbnail: {
                    assetId: '001'
                },
                content: 'content'
            };
            spyOn(repository, 'getThing').and.returnValue(Promise.resolve(thing));
            spyOn(repository, 'deleteThing').and.returnValue(Promise.resolve());
            spyOn(messageBusClient, 'request');
            spyOn(contentManager, 'deleteContent').and.returnValue(Promise.resolve());
            spyOn(contentManager.assetManager, 'unreferenceAssets').and.returnValue(Promise.resolve());
            return sut.deleteThing(principal, uuid)
                .then(function () {
                    expect(repository.getThing).toHaveBeenCalled();
                    expect(contentManager.deleteContent)
                        .toHaveBeenCalledWith(principal, thing.content, localizationSchema);
                    expect(contentManager.assetManager.unreferenceAssets).toHaveBeenCalledWith(principal, ['001']);
                    expect(messageBusClient.request).toHaveBeenCalledWith(
                        'collection', 'remove-thing-from-collections', { principal: principal, uuid: uuid });
                    expect(repository.deleteThing).toHaveBeenCalled();
                });
        });
        it('should publish a PRODUCT_DELETED event with the deleted thing', function () {
            var thing = {
                uuid: 'foo',
                thumbnail: {}
            };
            spyOn(repository, 'getThing').and.returnValue(Promise.resolve(thing));
            spyOn(contentManager, 'deleteContent').and.returnValue(Promise.resolve());
            spyOn(contentManager.assetManager, 'unreferenceAssets').and.returnValue(Promise.resolve());
            spyOn(eventBus, 'publishThingDeletedEvent').and.returnValue(Promise.resolve());
            return sut.deleteThing(principal, 'foo')
                .then(function () {
                    expect(eventBus.publishThingDeletedEvent).toHaveBeenCalledWith(thing);
                });
        });
    });

    describe('listThings()', function () {
        it('should return the result of repository.listThings()', function () {
            spyOn(repository, 'listThings').and.returnValue(Promise.resolve('dummyObject'));
            return sut.listThings(principal)
                .then(function (result) {
                    expect(repository.listThings).toHaveBeenCalled();
                    expect(result).toBe('dummyObject');
                });
        });
        it('should pass down to repository.listThings() any filter', function () {
            spyOn(repository, 'listThings').and.returnValue(Promise.resolve('dummyObject'));
            return sut.listThings(principal, { statusFilter: 'dummy', owner: 'owner' })
                .then(function (result) {
                    expect(repository.listThings).toHaveBeenCalledWith({
                        owner: 'owner',
                        statusFilter: 'dummy'
                    });
                    expect(result).toBe('dummyObject');
                });
        });
    });

    describe('listThingsReferencingAssets()', function () {
        it('should return the result of repository.listThingsReferencingAsset()', function () {
            spyOn(repository, 'listThingsReferencingAsset').and.returnValue(Promise.resolve('dummyObject'));
            return sut.listThingsReferencingAsset(principal, { assetId: 'the-asset-id', owner: 'owner' })
                .then(function (result) {
                    expect(repository.listThingsReferencingAsset).toHaveBeenCalledWith({
                        owner: 'owner',
                        assetId: 'the-asset-id'
                    });
                    expect(result).toBe('dummyObject');
                });
        });
        it('should pass down to repository.listThingsReferencingAsset() any statusFilter', function () {
            spyOn(repository, 'listThingsReferencingAsset').and.returnValue(Promise.resolve('dummyObject'));
            return sut.listThingsReferencingAsset(principal, {  assetId: 'the-asset-id', statusFilter: 'dummy' })
                .then(function (result) {
                    expect(repository.listThingsReferencingAsset).toHaveBeenCalledWith({
                        assetId: 'the-asset-id',
                        statusFilter: 'dummy'
                    });
                    expect(result).toBe('dummyObject');
                });
        });
    });

    describe('listThingsReferencingCollection()', function () {
        it('should return the result of repository.listThingsReferencingCollection()', function () {
            spyOn(repository, 'listThingsReferencingCollection').and.returnValue(Promise.resolve('dummyObject'));
            return sut.listThingsReferencingCollection(principal, 'collectionId')
                .then(function (result) {
                    expect(repository.listThingsReferencingCollection).toHaveBeenCalledWith(
                        principal.organizationId,
                        'collectionId'
                    );
                    expect(result).toBe('dummyObject');
                });
        });
    });

    describe('searchThingsByTags()', function () {
        it('should return the result of repository.searchThingsByTags()', function () {
            spyOn(repository, 'searchThingsByTags').and.returnValue(Promise.resolve('dummyObject'));
            return sut.searchThingsByTags(principal, { tags: ['tag'], locale: 'locale', owner: 'owner' })
                .then(function (result) {
                    expect(repository.searchThingsByTags)
                        .toHaveBeenCalledWith({ owner: 'owner', tags: ['tag'], locale: 'locale' });
                    expect(result).toBe('dummyObject');
                });
        });
        it('should pass down to repository.searchThingsByTags() any statusFilter', function () {
            spyOn(repository, 'searchThingsByTags').and.returnValue(Promise.resolve('dummyObject'));
            return sut.searchThingsByTags(principal, { tags: ['tag'], locale: 'locale', statusFilter: 'dummy' })
                .then(function (result) {
                    expect(repository.searchThingsByTags)
                        .toHaveBeenCalledWith({
                            tags: ['tag'],
                            locale: 'locale',
                            statusFilter: 'dummy'
                        });
                    expect(result).toBe('dummyObject');
                });
        });
    });

});
