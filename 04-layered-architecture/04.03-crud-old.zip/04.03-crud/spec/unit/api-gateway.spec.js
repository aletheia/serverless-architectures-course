'use strict';

var ApiGateway = require('../../src/api-gateway.js');

var createThingSchema = require('../../resources/json-schemas/thing-create.json'),
    updateThingSchema = require('../../resources/json-schemas/thing-update.json');

describe('ApiGateway', function () {
    var sut;

    describe('factory()', function () {
        it('should return an object with a create() method that creates an instance of ApiGateway', function () {
            var event = 'event';
            var factory = ApiGateway.factory();
            expect(factory).toBeObject();
            expect(factory.create).toBeFunction();
            var instance = factory.create(event);
            expect(instance).toEqual(new ApiGateway(event));
        });
    });

    describe('constructor()', function () {
        it('should store the passed event', function () {
            var event = 'event';
            sut = new ApiGateway(event);
            expect(sut.event).toBe(event);
        });
    });

    describe('getUuid()', function () {
        it('should call getPathParameter() with the right parameters and return its result', function () {
            var result = 'result';
            sut = new ApiGateway();
            spyOn(sut, 'getPathParameter').and.returnValue(result);
            var res = sut.getUuid();
            expect(res).toBe(result);
            expect(sut.getPathParameter).toHaveBeenCalledWith('uuid', true);
        });
        it('should propagate the errors of getPathParameter()', function () {
            var error = new Error('error');
            sut = new ApiGateway();
            spyOn(sut, 'getPathParameter').and.throwError(error);
            try {
                sut.getUuid();
            } catch (err) {
                expect(sut.getPathParameter).toHaveBeenCalled();
                expect(err).toBe(error);
            }
        });
    });

    describe('getOwner()', function () {
        it('should call getQueryStringParameter() with the right parameters and return its result', function () {
            var result = 'result';
            sut = new ApiGateway();
            spyOn(sut, 'getQueryStringParameter').and.returnValue(result);
            var res = sut.getOwner();
            expect(res).toBe(result);
            expect(sut.getQueryStringParameter).toHaveBeenCalledWith('owner');
        });
        it('should propagate the errors of getQueryStringParameter()', function () {
            var error = new Error('error');
            sut = new ApiGateway();
            spyOn(sut, 'getQueryStringParameter').and.throwError(error);
            try {
                sut.getOwner();
            } catch (err) {
                expect(sut.getQueryStringParameter).toHaveBeenCalled();
                expect(err).toBe(error);
            }
        });
    });

    describe('getLocale()', function () {
        it('should call getQueryStringParameter() with the right parameters', function () {
            sut = new ApiGateway();
            spyOn(sut, 'getQueryStringParameter');
            sut.getLocale();
            expect(sut.getQueryStringParameter).toHaveBeenCalledWith('locale', false, jasmine.any(Function));
        });
        it('should returned the `locale` parameter if it is valid', function () {
            var event = {
                queryStringParameters: {
                    locale: 'it'
                }
            };
            sut = new ApiGateway(event);
            spyOn(sut, 'getQueryStringParameter').and.callThrough();
            var res = sut.getLocale();
            expect(res).toEqual('it');
            expect(sut.getQueryStringParameter).toHaveBeenCalled();
        });
        it('should throw if the `locale` parameter is invalid', function () {
            var event = {
                queryStringParameters: {
                    locale: 'miao'
                }
            };
            sut = new ApiGateway(event);
            spyOn(sut, 'getQueryStringParameter').and.callThrough();
            try {
                sut.getLocale();
            } catch (err) {
                expect(sut.getQueryStringParameter).toHaveBeenCalled();
                expect(err.statusCode).toBe(400);
                expect(err.message).toBe('Invalid query string parameter "locale"');
                expect(err.causes).toEqual(['Invalid format: "miao"']);
            }
        });
        it('should propagate the errors of getQueryStringParameter()', function () {
            var error = new Error('error');
            sut = new ApiGateway();
            spyOn(sut, 'getQueryStringParameter').and.throwError(error);
            try {
                sut.getLocale();
            } catch (err) {
                expect(sut.getQueryStringParameter).toHaveBeenCalled();
                expect(err).toBe(error);
            }
        });
    });

    describe('getTags()', function () {
        it(
            'should call getQueryStringParameter() with the right parameters and return undefined if the result is ' +
                'undefined',
            function () {
                sut = new ApiGateway();
                spyOn(sut, 'getQueryStringParameter');
                var res = sut.getTags();
                expect(res).toBeUndefined();
                expect(sut.getQueryStringParameter).toHaveBeenCalledWith('tags', false, jasmine.any(Function));
            }
        );
        it('should returned the parsed `tags` parameter if it is valid', function () {
            var event = {
                queryStringParameters: {
                    tags: 'miao,bau'
                }
            };
            sut = new ApiGateway(event);
            spyOn(sut, 'getQueryStringParameter').and.callThrough();
            var res = sut.getTags();
            expect(res).toEqual(['miao', 'bau']);
            expect(sut.getQueryStringParameter).toHaveBeenCalled();
        });
        it('should throw if the `tags` parameter is invalid', function () {
            var event = {
                queryStringParameters: {
                    tags: 'miao,miao'
                }
            };
            sut = new ApiGateway(event);
            spyOn(sut, 'getQueryStringParameter').and.callThrough();
            try {
                sut.getTags();
            } catch (err) {
                expect(sut.getQueryStringParameter).toHaveBeenCalled();
                expect(err.statusCode).toBe(400);
                expect(err.message).toBe('Invalid query string parameter "tags"');
                expect(err.causes).toEqual(['Must contain unique values']);
            }
        });
        it('should propagate the errors of getQueryStringParameter()', function () {
            var error = new Error('error');
            sut = new ApiGateway();
            spyOn(sut, 'getQueryStringParameter').and.throwError(error);
            try {
                sut.getTags();
            } catch (err) {
                expect(sut.getQueryStringParameter).toHaveBeenCalled();
                expect(err).toBe(error);
            }
        });
    });

    describe('getStatusFilter()', function () {
        it('should call getQueryStringParameter() with the right parameters', function () {
            sut = new ApiGateway();
            spyOn(sut, 'getQueryStringParameter');
            sut.getStatusFilter();
            expect(sut.getQueryStringParameter).toHaveBeenCalledWith('statusFilter', false, jasmine.any(Function));
        });
        it('should return `published` if there is no statusFilter parameter', function () {
            var event = {};
            sut = new ApiGateway(event);
            var res = sut.getStatusFilter();
            expect(res).toBe('published');
        });
        it('should return `published` if the statusFilter parameter is `published`, case insensitive', function () {
            var event = {
                queryStringParameters: {
                    statusFilter: 'publisheD'
                }
            };
            sut = new ApiGateway(event);
            var res = sut.getStatusFilter();
            expect(res).toBe('published');
        });
        it('should return `undefined` if the statusFilter parameter is `all`, case insensitive', function () {
            var event = {
                queryStringParameters: {
                    statusFilter: 'All'
                }
            };
            sut = new ApiGateway(event);
            var res = sut.getStatusFilter();
            expect(res).toBeUndefined();
        });
        it('should return `draft` if the statusFilter parameter is `draft`, case insensitive', function () {
            var event = {
                queryStringParameters: {
                    statusFilter: 'draFt'
                }
            };
            sut = new ApiGateway(event);
            var res = sut.getStatusFilter();
            expect(res).toBe('draft');
        });
        it('should throw if the statusFilter parameter is invalid', function () {
            var event = {
                queryStringParameters: {
                    statusFilter: 'miao'
                }
            };
            sut = new ApiGateway(event);
            spyOn(sut, 'getQueryStringParameter').and.callThrough();
            try {
                sut.getStatusFilter();
            } catch (err) {
                expect(sut.getQueryStringParameter).toHaveBeenCalled();
                expect(err.statusCode).toBe(400);
                expect(err.message).toBe('Invalid query string parameter "statusFilter"');
                expect(err.causes).toEqual(['Must be one of "all", "published", "draft"']);
            }
        });
        it('should propagate the errors of getQueryStringParameter()', function () {
            var error = new Error('error');
            sut = new ApiGateway();
            spyOn(sut, 'getQueryStringParameter').and.throwError(error);
            try {
                sut.getStatusFilter();
            } catch (err) {
                expect(sut.getQueryStringParameter).toHaveBeenCalled();
                expect(err).toBe(error);
            }
        });
    });

    describe('getThingForCreate()', function () {
        it('should call getEntity() with the right parameters and return its result', function () {
            var result = 'result';
            sut = new ApiGateway();
            spyOn(sut, 'getEntity').and.returnValue(result);
            var res = sut.getThingForCreate();
            expect(res).toBe(result);
            expect(sut.getEntity).toHaveBeenCalledWith(createThingSchema, 'thing');
        });
        it('should propagate the errors of getEntity()', function () {
            var error = new Error('error');
            sut = new ApiGateway();
            spyOn(sut, 'getEntity').and.throwError(error);
            try {
                sut.getThingForCreate();
            } catch (err) {
                expect(sut.getEntity).toHaveBeenCalled();
                expect(err).toBe(error);
            }
        });
    });

    describe('getThingForUpdate()', function () {
        it('should call getEntity() with the right parameters and return its result', function () {
            var result = 'result';
            sut = new ApiGateway();
            spyOn(sut, 'getEntity').and.returnValue(result);
            var res = sut.getThingForUpdate();
            expect(res).toBe(result);
            expect(sut.getEntity).toHaveBeenCalledWith(updateThingSchema, 'thing');
        });
        it('should propagate the errors of getEntity()', function () {
            var error = new Error('error');
            sut = new ApiGateway();
            spyOn(sut, 'getEntity').and.throwError(error);
            try {
                sut.getThingForUpdate();
            } catch (err) {
                expect(sut.getEntity).toHaveBeenCalled();
                expect(err).toBe(error);
            }
        });
    });
});
