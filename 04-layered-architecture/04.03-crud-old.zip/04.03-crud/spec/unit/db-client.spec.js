'use strict';

var helper = require('../helper'),
    Client = require('../../src/db-client.js'),
    Promise = require('bluebird'),
    NspError = require('../../src/errors.js').NspError;

describe('DBClient', function () {
    var collection, db, mongoClient, mongo, url, sut;
    beforeEach(function () {
        collection = {
            insertOne: function () {},
            find: function () {},
            findOne: function () {},
            findOneAndReplace: function () {},
            deleteOne: function () {},
            update: function () {}
        };
        db = {
            collection: function () {},
            dropDatabase: function () {},
            close: function () {}
        };
        mongoClient = {
            connect: function () {
                return Promise.resolve(db);
            }
        };
        mongo = {
            MongoClient: mongoClient,
            ObjectId: function () {}
        };
        mongo.ObjectId.isValid = function () {};
        url = 'testingurl';
        sut = new Client(helper.getLoggerMock(), { url: url }, mongo);
    });
    describe('Constructor()', function () {
        it('connect to the database on construction with the given url', function () {
            spyOn(mongoClient, 'connect').and.callFake(function (param) {
                expect(param).toBe(url);
            });
            new Client(helper.getLoggerMock(), { url: url }, mongo);
            expect(mongoClient.connect).toHaveBeenCalled();
        });
    });
    describe('insertOne()', function () {
        it('should use the connected DB to get the required collection', function () {
            spyOn(collection, 'insertOne').and.returnValue(Promise.resolve());
            spyOn(db, 'collection').and.returnValue(collection);
            return sut.insertOne('dummy').then(function () {
                expect(db.collection).toHaveBeenCalledWith('dummy');
            });
        });
        it('should insert in the collection a document', function () {
            spyOn(collection, 'insertOne').and.returnValue(Promise.resolve('dummy'));
            spyOn(db, 'collection').and.returnValue(collection);
            return sut.insertOne('dummy', 'doc').then(function (result) {
                expect(result).toBe('dummy');
                expect(collection.insertOne).toHaveBeenCalledWith('doc');
            });
        });
        it('should throw any error thrown by the internal call wrapping in NspError', function () {
            spyOn(collection, 'insertOne').and.returnValue(Promise.reject(new Error('db error')));
            spyOn(db, 'collection').and.returnValue(collection);
            return sut
                .insertOne('dummy', 'doc')
                .then(helper.thenFail)
                .catch(function (err) {
                    expect(err.code).toBe(NspError.codes.INTERNAL_SERVER_ERROR);
                    expect(err.message).toBe('db error');
                });
        });
    });
    describe('find()', function () {
        it('should use the connected DB to get the required collection', function () {
            spyOn(db, 'collection').and.returnValue(collection);
            return sut.find('dummy').then(function () {
                expect(db.collection).toHaveBeenCalledWith('dummy');
            });
        });
        it('should pass to the collection find method the query', function () {
            spyOn(collection, 'find').and.returnValue('dummy');
            spyOn(db, 'collection').and.returnValue(collection);
            return sut.find('dummy', 'query').then(function (result) {
                expect(result).toBe('dummy');
                expect(collection.find.calls.mostRecent().args[0]).toBe('query');
                expect(collection.find.calls.mostRecent().args[1]).toBeUndefined();
            });
        });
        it('should pass to the collection find method the projection', function () {
            spyOn(collection, 'find').and.returnValue('dummy');
            spyOn(db, 'collection').and.returnValue(collection);
            return sut.find('dummy', 'query', 'projection').then(function (result) {
                expect(result).toBe('dummy');
                expect(collection.find.calls.mostRecent().args[0]).toBe('query');
                expect(collection.find.calls.mostRecent().args[1]).toBe('projection');
            });
        });
        it('should throw any error thrown by the internal call wrapping in NspError', function () {
            spyOn(collection, 'find').and.throwError('dummy');
            spyOn(db, 'collection').and.returnValue(collection);
            return sut
                .find('dummy', 'query')
                .then(helper.thenFail)
                .catch(function (err) {
                    expect(err.code).toBe(NspError.codes.INTERNAL_SERVER_ERROR);
                    expect(err.message).toBe('dummy');
                });
        });
    });
    describe('findOne()', function () {
        it('should use the connected DB to get the required collection', function () {
            spyOn(collection, 'findOne').and.returnValue(Promise.resolve());
            spyOn(db, 'collection').and.returnValue(collection);
            return sut.findOne('dummy').then(function () {
                expect(db.collection).toHaveBeenCalledWith('dummy');
            });
        });
        it('should pass to the collection all the other parameters', function () {
            spyOn(collection, 'findOne').and.returnValue(Promise.resolve('dummy'));
            spyOn(db, 'collection').and.returnValue(collection);
            return sut.findOne('dummy', 'query', 'projection').then(function (result) {
                expect(result).toBe('dummy');
                expect(collection.findOne).toHaveBeenCalledWith('query', 'projection');
            });
        });
        it('should throw any error thrown by the internal call wrapping in NspError', function () {
            spyOn(collection, 'findOne').and.returnValue(Promise.reject(new Error('dummy')));
            spyOn(db, 'collection').and.returnValue(collection);
            return sut
                .findOne('dummy', 'a')
                .then(helper.thenFail)
                .catch(function (err) {
                    expect(err.code).toBe(NspError.codes.INTERNAL_SERVER_ERROR);
                    expect(err.message).toBe('dummy');
                    expect(collection.findOne).toHaveBeenCalledWith('a', undefined);
                });
        });
    });
    describe('findOneAndReplace()', function () {
        it('should use the connected DB to get the required collection', function () {
            spyOn(collection, 'findOneAndReplace').and.returnValue(Promise.resolve());
            spyOn(db, 'collection').and.returnValue(collection);
            return sut.findOneAndReplace('dummy').then(function () {
                expect(db.collection).toHaveBeenCalledWith('dummy');
            });
        });
        it('should pass to the collection all the other parameters', function () {
            spyOn(collection, 'findOneAndReplace').and.returnValue(Promise.resolve('dummy'));
            spyOn(db, 'collection').and.returnValue(collection);
            return sut.findOneAndReplace('dummy', 'query', 'doc', 'options').then(function (result) {
                expect(result).toBe('dummy');
                expect(collection.findOneAndReplace).toHaveBeenCalledWith('query', 'doc', 'options');
            });
        });
        it('should throw any error thrown by the internal call wrapping in NspError', function () {
            spyOn(collection, 'findOneAndReplace').and.returnValue(Promise.reject(new Error('dummy')));
            spyOn(db, 'collection').and.returnValue(collection);
            return sut
                .findOneAndReplace('dummy', 'a', 'b')
                .then(helper.thenFail)
                .catch(function (err) {
                    expect(err.code).toBe(NspError.codes.INTERNAL_SERVER_ERROR);
                    expect(err.message).toBe('dummy');
                    expect(collection.findOneAndReplace).toHaveBeenCalledWith('a', 'b', undefined);
                });
        });
    });
    describe('deleteOne()', function () {
        it('should use the connected DB to get the required collection', function () {
            spyOn(collection, 'deleteOne').and.returnValue(Promise.resolve());
            spyOn(db, 'collection').and.returnValue(collection);
            return sut.deleteOne('dummy').then(function () {
                expect(db.collection).toHaveBeenCalledWith('dummy');
            });
        });
        it('should pass to the collection all the other parameters', function () {
            spyOn(collection, 'deleteOne').and.returnValue(Promise.resolve('dummy'));
            spyOn(db, 'collection').and.returnValue(collection);
            return sut.deleteOne('dummy', 'query').then(function (result) {
                expect(result).toBe('dummy');
                expect(collection.deleteOne).toHaveBeenCalledWith('query');
            });
        });
        it('should throw any error thrown by the internal call wrapping in NspError', function () {
            spyOn(collection, 'deleteOne').and.returnValue(Promise.reject(new Error('dummy')));
            spyOn(db, 'collection').and.returnValue(collection);
            return sut
                .deleteOne('dummy', 'a')
                .then(helper.thenFail)
                .catch(function (err) {
                    expect(err.code).toBe(NspError.codes.INTERNAL_SERVER_ERROR);
                    expect(err.message).toBe('dummy');
                    expect(collection.deleteOne).toHaveBeenCalledWith('a');
                });
        });
    });
    describe('update()', function () {
        it('should use the connected DB to get the required collection', function () {
            spyOn(collection, 'update').and.returnValue(Promise.resolve());
            spyOn(db, 'collection').and.returnValue(collection);
            return sut.update('dummy', 'query', 'update').then(function () {
                expect(db.collection).toHaveBeenCalledWith('dummy');
            });
        });
        it('should pass to the collection all the other parameters', function () {
            spyOn(collection, 'update').and.returnValue(Promise.resolve('dummy'));
            spyOn(db, 'collection').and.returnValue(collection);
            return sut.update('collection', 'query', 'update').then(function (result) {
                expect(result).toBe('dummy');
                expect(collection.update).toHaveBeenCalledWith('query', 'update');
            });
        });
        it('should throw any error thrown by the internal call wrapping in NspError', function () {
            spyOn(collection, 'update').and.returnValue(Promise.reject(new Error('dummy')));
            spyOn(db, 'collection').and.returnValue(collection);
            return sut
                .update('collection', 'query', 'update')
                .then(helper.thenFail)
                .catch(function (err) {
                    expect(err.code).toBe(NspError.codes.INTERNAL_SERVER_ERROR);
                    expect(err.message).toBe('dummy');
                    expect(collection.update).toHaveBeenCalledWith('query', 'update');
                });
        });
    });
    describe('dropDatabase()', function () {
        it('should throw if the connected DB throws dropping the database', function () {
            spyOn(db, 'dropDatabase').and.returnValue(Promise.reject(new Error('dummy')));
            return sut
                .dropDatabase()
                .then(helper.thenFail)
                .catch(function (err) {
                    expect(err.message).toBe('dummy');
                    expect(db.dropDatabase).toHaveBeenCalled();
                });
        });
        it('should use the connected DB to drop the database and return the result', function () {
            spyOn(db, 'dropDatabase').and.returnValue(Promise.resolve('dummy'));
            return sut.dropDatabase().then(function (result) {
                expect(result).toBe('dummy');
                expect(db.dropDatabase).toHaveBeenCalled();
            });
        });
    });
    describe('dispose()', function () {
        it('should throw if the connected DB throws closing the database', function () {
            spyOn(db, 'close').and.returnValue(Promise.reject(new Error('dummy')));
            return sut
                .dispose()
                .then(helper.thenFail)
                .catch(function (err) {
                    expect(err.message).toBe('dummy');
                    expect(db.close).toHaveBeenCalled();
                });
        });
        it('should close the connected database', function () {
            spyOn(db, 'close');
            return sut.dispose().then(function () {
                expect(db.close).toHaveBeenCalled();
            });
        });
    });
});
