'use strict';

var _ = require('lodash'),
    Commons = require('@neosperience/nsp-service-commons-lib'),
    Container = require('../src/container.js'),
    MongoDb = require('mongodb'),
    Promise = require('bluebird');

var config = new Commons.Config('./config', 'ENV').get();

module.exports.getLoggerMock = function () {
    var noop = function () {
    };
    return {
        silly: noop,
        debug: noop,
        verbose: noop,
        info: noop,
        warn: noop,
        error: noop
    };
};

module.exports.thenFail = function (data) {
    var formatted = data;
    if (data !== undefined) {
        try {
            formatted = JSON.stringify(data);
        } catch (e) {
            formatted = data;
        }
    }
    fail('Promise rejection expected, instead fulfilled with: ' + formatted);
};

module.exports.getConfig = function () {
    return config;
};

module.exports.createContainer = function (lambdaClient) {
    return new Container(lambdaClient);
};

var connectDatabase = function () {
    var config = module.exports.getConfig();
    return MongoDb.MongoClient.connect(config.database.url, { promiseLibrary: Promise });
};

module.exports.dropDatabase = function () {
    var conn;
    return connectDatabase()
        .then(function (db) {
            conn = db;
            return db.dropDatabase();
        })
        .finally(function () {
            return conn.close();
        });
};

module.exports.loadFixtures = function (fixtures) {
    var conn, loadedFixtures = _.cloneDeep(fixtures);
    return Promise
        .try(function () {
            if (!_.isObject(fixtures)) {
                throw new Error('Fixtures format not correct');
            }
            return connectDatabase();
        })
        .then(function (db) {
            conn = db;
            return Promise
                .each(_.keys(fixtures), function (collectionName) {
                    var collectionFixtures = fixtures[collectionName];
                    if (!_.isArray(collectionFixtures) || _.isEmpty(collectionFixtures)) {
                        return;
                    }
                    return db.collection(collectionName).insertMany(collectionFixtures)
                        .then(function (result) {
                            _.forEach(result.insertedIds, function (value, idx) {
                                loadedFixtures[collectionName][idx]._id = value;
                            });
                        });
                })
                .then(function () {
                    return loadedFixtures;
                })
                .finally(function () {
                    return conn.close();
                });
        });
};

module.exports.executeFind = function (collectionName, query, projection) {
    var conn;
    return Promise
        .try(function () {
            return connectDatabase();
        })
        .then(function (db) {
            conn = db;
            return db.collection(collectionName).find(query, projection).toArray()
                .finally(function () {
                    return conn.close();
                });
        });
};

module.exports.lambdaClientResultResponse = function (result) {
    return {
        promise: function () {
            return Promise.resolve({ Payload: JSON.stringify(result) });
        }
    };
};

module.exports.lambdaClientErrorResponse = function (error) {
    return {
        promise: function () {
            return Promise.resolve({ Payload: JSON.stringify({ errorMessage: JSON.stringify(error) }) });
        }
    };
};
